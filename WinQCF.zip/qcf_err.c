/****************************************************************************\

	QCFIT Module Err_handler
	
	Provides the QCFIT error handling routines.
	
	Author:  Steve Wilcox, Jeremy Cook
	
	Date:  2003-07-02
	
	Description:

\****************************************************************************/
#include <ansi_c.h>
#include <userint.h>
#include "qcf_err.h"


/* function prototypes */
char* error_msg(int code, char *note, char *msg);


void fatal_error(int code, char *note)
{
	char user_msg[1000],
		error[500];
	
	sprintf(user_msg, "The program has encountered an irrecoverable error condition:\n\n%s\n\n"
				 "Please exit the program and report this error.", error_msg(code, note, error));
	MessagePopup("Irrecoverable Error", user_msg);
}

void nonfatal_error(int code, char *note)
{
	char user_msg[1000],
		 error[500];
	
	sprintf(user_msg, "The program has encountered a potential error condition:\n\n%s\n\n"
				 "Data or program operation may be compromised", error_msg(code, note, error));
	MessagePopup("Warning", user_msg);
}

void advisory_error(int code, char *note)
{
	char user_msg[1000],
		 error[500];
	
	sprintf(user_msg, "The program has encountered a possible error condition:\n\n%s\n"
				 "Make sure this condition is consistant with system use.", error_msg(code, note, error));
	MessagePopup("Advisory", user_msg);
}

char* error_msg(int code, char *note, char *msg)
{
	switch (code)
	{
		case MEM_ALLOC_ERROR:
			sprintf(msg, "Memory allocation error in (%s)", note);
			break;
			
		case FILE_OPEN_ERROR:
			sprintf(msg, "Cannot open file (%s)", note);
			break;
			
		case FILE_WRITE_ERROR:
			sprintf(msg, "Cannot write to file (%s)", note);
			break;
			
		case FILE_READ_ERROR:
			sprintf(msg, "Format error or unexpected end of file (%s)", note);
			break;
			
		case FILE_CLOSE_ERROR:
			sprintf(msg, "Cannot close file in %s", note);
			break;
			
		case SOLPOS_ERROR:
			sprintf(msg, "SolPos error: %s", note);
			break;
			
		case QC0_FORMAT_ERROR:
			sprintf(msg, "Error in QC0 file format: %s", note);
			break;
			
		case PLOT_INIT_ERROR:
			sprintf(msg, "Cannot initialize data plot in %s", note);
			break;
			
		case INTERNAL_ERROR:
			sprintf(msg, "Internal error: %s", note);
			break;
			
		case GENERIC_ERROR:
			sprintf(msg, "%s", note);
			break;
			
		default:
			sprintf(msg, "Unknown error [%s]", note);
			
	}

	return msg;
}

