#include "toolbar.h"
#include <utility.h>
#include <userint.h>
#include "WinQCF.h"
#include <ansi_c.h>
#include "solpos00.h"
#include "qcf.h"
#include "qcf_err.h"
#include "qcf_bndry.h"

void timecvtcal(int adjmin, int *year, int *month, int *day, int *hour, int *minute);
void timecvt(int adjmin, int *inyear, int *indoy, int *inhour, int *inminute);
int dayofyear(int year, int month, int day);
void modyyr(int jday, int year, int *month, int *day);
int leapday(int year);
void sortlist(struct datalist *lhead);


int Density(void *callbackData);
int Plot (void *callbackData);
int DisplayStats (void *callbackData);
int UpdateCurveDisplay (void *callbackData, int panel, int ig);

static int listpan;
static int listmenu;
static int waitPan;
static ToolbarType ListToolbar;



/****************************************************************************\

	Function: str_trim()
	  Author: Steve Wilcox,
	    Date: 2001-03-01
	
 Description: Trims spaces from the beginning and end of strings.
 			  
	  Inputs: A string.
	 
	 Outputs: (By reference) a string that has no leading or trailing spaces.
	
	Note: Also removes any newline at the end of the string.				   
\****************************************************************************/
void str_trim(char *s)
{
  char *ptr;   /* temporary string pointer for searching */

  /* strip any existing newline character */
  if ((ptr = strchr(s, '\n')) != NULL)
    *ptr = '\0';

  /* point to the beginning of the string */
  ptr = s;
  
  /* pass over any blanks to look for beginning of text */
  while (*ptr == ' ')
    ptr++;
    
  /* move the text to the beginning of the string */
  strcpy(s, ptr);
  
  /* point to the end of the string */
  ptr = s + strlen(s);
  
  /* move backwards over spaces to look for the end of any text */
  while (ptr != s && *(ptr-1) == ' ')
    ptr--;
    
  /* terminate the string at the end of text */
  *ptr = '\0';
}


/***********************************************************************\

  function midsol()

  Description: Finds the solar geometry at the midpoint of the interval.

    Inputs: struct posdata *soldat ... pointer to a solpos structure 
    		filled in for time, location, etc.
    Outputs: The midpoint zenith angle, etr, and etrn (via soldat
    		structure). Returns the solpos return code.
    
    Note: This function modifies the incoming solpos structure, 
    		overwriting values for time and solar geometry.

\***********************************************************************/
int midsol(struct posdata *soldat)
{
	
	int 	i,			/* loop index */
			interval,	/* measurement interval */
			save_f,		/* storage for the current Solpos function parameter */
			retval;		/* function return value */
	
	float	frac, 		/* fraction to balance beginning and ending accumulators */
			sunup, 		/* count of sunup minutes */
			zen,		/* accumulator for zen */
			etr,		/* accumulator for etr */
			etrn;		/* accumulator for etrn */
	
	/* initialize the accumulators */
	sunup	= 0;0;
	zen		= 0.0;
	etr		= 0.0;
	etrn	= 0.0;
	
	interval = soldat->interval;
	
	/* go to the beginning of the interval to see if the sun is up */
	timecvtcal(-interval, &soldat->year, &soldat->month, &soldat->day, &soldat->hour, &soldat->minute);

	/* loop through the interval, ending on and including the original time  */
	for (i = 0; i < interval+1; i++)
	{
		retval = S_solpos(soldat);
		
		if (retval == 0)
		{
			if (soldat->etrn > 0.0)
			{
				/* give only half weight to the end points */
				frac = (i == 0 || i == interval) ? 0.5 : 1.0;
			
				sunup	+= frac;
				zen		+= (soldat->zenref * frac);
				etr 	+= (soldat->etr    * frac);
				etrn	+= (soldat->etrn   * frac);
			}
		
			/* increment time by one minute */
			timecvtcal(1, &soldat->year, &soldat->month, &soldat->day, &soldat->hour, &soldat->minute);
		}
		else
			break; // bad solpos call
	}
	
	/* take the average of the sunup value for the zenith angle and the average of
	   the entire interval for etr and etrn.  Assign to the solpos structure */
	
	if (sunup > 0.0 && retval == 0)
	{
		soldat->zenref	= zen / sunup;
		soldat->etr		= etr / (float)interval;
		soldat->etrn	= etrn / (float)interval;
		
		/* get the airmass for the new zenith angle */
		save_f = soldat->function;
		soldat->function = L_AMASS;
		retval = S_solpos(soldat);
		soldat->function = save_f;
	}
	
	return retval;
}	
	
				
	
	
	
	
	
/***********************************************************************\

  function timecvtcal()

  Description: Adjusts the time and calendar date by specified number of minutes.

    Inputs: Number of minutes to adjust,
            Year, month, day, hour, and minute (by value)
    Outputs: Year, month, day, hour, and minute (by reference) for
            the adjusted time.

\***********************************************************************/
void timecvtcal(int adjmin, int *year, int *month, int *day, int *hour, int *minute)
{
  int doy;

  doy = dayofyear(*year, *month, *day);
  timecvt(adjmin, year, &doy, hour, minute);
  modyyr(doy, *year, month, day);
}

/***********************************************************************\

  function timecvt()

  Description: Adjusts the time and date by specified number of minutes.

    Inputs: Number of minutes to adjust,
            Year, day of year, hour, and minute of GMT (by value)
    Outputs: Year, day of year, hour, and minute (by reference) for
            the local time.

\***********************************************************************/
void timecvt(int adjmin, int *inyear, int *indoy, int *inhour, int *inminute)
{

  /* adjust the time */
  *inminute += adjmin;

  /* check for minutes out of bounds */
  while (*inminute < 0)
  {
    (*inhour)--;
    (*inminute) += 60;
  }
  while (*inminute > 59)
  {
    (*inhour)++;
    (*inminute) -= 60;
  }

  /* check for hours out of bounds */
  while (*inhour < 0)
  {
    (*indoy)--;
    (*inhour) += 24;
  }
  while (*inhour > 23)
  {
    (*indoy)++;
    (*inhour) -= 24;
  }

  /* check for days out of bounds */
  while (*indoy < 1)
  {
    (*inyear)--;
    (*indoy) += (365 + leapday(*inyear));
  }
  while (*indoy > (365 + leapday(*inyear)))
  {
    (*indoy) -= (365 + leapday(*inyear));
    (*inyear)++;
  }
}


/***********************************************************************\

  function dayofyear()

  Description: Converts date as year, month, and day to day of years
               (accounts for leap year).

  Inputs:  Year, month, day
  Return:  Day of year

\***********************************************************************/
int dayofyear(int year, int month, int day)
{

  int Month_days [] = {0,31,59,90,120,151,181,212,243,273,304,334};
  int doy;   /* day of year */

  doy = Month_days[month-1] + day;
  if (month > 2)
    doy += leapday(year);

  return doy;
}

/***********************************************************************\

  function modyry()

  Description: Takes a julian day and year and converts to month-day-year
               (returns only the month and day by reference)

\***********************************************************************/
void modyyr(int jday, int year, int *month, int *day)
{
  int molgth[]= {31,28,31,30,31,30,31,31,30,31,30,31};
  int i, j;

  j = jday;

  /* do leapyear */
  molgth[1] += leapday(year);

  for (i = 0; i < 12 && j > 0; i++)
    j -= molgth[i];

  *month = i;
  *day =   j + molgth[i-1];
}

/***********************************************************************\

  function leapday()

     Description:  Given a year, determines whether it is a leapyear.

     Inputs:  Year

     Outputs: 1 if leapyear, 0 if non-leapyear.

\***********************************************************************/
int leapday(int year)
{
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0 )
      return 1; /* leap year */
    else
      return 0;
}


/***********************************************************************\

  function list_dat()

  Description: Lists all data under selected pixels.

    Inputs: datastruct passed as callbackData.
    
    Outputs: List text box
    
    Note: 

\***********************************************************************/
int CVICALLBACK list_dat (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, ip, x1, x2, y1, y2, ix, iy, filenum, fileold, dat_cnt;
	double x1_pos, x2_pos, y1_pos, y2_pos; 
	char io[2000], kt[10], kn[10], kd[10], compare[100], dat_str[2050];
	
	datastruct *dat;
	pixelheader *pixel;
	struct datalist *rec, *rpt_list, *rpt_tail;
	graphstruct *graph;
	
	FILE *infile;
	
	switch (event)
		{
		case EVENT_COMMIT:
			dat = (datastruct*) callbackData;
			
			if ((listpan = LoadPanel (0, "WinQCF.uir", LISTPAN)) < 0)
				return -1;
				
			listmenu = LoadMenuBar (listpan, "WinQCF.uir", LISTER);
			Toolbar_New (listpan, listmenu, "List Toolbar", 0, 0, 1, 1,
						 &ListToolbar);
			Toolbar_InsertItem (ListToolbar, 1, kCommandButton, 1, "Save List",
								kMenuCallback, LISTER_FILE_SAVE, 0, 0, "save.pcx");
			Toolbar_Display (ListToolbar);
			InstallPopup(listpan);
				
			/* Set ig based on title of panel so values are correctly saved for each air mass. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Err adjustment corrupted.");
			graph = &dat->graphs[ig];

			/* get the panel */
			ip = dat->selPlane;
			
			/* save the initialized tail for reset */
			rpt_tail = graph->rpthead->rpt_next;
			
			/* get the cursor locations and convert to integer indexes, min to max */
			GetGraphCursor (panel, EDIT_GRAPH, 1, &x1_pos, &y1_pos);
			GetGraphCursor (panel, EDIT_GRAPH, 2, &x2_pos, &y2_pos);
			
			x1 = RoundRealToNearestInteger(MIN(x1_pos, x2_pos));
			y1 = RoundRealToNearestInteger(MIN(y1_pos, y2_pos));
			x2 = RoundRealToNearestInteger(MAX(x1_pos, x2_pos));
			y2 = RoundRealToNearestInteger(MAX(y1_pos, y2_pos));
			
			/* make sure we're not out of bounds */
			x1 = MAX(x1, XMIN);
			x2 = MIN(x2, XMAX);
			y1 = MAX(y1, YMIN);
			y2 = MIN(y2, YMAX);
			
			/* go through the selected pixels and look for data */
			dat_cnt = 0;
			for (ix = x1; ix <= x2; ix++)
			{
				for (iy = y1; iy <= y2; iy++)
				{
					pixel = &graph->phead[ix][iy][ip];
					
					/* if there's data, add the entire list to the report list by
					   copying plane links to the report links */
					if (pixel->count > 0 && !pixel->excluded)
					{
						dat_cnt += pixel->count;
						rec = pixel->dathead->dat_next[ip]; 	// first rec under pixel
						rpt_list = graph->rpthead->rpt_next;	// report list under graph
						graph->rpthead->rpt_next = rec;			// start inserting pixel list
						
						/* inset the pixel list under rpthead */
						while (rec->dat_next[ip]->dat_next[ip])
						{
							rec->rpt_next = rec->dat_next[ip];  // duplicate pixel links for report
							rec = rec->dat_next[ip];
						}
						rec->rpt_next = rpt_list;				// attach original list
					}
				}
			}
			
			waitPan = -1; // flag for dismissal
			if (dat_cnt > 6000)
			{
				waitPan = LoadPanel (0, "WinQCF.uir", WAIT_PAN_3);
				InstallPopup(waitPan);
			}
			
				
			/* update the record count on the panel */
			sprintf(io, "%d", dat_cnt);
			SetCtrlVal(listpan, LISTPAN_DAT_CNT, io);
			
			/* sort report list by date */
			sortlist(graph->rpthead);
			
			if (waitPan >= 0)
				DiscardPanel(waitPan);
				
			/* go down the report list and copy to text box */
			rpt_list = graph->rpthead->rpt_next;
			
			fileold = -1;
			while (rpt_list->rpt_next)
			{
				/* get the source file for this record */
				filenum = rpt_list->filenum;
				
				/* open a new file if the file has changed */
				if (filenum != fileold)
				{
					if (fileold >= 0)
						fclose(infile);
						
					if ((infile = fopen(dat->file_dat.MFileName[filenum], "rt")) == NULL)
						nonfatal_error(FILE_OPEN_ERROR,dat->file_dat.MFileName[filenum] );
					else
						fileold = filenum;
				}
				
				/* read the original record from the file */
				fseek (infile, rpt_list->fileptr, SEEK_SET);
				fgets(io, 1999, infile);
				
				/* format to accommodate missing data */
				if (rpt_list->kt < MISS_K)
					sprintf(kt, "%6.3f", rpt_list->kt);
				else
					sprintf(kt, "%6s", "-----");
				
				if (rpt_list->kn < MISS_K)
					sprintf(kn, "%6.3f", rpt_list->kn);
				else
					sprintf(kn, "%6s", "-----");
				
				if (rpt_list->kd < MISS_K)
					sprintf(kd, "%6.3f", rpt_list->kd);
				else
					sprintf(kd, "%6s", "-----");
				
				/* print it out */
				sprintf(dat_str, " %4.1f |%s |%s |%s | %s", rpt_list->solzen, kt, kn, kd, io);
				SetCtrlVal(listpan, LISTPAN_DATALIST, dat_str);
				
				/* go to the next record */
				rpt_list = rpt_list->rpt_next;
			}
			
			
			/* done... reset the list by attaching tail to head (ignore existing 
			   links... they will be overwritten if necessary) */
			graph->rpthead->rpt_next = rpt_tail;
			fclose(infile);
			
			break;
		}
	return 0;
}

/**************************** FUNCTION sortlist *****************************/
/**   NAME:                                                                **/
/**   DATE: 10/27/92                                                       **/
/**     BY: Steve Wilcox                                                   **/
/**                                                                        **/
/**   DESCRIPTION: This is a "selection sort" that I modified for lists:   **/
/**                                                                        **/
/**      A selection sort traverses an array looking for the lowest value. **/
/**      That value is then swapped for the value in the target position,  **/
/**      and then the target position is incremented.                      **/
/**                                                                        **/
/**      This sort traverses the list looking for the lowest value.  That  **/
/**      value's record unlinked from the list and then inserted before    **/
/**      the target position, and then the target position is incremented. **/
/**                                                                        **/
/**    Note that the target is referenced as ltargprev->next, sort of like **/
/**    saying "I am my predecessor's successor."  This reference provides  **/
/**    a handy pointer to the element previous to the target in the list   **/
/**    (for linking in the lowest value element).                          **/
/**                                                                        **/
/**    The list head, lhead, does not contain data; the real list starts   **/
/**    with the element after the head.  The last data element must be     **/
/**    marked with its .next pointer set to NULL.                          **/
/**                                                                        **/
/****************************************************************************/
void sortlist(struct datalist *lhead)
{

  struct datalist
     *ltargprev,     /* references the target position in the list */
     *lbest,         /* points to the best candidate for moving    */
     *lbestprev,     /* points to the element prior the best       */
     *ltry;          /* points to the candidate member             */

  /* the target to beat is ltargprev->next (lhead is not considered */
  ltargprev = lhead;
  while (ltargprev->rpt_next)
  {
    /* the first in the list is the starting point for comparison */
    lbest = ltargprev->rpt_next;
    ltry  = lbest;
    while (ltry->rpt_next)
    {
      /* see if this is a new low */
      if (ltry->rpt_next->date < lbest->date)
      {
        lbestprev = ltry;
        lbest     = ltry->rpt_next;
      }
      ltry = ltry->rpt_next;
    }

    /* unlink and move, if there is a candidate element */
    if (lbest != ltargprev->rpt_next)
    {
      /* yank lbest from list (link around it) */
      lbestprev->rpt_next = lbest->rpt_next;

      /* insert lbest before target */
      lbest->rpt_next = ltargprev->rpt_next;
      ltargprev->rpt_next = lbest;
    }

    ltargprev = ltargprev->rpt_next;
  }
}

int CVICALLBACK exclude_pix (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	datastruct *dat;
	char compare[100];
	graphstruct *graph;

	int		ig, ip, x1, x2, y1, y2, ix, iy;
	double	x1_pos, x2_pos, y1_pos, y2_pos;
	
	switch (event)
		{
		case EVENT_COMMIT:
			dat = (datastruct*) callbackData;
			
			/* Set ig based on title of panel so values are correctly saved for each air mass. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Err adjustment corrupted.");
			graph = &dat->graphs[ig];

			/* get the panel */
			ip = dat->selPlane;
			
			/* get the cursor locations and convert to integer indexes, min to max */
			GetGraphCursor (panel, EDIT_GRAPH, 1, &x1_pos, &y1_pos);
			GetGraphCursor (panel, EDIT_GRAPH, 2, &x2_pos, &y2_pos);
			
			x1 = RoundRealToNearestInteger(MIN(x1_pos, x2_pos));
			y1 = RoundRealToNearestInteger(MIN(y1_pos, y2_pos));
			x2 = RoundRealToNearestInteger(MAX(x1_pos, x2_pos));
			y2 = RoundRealToNearestInteger(MAX(y1_pos, y2_pos));
			
			/* make sure we're not out of bounds */
			x1 = MAX(x1, XMIN);
			x2 = MIN(x2, XMAX);
			y1 = MAX(y1, YMIN);
			y2 = MIN(y2, YMAX);
			
			/* go through the selected pixels and look for data */
			for (ix = x1; ix <= x2; ix++)
				for (iy = y1; iy <= y2; iy++)
					if (graph->phead[ix][iy][ip].count > 0)
						graph->phead[ix][iy][ip].excluded = 1;
			
			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			UpdateCurveDisplay (callbackData, panel, ig);
			Plot(callbackData);

			break;
		}
	return 0;
}

int CVICALLBACK reset_exclude (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	datastruct *dat;
	char compare[100];
	graphstruct *graph;

	int		ig, ip, ix, iy;
	
	switch (event)
		{
		case EVENT_COMMIT:
			dat = (datastruct*) callbackData;
			
			/* Set ig based on title of panel so values are correctly saved for each air mass. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Err adjustment corrupted.");
			graph = &dat->graphs[ig];

			/* get the panel */
			ip = dat->selPlane;
			
			/* go through all pixels and set to unexcluded */
			for (ix = XMIN; ix < XMAX; ix++)
				for (iy = YMIN; iy < YMAX; iy++)
					graph->phead[ix][iy][ip].excluded = 0;
			
			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			UpdateCurveDisplay (callbackData, panel, ig);
			Plot(callbackData);

			break;
		}
	return 0;
}

int CVICALLBACK quitlist (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			DiscardPanel(listpan);

			break;
		}
	return 0;
}

void CVICALLBACK menu_quitlist (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	DiscardPanel(listpan);
}

void CVICALLBACK list_save (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	char path[MAX_PATHNAME_LEN], *str;
	FILE *outfile;
	
	int retval, str_len;
	
	
	retval = FileSelectPopup ("", "*.*", "", "List File", VAL_SAVE_BUTTON, 0, 0, 1,
					 1, path);
					 
	if (retval != VAL_NO_FILE_SELECTED)
	{
		if ((outfile = fopen(path, "wt")) == NULL)
			nonfatal_error(FILE_OPEN_ERROR, "list_save");
		else
		{
			GetCtrlAttribute (listpan, LISTPAN_DATALIST, ATTR_STRING_TEXT_LENGTH,
							  &str_len);
			
			/* print the header */
			fprintf(outfile, " Zen  |  Kt   |  Kn   |  Kd   | Data ---->\n");
			
			if (str_len > 0)
			{
				
				if ((str = CNEW(str_len+1, char)) == NULL)
					nonfatal_error(MEM_ALLOC_ERROR, "list_save");
				else
				{
					GetCtrlVal(listpan, LISTPAN_DATALIST, str);
					fputs(str, outfile);
				}
			}
			fclose(outfile);
			free(str);
		}
	}
}

