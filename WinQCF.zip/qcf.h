/****************************************************************************\

	QC Fit header file
	
	Author:  Jeremy Cook, Steve Wilcox
	
	Date:  2003-07-03
	
	Description: All global structure definitions and define statements.

\****************************************************************************/
#ifndef __qcf_header
#define __qcf_header
#include "solpos00.h"
#include <userint.h>
#include <time.h>


#define VERSION "0.28"
#define CNEW(n,x) (x*) calloc(n, sizeof(x))  /* shorthand memory allocations */
#define MAX(x,y) ((x) > (y) ? (x) : (y))
#define MIN(x,y) ((x) < (y) ? (x) : (y))
#define GRAPH_CNT 3
#define PLANE_CNT 3
#define XSIZE 102
#define YSIZE 102
#define XMAX 100
#define YMAX 100
#define XMIN 2
#define YMIN 2
#define FEOF 1
#define CANCEL 2
#define MISS_VAL 9000.0
#define MISS_K 9900.0
#define MISS_PIX 101
#define LOW_TITLE " - Low Air Mass - QCFIT"
#define MED_TITLE " - Medium Air Mass - QCFIT"
#define HI_TITLE  " - High Air Mass - QCFIT"
#define FORMAT "%d %d %d %d %d %f %f %f %s" // trailing string is to capture bad data
#define DENSITY_RANGE 6						// 5 density ranges plus 1 year select range
#define ZEN_MAX 80.0
#define DEN_0_IN	0xFF5328
#define DEN_1_IN	0xFF8533
#define DEN_2_IN	0xFFB75A
#define DEN_3_IN	0xFFD750
#define DEN_4_IN	0xFFF000
#define DEN_Y_IN	VAL_CYAN
#define DEN_0_OUT	0xB4351C	 
#define DEN_1_OUT	0xB45A23
#define DEN_2_OUT	0xB47D44
#define DEN_3_OUT	0xB49B46
#define DEN_4_OUT	0xCCB400
#define DEN_Y_OUT	VAL_BLUE
#define TEMPFILE "qc0_temp.$$$"
#define DFLT_0 "DEFAULT CONFIGURATION"
#define DFLT_1 "Integration (minutes):"
#define DFLT_2 "Data Folder:"
#define DFLT_3 "Plane:"
#define DFLT_4 "3-Component Filter:"


typedef struct
{
	float 	*xData;
	float 	*yData;
	int		colors[GRAPH_CNT];
	int		dat_cnt;
	int		binmax;
	float	keydatX[GRAPH_CNT][2];
	float	keydatY[GRAPH_CNT][2];
	int		key_cnt[GRAPH_CNT];
} freqplotstruct;

struct monthfilestruct
{
	int  filenum;
	long begptr;
	long endptr;
	struct monthfilestruct *next;
};

typedef struct
{
	char **MFileName;
	int  numFiles;
	int  passflg;
	struct monthfilestruct monthfiles[12];
} filestruct;

typedef struct 
{
	int yr;
	int mon;
	int day;
	int hr;
	int min;
	int sec;
	float glo;
	float dir;
	float dif;
	long int fp;
}QCFlinestruct;

typedef struct
{
	int QCF_flag;
	int QC0_flag;
	int FirstFileLoad;
	int NewSitePath;
	int NewSiteID;
	int NewSiteCreated;
} flagstruct;

struct datalist
{
	float kt;
	float kn;
	float kd;
	int   excluded;
	int   filenum;
	long int fileptr;
	float solzen;
	time_t date;
	struct datalist *dat_next[3];
	struct datalist *rpt_next;
};

typedef struct
{
	int count;
	int bndry_flg;
	int density_val;
	int excluded;
	int selected;
	char *years;
	struct datalist *dathead;
	struct datalist *dattail;
} pixelheader;

typedef struct
{
	int pixelMax;
	int pixelMin;
	char range[PLANE_CNT][DENSITY_RANGE-1][20];
	int d_func;
	float factor;
} densitystruct;

typedef struct
{
	char	cnt_active[20];
	char	cnt_invalid[20];
	char	cnt_total[20];
	char	cnt_inside[20];
	char	cnt_outside[20];
	char	error_out[20];
	char	error_rgt[20];
	char	error_lft[20];
} statstruct;

typedef struct
{
    pixelheader ***phead;
    int pix_count[PLANE_CNT][DENSITY_RANGE][2];	// three planes x five density ranges by boundary status
    int *xData[DENSITY_RANGE][2];
    int *yData[DENSITY_RANGE][2];
	struct datalist *rpthead;
	statstruct stats[PLANE_CNT];
} graphstruct;

typedef struct
{
	char Site[20];
	char *site_desc;
	double Lat;
	double Lon;
	double TZone;
} sitestruct;

typedef struct
{
	char QC0_FileName[MAX_PATHNAME_LEN];
	int Month;
	int Max_kn;
	int Max_kt[4];
	int LeftShape[3];
	int LeftPos[3];
	int RightShape[3];
	int RightPos[3][4];
	int RightPosIndex;
	float Scale;
	int chngflg;
} qczstruct;

struct listfilestruct
{
	char FilePath[MAX_PATHNAME_LEN];
	struct listfilestruct *next;
};

/* main data structure */
typedef struct
{
	graphstruct graphs[3];
	sitestruct	site_dat;
	filestruct	file_dat;
	qczstruct	qcz_dat;
	flagstruct	flags;
	densitystruct density;
	freqplotstruct freqplot;
	char dat_Folder[MAX_PATHNAME_LEN];
	char qc0_Folder[MAX_PATHNAME_LEN];
	struct listfilestruct *filelist_dat;
	struct posdata *soldat;
	int selPlane;									// selected plane
	char *years;									// yearlist for year control
	int cmdline;									// flag for command line use
}datastruct;

//static ToolbarType EditToolbar;

/* air mass range enum */
enum {LOW, 
	  MED, 
	  HI};

/* density algorithms */
enum {DENS_OFF,
	  DENS_EQ_FREQ,
	  DENS_EQ_RANGE,
	  DENS_EXPONENTIAL};
	  
enum {OFF,ON};

enum savetype {SAVE_YES, SAVE_DISCARD, SAVE_CANCEL};

enum kspacetype {KT, KN, K_CNT};

#endif

