/****************************************************************************\

	QCF Module boundary
	
	Author:  Steve Wilcox, Jeremy Cook
	
	Date:  2003-07-23
	
	Description: Provides boundary setting and detecting functions.

\****************************************************************************/
#include <ansi_c.h>
#include <utility.h>
#include "qcf.h"
#include "qcf_bndry.h"
#include "qcf_err.h"
extern int am_throt[K_CNT][GRAPH_CNT];

enum error_type {NON_OUT, INV_OUT, MAX_OUT, RGT_OUT, LFT_OUT, ACT_OUT, ERR_MAX}; 

float curveLeft[6][100] = {
     {-60.0,-60.0,13.1,14.6, 15.8, 16.9, 17.9, 18.7, 19.6, 20.3,
     21.0, 21.7, 22.3, 22.9, 23.5, 24.1, 24.7, 25.2, 25.7, 26.2,
     26.7, 27.2, 27.7, 28.2, 28.6, 29.1, 29.5, 30.0, 30.4, 30.8,
     31.3, 31.7, 32.1, 32.5, 33.0, 33.4, 33.8, 34.2, 34.6, 35.0,
     35.4, 35.8, 36.2, 36.6, 37.0, 37.4, 37.8, 38.2, 38.6, 39.0,
     39.4, 39.8, 40.2, 40.6, 41.0, 41.4, 41.9, 42.3, 42.7, 43.1,
     43.5, 43.9, 44.4, 44.8, 45.2, 45.7, 46.1, 46.5, 47.0, 47.4,
     47.9, 48.3, 48.8, 49.3, 49.7, 50.2, 50.7, 51.2, 51.7, 52.2,
     52.7, 53.3, 53.8, 54.3, 54.9, 55.4, 56.0, 56.6, 57.2, 57.8,
     58.4, 59.1, 59.7, 60.4, 61.1, 61.8, 62.5, 63.3, 64.0, 64.8},

     {-60.0,-60.0,10.3,11.9, 13.3, 14.6, 15.7, 16.6, 17.6, 18.4,
     19.2, 20.0, 20.7, 21.4, 22.1, 22.7, 23.3, 24.0, 24.5, 25.1,
     25.7, 26.2, 26.8, 27.3, 27.8, 28.3, 28.8, 29.3, 29.8, 30.3,
     30.8, 31.3, 31.8, 32.2, 32.7, 33.2, 33.6, 34.1, 34.5, 35.0,
     35.5, 35.9, 36.4, 36.8, 37.3, 37.7, 38.2, 38.6, 39.1, 39.5,
     40.0, 40.4, 40.9, 41.3, 41.8, 42.2, 42.7, 43.2, 43.6, 44.1,
     44.6, 45.0, 45.5, 46.0, 46.5, 46.9, 47.4, 47.9, 48.4, 48.9,
     49.4, 49.9, 50.5, 51.0, 51.5, 52.0, 52.6, 53.1, 53.7, 54.2,
     54.8, 55.4, 56.0, 56.6, 57.2, 57.8, 58.4, 59.1, 59.7, 60.4,
     61.1, 61.8, 62.5, 63.2, 64.0, 64.8, 65.5, 66.4, 67.2, 68.1},

     {-60.0,-60.0,3.9,  6.1,  7.9,  9.4, 10.8, 12.1, 13.3, 14.3,
     15.4, 16.3, 17.3, 18.1, 19.0, 19.8, 20.6, 21.3, 22.1, 22.8,
     23.5, 24.2, 24.9, 25.5, 26.2, 26.8, 27.4, 28.1, 28.7, 29.3,
     29.9, 30.5, 31.0, 31.6, 32.2, 32.8, 33.3, 33.9, 34.4, 35.0,
     35.5, 36.1, 36.6, 37.2, 37.7, 38.3, 38.8, 39.3, 39.9, 40.4,
     40.9, 41.5, 42.0, 42.6, 43.1, 43.6, 44.2, 44.7, 45.2, 45.8,
     46.3, 46.9, 47.4, 48.0, 48.5, 49.1, 49.6, 50.2, 50.7, 51.3,
     51.9, 52.4, 53.0, 53.6, 54.2, 54.8, 55.3, 55.9, 56.5, 57.1,
     57.8, 58.4, 59.0, 59.6, 60.3, 60.9, 61.6, 62.2, 62.9, 63.6,
     64.3, 65.0, 65.7, 66.4, 67.1, 67.9, 68.6, 69.4, 70.1, 70.9},

     {-60.0,-60.0,-4.5,-1.7,  0.6,  2.7,  4.5,  6.1,  7.6,  9.0,
     10.3, 11.5, 12.7, 13.8, 14.9, 15.9, 16.9, 17.9, 18.9, 19.8,
     20.7, 21.5, 22.4, 23.2, 24.0, 24.8, 25.6, 26.4, 27.2, 27.9,
     28.7, 29.4, 30.1, 30.8, 31.5, 32.2, 32.9, 33.6, 34.3, 35.0,
     35.7, 36.4, 37.0, 37.7, 38.3, 39.0, 39.7, 40.3, 41.0, 41.6,
     42.3, 42.9, 43.6, 44.2, 44.9, 45.5, 46.1, 46.8, 47.4, 48.1,
     48.7, 49.4, 50.0, 50.6, 51.3, 51.9, 52.6, 53.2, 53.9, 54.6,
     55.2, 55.9, 56.5, 57.2, 57.9, 58.5, 59.2, 59.9, 60.6, 61.3,
     62.0, 62.7, 63.4, 64.1, 64.8, 65.5, 66.2, 66.9, 67.7, 68.4,
     69.1, 69.9, 70.7, 71.4, 72.2, 73.0, 73.8, 74.6, 75.4, 76.2},

     {-60.0,-60.0,1.3,  3.5,  5.4,  7.0,  8.5,  9.8, 11.1, 12.2,
     13.3, 14.3, 15.3, 16.3, 17.2, 18.0, 18.9, 19.7, 20.5, 21.3,
     22.1, 22.8, 23.6, 24.3, 25.0, 25.7, 26.4, 27.1, 27.8, 28.5,
     29.1, 29.8, 30.5, 31.1, 31.8, 32.4, 33.1, 33.7, 34.4, 35.0,
     35.6, 36.3, 36.9, 37.6, 38.2, 38.8, 39.5, 40.1, 40.8, 41.4,
     42.1, 42.7, 43.4, 44.0, 44.7, 45.4, 46.0, 46.7, 47.4, 48.1,
     48.8, 49.5, 50.2, 50.9, 51.6, 52.3, 53.1, 53.8, 54.6, 55.3,
     56.1, 56.9, 57.7, 58.5, 59.3, 60.2, 61.0, 61.9, 62.8, 63.7,
     64.6, 65.6, 66.5, 67.5, 68.5, 69.6, 70.6, 71.7, 72.9, 74.0,
     75.2, 76.5, 77.8, 79.1, 80.5, 82.0, 83.5, 85.1, 86.8, 88.5},

     {-60.0,-60.0,5.6,  7.5,  9.0, 10.4, 11.6, 12.7, 13.8, 14.7,
     15.6, 16.5, 17.4, 18.2, 18.9, 19.7, 20.4, 21.2, 21.9, 22.5,
     23.2, 23.9, 24.5, 25.2, 25.8, 26.4, 27.1, 27.7, 28.3, 28.9,
     29.5, 30.1, 30.8, 31.4, 32.0, 32.6, 33.2, 33.8, 34.4, 35.0,
     35.6, 36.2, 36.8, 37.5, 38.1, 38.7, 39.4, 40.0, 40.6, 41.3,
     42.0, 42.6, 43.3, 44.0, 44.7, 45.4, 46.1, 46.8, 47.6, 48.3,
     49.1, 49.9, 50.7, 51.5, 52.3, 53.2, 54.1, 55.0, 55.9, 56.9,
     57.8, 58.9, 59.9, 61.0, 62.2, 63.4, 64.6, 65.9, 67.3, 68.7,
     70.3, 71.9, 73.6, 75.5, 77.5, 79.7, 82.2, 84.9, 88.0, 91.5,
     95.8,101.0,107.8,117.8,136.8,999.9,999.9,999.9,999.9,999.9}
};

float curveRight[5][100] = {
     {13.4,17.2, 19.6, 21.5, 23.1, 24.5, 25.8, 26.9, 27.9, 28.9,
     29.8, 30.7, 31.5, 32.3, 33.0, 33.8, 34.5, 35.1, 35.8, 36.5,
     37.1, 37.7, 38.3, 38.9, 39.5, 40.1, 40.6, 41.2, 41.7, 42.3,
     42.8, 43.4, 43.9, 44.4, 44.9, 45.5, 46.0, 46.5, 47.0, 47.5,
     48.0, 48.5, 49.0, 49.5, 50.0, 50.5, 51.0, 51.5, 52.0, 52.5,
     53.0, 53.5, 54.0, 54.5, 55.0, 55.5, 56.0, 56.5, 57.0, 57.5,
     58.0, 58.5, 59.0, 59.5, 60.1, 60.6, 61.1, 61.6, 62.2, 62.7,
     63.2, 63.8, 64.3, 64.9, 65.5, 66.0, 66.6, 67.2, 67.8, 68.4,
     69.0, 69.6, 70.2, 70.8, 71.4, 72.1, 72.7, 73.4, 74.1, 74.7,
     75.4, 76.1, 76.9, 77.6, 78.3, 79.1, 79.9, 80.7, 81.5, 82.4},

     {18.1,21.2, 23.3, 24.9, 26.3, 27.5, 28.5, 29.5, 30.4, 31.2,
     32.0, 32.7, 33.4, 34.1, 34.7, 35.4, 36.0, 36.6, 37.1, 37.7,
     38.3, 38.8, 39.3, 39.8, 40.4, 40.9, 41.4, 41.9, 42.4, 42.8,
     43.3, 43.8, 44.3, 44.7, 45.2, 45.7, 46.1, 46.6, 47.0, 47.5,
     48.0, 48.4, 48.9, 49.3, 49.8, 50.2, 50.7, 51.2, 51.6, 52.1,
     52.5, 53.0, 53.5, 53.9, 54.4, 54.9, 55.3, 55.8, 56.3, 56.8,
     57.3, 57.8, 58.3, 58.8, 59.3, 59.8, 60.3, 60.8, 61.4, 61.9,
     62.4, 63.0, 63.6, 64.1, 64.7, 65.3, 65.9, 66.5, 67.1, 67.7,
     68.4, 69.0, 69.7, 70.4, 71.1, 71.8, 72.5, 73.3, 74.1, 74.9,
     75.7, 76.5, 77.4, 78.3, 79.3, 80.2, 81.2, 82.3, 83.4, 84.6},

     {22.8,25.3, 27.0, 28.4, 29.5, 30.4, 31.3, 32.1, 32.8, 33.5,
     34.2, 34.8, 35.4, 36.0, 36.5, 37.0, 37.5, 38.1, 38.5, 39.0,
     39.5, 39.9, 40.4, 40.8, 41.3, 41.7, 42.1, 42.6, 43.0, 43.4,
     43.8, 44.2, 44.7, 45.1, 45.5, 45.9, 46.3, 46.7, 47.1, 47.5,
     47.9, 48.3, 48.7, 49.1, 49.5, 49.9, 50.4, 50.8, 51.2, 51.6,
     52.0, 52.5, 52.9, 53.3, 53.8, 54.2, 54.6, 55.1, 55.6, 56.0,
     56.5, 57.0, 57.4, 57.9, 58.4, 58.9, 59.4, 60.0, 60.5, 61.0,
     61.6, 62.1, 62.7, 63.3, 63.9, 64.5, 65.2, 65.8, 66.5, 67.2,
     67.9, 68.7, 69.4, 70.2, 71.1, 72.0, 72.9, 73.8, 74.8, 75.9,
     77.0, 78.2, 79.5, 80.9, 82.4, 84.0, 85.9, 87.9, 90.2, 92.8},

     {28.0,29.9, 31.3, 32.3, 33.2, 33.9, 34.6, 35.2, 35.8, 36.4,
     36.9, 37.4, 37.8, 38.3, 38.7, 39.1, 39.5, 39.9, 40.3, 40.7,
     41.1, 41.4, 41.8, 42.2, 42.5, 42.8, 43.2, 43.5, 43.9, 44.2,
     44.5, 44.9, 45.2, 45.5, 45.9, 46.2, 46.5, 46.8, 47.2, 47.5,
     47.8, 48.2, 48.5, 48.8, 49.2, 49.5, 49.8, 50.2, 50.5, 50.9,
     51.2, 51.6, 51.9, 52.3, 52.6, 53.0, 53.4, 53.7, 54.1, 54.5,
     54.9, 55.3, 55.7, 56.1, 56.5, 57.0, 57.4, 57.9, 58.3, 58.8,
     59.3, 59.8, 60.3, 60.8, 61.3, 61.9, 62.5, 63.1, 63.7, 64.3,
     65.0, 65.7, 66.4, 67.2, 68.0, 68.9, 69.8, 70.8, 71.8, 72.9,
     74.2, 75.5, 77.0, 78.8, 80.7, 83.0, 85.9, 89.6, 94.8,103.9},

     {32.2,33.7, 34.8, 35.6, 36.3, 36.9, 37.4, 37.9, 38.3, 38.7,
     39.1, 39.5, 39.9, 40.2, 40.6, 40.9, 41.2, 41.5, 41.8, 42.1,
     42.4, 42.7, 43.0, 43.3, 43.6, 43.8, 44.1, 44.4, 44.6, 44.9,
     45.2, 45.4, 45.7, 45.9, 46.2, 46.5, 46.7, 47.0, 47.2, 47.5,
     47.8, 48.0, 48.3, 48.5, 48.8, 49.1, 49.3, 49.6, 49.9, 50.2,
     50.4, 50.7, 51.0, 51.3, 51.6, 51.9, 52.2, 52.5, 52.8, 53.1,
     53.4, 53.7, 54.1, 54.4, 54.7, 55.1, 55.5, 55.8, 56.2, 56.6,
     57.0, 57.4, 57.8, 58.2, 58.7, 59.2, 59.6, 60.1, 60.7, 61.2,
     61.8, 62.4, 63.0, 63.7, 64.4, 65.2, 66.0, 66.9, 67.8, 68.9,
     70.1, 71.4, 73.0, 74.8, 77.0, 80.0, 84.2, 91.9,999.9,999.9}
};


/****************************************************************************\

	Function: curve_x()
	  Author: Steve Wilcox,
	    Date: 2003-07-23
	
 Description: For a given y coordinate, returns the x coordinate of the
 			  specified curve.
 			  
	  Inputs: curve side (right or left as RGT_CUR or LFT_CUR), y coordinate,
	  		  the curve number, and the curve position. (all inputs are 1-based:
	  		  Y goes from 1 to 99; curve goes from 1 to 5 (R) or 1-6 (L), and
	  		  postition goes from 1-20;
	 
	 Outputs: The x coordinate of the specified curve boundary. Returns -1 on
	 		  error.
	
\****************************************************************************/
int curve_x(int side, int y, int curve, int position)
{
	int x, retval;
	
	retval = 0; // initialize to zero for no errors
	
	/* look for parameter errors */
	if (y < 1 || y > 99 || curve < 1 || position < 1 || position > 20)
		retval = -1;
	
	if (retval == 0)
	{
		/* choose sides and calculate x coordinate (check for curve errors) */
		if (side == RGT_CUR)
		{
			if (curve > 5)
				retval = -1;
			else
				x = RoundRealToNearestInteger (curveRight[curve-1][y-1]);
		}
		else
		{
			if (curve > 6 )
				retval = -1;
			else
				x = RoundRealToNearestInteger (curveLeft[curve-1][y-1]);
		}

		/* if no errors in retval, add the offset and bound the coordinate */
		if (retval == 0) // no errors
			retval =  MAX(MIN(x + (position-1)*2.5, 100), 0);
	}
	
	return retval;
}



/****************************************************************************\

	Function: in_bounds()
	  Author: Steve Wilcox,
	    Date: 2003-07-23
	
 Description: For a given xy pair and curve x coordinates and kt/kn maximums,
 			  returns a boolean for whether the xy pair is in bounds..
 			  
	  Inputs: Pixel x and y, right and left curve x values, and kt and kn
	  		  maximums.
	 
	 Outputs: Zero if out of bounds; One if in bounds.
	
\****************************************************************************/
int in_bounds(int pix_x, int pix_y, int rx, int lx, int kt, int kn)
{
	int error_code;
	
	error_code = NON_OUT;

	/* look at the left and right sides first */
	if (pix_x < lx)
			error_code = LFT_OUT;
	else if (pix_x > rx)
		error_code = RGT_OUT;
		
 	/* override with any max errors */
	if (pix_y > kn || pix_x > kt)
		error_code = MAX_OUT;
	
	return error_code;
	
//	return (pix_x >= lx && pix_x <= rx && pix_y <= kn && pix_x <= kt) ? 1 : 0;
}


/****************************************************************************\

	Function: bndry_status()
	  Author: Steve Wilcox,
	    Date: 2003-07-23
	
 Description: For a given xy pair and curve x coordinates and kt/kn maximums,
 			  returns a boolean for whether the xy pair is in bounds..
 			  
	  Inputs: Pixel x and y, right and left curve x values, and kt and kn
	  		  maximums.
	 
	 Outputs: Zero if out of bounds; One if in bounds.
	
\****************************************************************************/
void BndryStatus(void *callbackData)
{
	int	ig, 	  /* graph index */
		ix, 	  /* x axis index */
		iy, 	  /* y axis index */
		ip, 	  /* plane index */
		kt_max,   /* kt max from qc0 */
		kn_max,   /* kn max from qc0 */
		rs, 	  /* right shape from qc0 */
		ls, 	  /* left shape from qc0 */
		rp, 	  /* right position from qc0 */
		lp, 	  /* left position from qc0 */
		rpi, 	  /* right position index from integration time */
		lx, 	  /* left curve x value for given y */
		rx,		  /* right curve x value for given y */
		i,		  /* utility integer */
		status,	  /* boundary status code (see error_type enumeration */
		active_cnt,/* total of all pixels examined (below the diagonal) */
		error_cnt[ERR_MAX];  /* error counter */
	
	pixelheader *pixel;
	datastruct *dat;
	statstruct *stats;
	qczstruct *qc0; /* short cut to qc0 stuff */
	
	dat = (datastruct*)callbackData;
	
	/* point to the qc0 stuff */
	qc0 = &dat->qcz_dat;
	
	/* get the qc0 values common to all graphs */
	rpi		= qc0->RightPosIndex;
	
	
	/* loop through all graphs */
	for (ig = 0; ig < GRAPH_CNT; ig++)
	{
		/* get qc0 stuff specific to each graph */
		rs		= qc0->RightShape[ig];
		ls		= qc0->LeftShape[ig];
		rp		= qc0->RightPos[ig][rpi];
		lp		= qc0->LeftPos[ig];
		kn_max	= qc0->Max_kn;
		kt_max	= qc0->Max_kt[rpi];
	
		/* make sure that the QC0 file provides needed information */
		if (rs > 0 && ls > 0 && rp > 0 && lp > 0 && kn_max > 0 && kt_max > 0)
		{
			/* reduce maximums according to the airmass */
			kn_max -= am_throt[KN][ig];
			kt_max -= am_throt[KT][ig];
			
			for (ip = 0; ip < PLANE_CNT; ip++)
			{
		
				/* initialize counters */
				for (i = 0; i < ERR_MAX; i++)
					error_cnt[i] = 0;
				active_cnt = 0;
		
				/* loop through y axis, skipping the perimeter row and column */
				for (iy = YMIN; iy < YMAX; iy++)
				{
					/* determine the x boundary coordinates for each line */
					lx = curve_x(LFT_CUR, iy, ls, lp);
					rx = curve_x(RGT_CUR, iy, rs, rp);
			
					if (lx < 0 || rx < 0)
					{
						fatal_error(INTERNAL_ERROR, "Curve out of bounds");
						break;
					}
					else
					{
						/* loop through the pixels on the line and mark the boundary status */
						for (ix = XMIN; ix < XMAX; ix++)
						{
							pixel = &dat->graphs[ig].phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
							{
								status = in_bounds(ix, iy, rx, lx, kt_max, kn_max);
								if (ix > iy)
								{
									active_cnt += pixel->count;

									switch (status)
									{
										case RGT_OUT:
											error_cnt[RGT_OUT]+= pixel->count;
											error_cnt[ACT_OUT]+= pixel->count;
											break;
										
										case LFT_OUT:
											error_cnt[LFT_OUT]+= pixel->count;
											error_cnt[ACT_OUT]+= pixel->count;
											break;
										
										case MAX_OUT:
											error_cnt[ACT_OUT]+= pixel->count;
											break;
										
										case NON_OUT:
											; // do nothing
									
									}
										
								}
								else
									error_cnt[INV_OUT]+= pixel->count;
								
								pixel->bndry_flg = status > 0 ? 0 : 1;
							}
						}
					}
				}
				
				
			 	stats = &dat->graphs[ig].stats[ip];
			 	
			 	sprintf(stats->cnt_active, "%d",	active_cnt);
			 	sprintf(stats->cnt_invalid, "%d",	error_cnt[INV_OUT]);
			 	sprintf(stats->cnt_total, "%d",		active_cnt + error_cnt[INV_OUT]);
			 	sprintf(stats->cnt_outside, "%d",	error_cnt[ACT_OUT]);
			 	sprintf(stats->cnt_inside, "%d",	active_cnt - error_cnt[ACT_OUT]);
			 	sprintf(stats->error_out, "%0.1f",	(float)error_cnt[ACT_OUT] / (float)MAX(active_cnt, 1) * 100.0);
			 	sprintf(stats->error_lft, "%0.1f",	(float)error_cnt[LFT_OUT] / (float)MAX(active_cnt, 1) * 100.0);
			 	sprintf(stats->error_rgt, "%0.1f",	(float)error_cnt[RGT_OUT] / (float)MAX(active_cnt, 1) * 100.0);
			 	
			 	
//printf("G%dP%d ACT %s INV %s TOT %s OUT %s IN %s EOUT %s ELFT %s ERGT %s\n",
 //ig, ip, stats->cnt_active, stats->cnt_invalid, stats->cnt_total, stats->cnt_outside, 
 //stats->cnt_inside, stats->error_out, stats->error_lft, stats->error_rgt);
			}
		}
		else /* set the stats for no data */
		{
			for (ip = 0; ip < PLANE_CNT; ip++)
			{
				stats = &dat->graphs[ig].stats[ip];
			 	
			 	sprintf(stats->cnt_active, "%d",	0);
			 	sprintf(stats->cnt_invalid, "%d",	0);
			 	sprintf(stats->cnt_total, "%d",		0);
			 	sprintf(stats->cnt_outside, "%d",	0);
			 	sprintf(stats->cnt_inside, "%d",	0);
			 	sprintf(stats->error_out, "%0.1f",	0.0);
			 	sprintf(stats->error_lft, "%0.1f",	0.0);
			 	sprintf(stats->error_rgt, "%0.1f",	0.0);
			 }
		}
	}
}

/****************************************************************************\

	Function: plot_boundary()
	  Author: Steve Wilcox,
	    Date: 2003-07-24
	
 Description: Plots the gompertz boundarys and kt/kn maximums
 			  
	  Inputs: data struct, graph index (airmass), graph panel, graph control
	 
	 Outputs: none
	
\****************************************************************************/
void plot_boundary(datastruct *dat, int graph, int panel, int control)
{
	int ix, 	  /* x axis index */
		iy, 	  /* y axis index */
		lx,		  /* left boundary x value */
		kt_max,   /* kt max from qc0 */
		kn_max,   /* kn max from qc0 */
		y_max,	  /* maximum y for either curve */
		rs, 	  /* right shape from qc0 */
		ls, 	  /* left shape from qc0 */
		rp, 	  /* right position from qc0 */
		lp, 	  /* left position from qc0 */
		rpi, 	  /* right position index from integration time */
		ndx,	  /* data array index and counter */
		x_ary[202], /* x coordinate array */
		y_ary[202]; /* y coordinate array */
		
	qczstruct *qc0; /* short cut to qc0 stuff */

	/* point to the qc0 data */
	qc0 = &dat->qcz_dat;
	
	/* get the qc0 values common to all graphs */
	rpi		= qc0->RightPosIndex;
	kn_max	= qc0->Max_kn;
	kt_max	= qc0->Max_kt[rpi];
	
	/* reduce maximums according to the airmass */
	kn_max -= am_throt[KN][graph];
	kt_max -= am_throt[KT][graph];
		
	/* get the remaining boundar information */
	rs = qc0->RightShape[graph];
	ls = qc0->LeftShape[graph];
	rp = qc0->RightPos[graph][rpi];
	lp = qc0->LeftPos[graph];
	
	ndx = 0;
	
	/* make sure that there's something to plot */
	if (rs > 0 && ls > 0 && rp > 0 && lp > 0 && kt_max > 0 && kn_max > 0)
	{
		/* do the right curve as far as the intersection with kt_max or the left curve */	
		x_ary[ndx] = curve_x(RGT_CUR, 1, rs, rp);
		y_ary[ndx] = 1;
	
		for (iy = 2; iy < kn_max; iy++)
		{
			ix = curve_x(RGT_CUR, iy, rs, rp);
			lx = curve_x(LFT_CUR, iy, ls, lp);
			if (lx <= ix)
			{
				x_ary[ndx] = ix;
				y_ary[ndx] = iy;
				ndx++;
			}
			else
				break;
		
			if (ix >= kt_max)
				break;
		}
		
		/* determine the upper bound of the left curve */
		y_max = lx == ix ? iy-1 : kn_max;
		while (curve_x(LFT_CUR, y_max, ls, lp) >= kt_max)
			y_max--;
				
	
		/* draw the kt_max and kn_max lines, if they exist */
		if (lx < ix)
		{
			x_ary[ndx] = ix;
			y_ary[ndx] = y_max;
			ndx++;
		
			/* draw the kn_max line */
			if (kn_max > y_max && lx < kt_max)
			{
				x_ary[ndx] = curve_x(LFT_CUR, y_max, ls, lp);
				y_ary[ndx] = y_max;
				ndx++;
			}
		}

		/* do the left curve from kn_max to the bottom */
		for (iy = y_max; iy > 0; iy--)
		{
			x_ary[ndx] = curve_x(LFT_CUR, iy, ls, lp);
			y_ary[ndx] = iy;
			ndx++;
		}
	
	
	
		PlotXY (panel, control, x_ary, y_ary, ndx, VAL_INTEGER,
				VAL_INTEGER, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1,
				VAL_BLACK);
	}
}

		
/****************************************************************************\

	Function: auto_fit()
	  Author: Steve Wilcox,
	    Date: 2003-07-26
	
 Description: Does an autofit of the data envelope
 			  
	  Inputs: data struct, graph index (airmass), plane, scaling factor
	 
	 Outputs: revised QC0 structure
	 
	   Notes: Modeled after Martin Rymes' fitting algorithm from the original
	   		  QCFIT Fortran program. Here I include fitting for kt_max and
	   		  kn_max.
	
\****************************************************************************/
void autofit(datastruct *dat, int grph, int plane, float scale)
{
	int		i,			/* utility integer */
			ix, 		/* x axis index */
			iy, 		/* y axis index */
			kt_max,		/* kt max from qc0 */
			kn_max,		/* kn max from qc0 */
			rpi,		/* right position index from integration time */
			curve,		/* curve index */
			pos,		/* position index */
			best_curve, /* curve of best score */
			best_posit, /* position of best score */
			i_cur,		/* curve index */
			pix_total,	/* total pixels outside the curve */
			active,		/* total active data points */
			ysave,		/* previous notable y position while traversing axis */
			no_data,	/* flag indicating there are no data to evaluate */
			lol[XSIZE],	/* left data outline */
			rol[XSIZE];	/* right data outline */
		
	float	slope,		/* slope of the line */
			dat_count,	/* count of all data represented by all pixels */
			pix_count,  /* count of pixels with data */
			best_score, /* best of trial scores */
			score;		/* temporary score */
			
		
	qczstruct *qc0;	/* short cut to qc0 stuff */
	pixelheader ***pixel;
	
	/* point to the qc0 data */
	qc0 = &dat->qcz_dat;
	
	/* get the qc0 values common to all graphs */
	rpi		= qc0->RightPosIndex;
	kn_max	= 0;
	kt_max	= qc0->Max_kt[rpi];

	
	pixel = dat->graphs[grph].phead;
	no_data = 0;
	
	/* find kn max, starting at the top and moving down, scanning each line for the first data */
	for (iy = YMAX-1; iy >= YMIN; iy--)
	{
		for (ix = XMIN; ix < XMAX; ix++)
		{
			if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
			{
				kn_max = iy+1;
				break;
			}
		}
		if (kn_max == iy+1)
			break;
	}
	
	if (iy < YMIN)
		no_data = 1;
	else 
	{
		/* map to low airmass and save if exceeds existing max */
		qc0->Max_kn = MAX((kn_max + am_throt[KN][grph]), qc0->Max_kn);
		qc0->Max_kn = MIN(qc0->Max_kn, 99);
		kn_max = qc0->Max_kn; // used later in the routine
	}
		
	
	
	/* find kt max, starting at the right and moving left, scanning each column for the first data */
	if (!no_data)
	{
		if (kt_max == 0) // skip if already defined
		{
			for (ix = XMAX-1; ix >= XMIN; ix--)
			{
				for (iy = YMIN; iy < YMAX; iy++)
				{
					if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
					{
						kt_max = ix+1;
						break;
					}
				}
				if (kt_max == ix+1)
					break;
			}
			
			/* map to low airmass and save if exceeds existing max */
			qc0->Max_kt[rpi] = MAX((kt_max + am_throt[KT][grph]), qc0->Max_kt[rpi]);
			qc0->Max_kt[rpi] = MIN(kt_max, 99);
		}
	
		/* outline the left of the data envelope (keep track of data points also) */
		active = 0;
		for (iy = 0; iy < YMAX; iy++)
		{
			lol[iy] = -1;
			for (ix = 0; ix < XMAX; ix++)
			{
				if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
				{
					if (ix > iy)
						active++;
					if (lol[iy] < 0)
						lol[iy] = MAX(ix, iy); // keep it to the right of the diagnonal
				}
			}
		}
				
		/* outline the right of the data envelope */
		for (iy = 0; iy < YMAX; iy++)
		{
			rol[iy] = -1;
			for (ix = XMAX-1; ix >= XMIN; ix--)
				if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
				{
					rol[iy] = ix;
					break;
				}
		}
	
	
		/* interpolate gaps in the outline */
		/* LEFT side */
	
		/* find the first outline point */
		iy = YMIN;
		while (iy < YMAX && lol[iy] < 0)
			iy++;
	
		iy++;

		/* now work up the plot, interpolating as we go */
		while (iy < YMAX)
		{
			while (lol[iy] >= 0)  /* look for first missing data */
			{
				ysave = iy;
				iy++;
			}
		
			while (iy < YMAX && lol[iy] < 0) /* determine the gap */
				iy++;
		
			if (iy < YMAX) /* if the gap has an end, interpolate */
			{
				for (i = ysave+1; i < iy; i++)
				{
					slope = (float)(lol[iy] - lol[ysave]) / (float)(iy - ysave) ;
					lol[i] = RoundRealToNearestInteger(slope * (i - ysave) + lol[ysave]);
				}
			}
		}
	
		/* RIGHT side */
	
		/* find the first outline point */
		iy = YMIN;
		while (iy < YMAX && rol[iy] < 0)
			iy++;
	
		iy++;

		/* now work up the plot, interpolating as we go */
		while (iy < YMAX)
		{
			while (iy < YMAX && rol[iy] >= 0)  /* look for first missing data */
			{
				ysave = iy;
				iy++;
			}
		
			while (iy < YMAX && rol[iy] < 0) /* determine the gap */
				iy++;
		
			if (iy < YMAX) /* if the gap has an end, interpolate */
			{
				for (i = ysave+1; i < iy; i++)
				{
					slope = (float)(rol[iy] - rol[ysave]) / (float)(iy - ysave) ;
					rol[i] = RoundRealToNearestInteger(slope * (i - ysave) + lol[ysave]);
				}
			}
		}
	

		/* determine the best-fit LEFT curve */
		best_score = 1.0e40;
		best_curve = 0.0;
		best_posit = 0.0;
	
		/* examine all combinations of curves and positions */
		for (curve = 0; curve < 6; curve++)
		{
			for (pos = 0; pos < 20; pos++)
			{
				/* count the data points outside the boundary up to kn max */
				dat_count = 0.0;
				pix_count = 0.0;
				pix_total = 0;
			
				for (iy = YMIN; iy < kn_max; iy++)
				{
					if (lol[iy] > 0)
					{
						/* count the total data points represented by the pixel and the
						   total area from the left edge to the curve */
						i_cur = curve_x(LFT_CUR, iy+1, curve+1, pos+1);
						pix_total += (i_cur - XMIN);
						for (ix = lol[iy]; ix <= i_cur; ix++)
						{
							if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
								dat_count += pixel[ix][iy][plane].count;
						}
				
						/* get the count of pixels between the curve and outline */
						pix_count += abs(lol[iy] - i_cur);
					}
				}

	//printf("lc %2d, lp %2d, dc %4.0f pc %4.0f, scale %1.0f", curve+1, pos+1, dat_count, pix_count, scale);

				dat_count *= scale;
				dat_count /= (float)active;
			
				pix_count /= scale;
				pix_count /= (float)pix_total;
			
				score = dat_count + pix_count;
	//printf(" dc2 %0.4f, pc2 %0.4f, score %7.4f\n", dat_count, pix_count, score);
			
				if (score < best_score)
				{
					best_score = score;
					best_curve = curve;
					best_posit = pos;
				}
			}
		}
	
		qc0->LeftShape[grph]	= best_curve+1;
		qc0->LeftPos[grph]		= best_posit+1;
	
	//printf("Curve %d, Position %d\n", best_curve+1, best_posit+1);

		/* determine the best-fit RIGHT curve */
		best_score = 1.0e40;
		best_curve = 0.0;
		best_posit = 0.0;
	
		/* examine all combinations of curves and positions */
		for (curve = 0; curve < 5; curve++)
		{
			for (pos = 0; pos < 20; pos++)
			{
				/* count the data points outside the boundary up to kn max */
				dat_count = 0.0;
				pix_count = 0.0;
				pix_total = 0;
			
				for (iy = YMIN; iy < kn_max; iy++)
				{
					if (rol[iy] > 0)
					{
					/* count the total data points represented by the pixel and the total
					   pixels between the curve and the right edge */
						i_cur = curve_x(RGT_CUR, iy+1, curve+1, pos+1);
				
						/* don't consider points above intersection of curve and kt_max */      
						if (i_cur < kt_max) // don't consider points above intersection of curve and kt_max
						{
							pix_total += (XMAX - i_cur);
							for (ix = i_cur; ix <= rol[iy]; ix++)
							{
								if (pixel[ix][iy][plane].count > 0 && !pixel[ix][iy][plane].excluded)
									dat_count += pixel[ix][iy][plane].count;
							}
						}
				
						/* get the count of pixels between the curve and outline */
						pix_count += (float)abs(rol[iy] - i_cur);
					}
				}
			
	//printf("rc %2d, rp %2d, dc %4.0f pc %4.0f, scale %1.0f", curve+1, pos+1, dat_count, pix_count, scale);
				dat_count *= scale;
				dat_count /= (float)active;
			
				pix_count /= scale;
				pix_count /= (float)pix_total;
			
				score = dat_count + pix_count;
	//printf(" dc2 %0.4f, pc2 %0.4f, score %7.4f\n", dat_count, pix_count, score);
			
				if (score < best_score)
				{
					best_score = score;
					best_curve = curve;
					best_posit = pos;
				}
			}
		}
	
		/* save the results */
		qc0->RightShape[grph]		= best_curve+1;
		qc0->RightPos[grph][rpi]	= best_posit+1;
		
		/* bound the final values */
		qc0->Max_kn			= MAX(MIN(qc0->Max_kn,      (YMAX-1)), YMIN);
		qc0->Max_kt[rpi]	= MAX(MIN(qc0->Max_kt[rpi], (XMAX-1)), XMIN);
		
		qc0->chngflg = 1;
//printf("Curve %d, Position %d\n", best_curve+1, best_posit+1);
	}
}
	














