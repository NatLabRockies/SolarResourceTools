/****************************************************************************\

	QCF Module qcf_init
	
	Author:  Steve Wilcox, Jeremy Cook
	
	Date:  2003-07-03
	
	Description: Header file for the qcf_init.c module

\****************************************************************************/
#ifndef __qcf_misc_header
#define __qcf_misc_header

void str_trim(char *s);
int midsol(struct posdata *soldat);

#endif
