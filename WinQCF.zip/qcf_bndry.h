#ifndef __qcf_bndry_header
#define __qcf_bndry_header
enum curvetype {RGT_CUR, LFT_CUR};
void BndryStatus(void *callbackData);
void autofit(datastruct *dat, int grph, int plane, float scale);
void plot_boundary(datastruct *dat, int graph, int panel, int control);
#endif
