#ifndef __rcc_err_header
#define __rcc_err_header

enum error_codes {
MEM_ALLOC_ERROR,		// memory allocation
FILE_OPEN_ERROR,		// file open  
FILE_WRITE_ERROR,		// file write  
FILE_READ_ERROR,		// file read 
FILE_CLOSE_ERROR,		// file close 
SOLPOS_ERROR,			// SolPos error 
QC0_FORMAT_ERROR,		// QC0 file format
INTERNAL_ERROR,			// internal integrity error
GENERIC_ERROR,			// generic error
PLOT_INIT_ERROR};		// plot initialization

void fatal_error(int code, char *note);
void nonfatal_error(int code, char *note);
void advisory_error(int code , char *note);

#endif
