/****************************************************************************\

	QCF Module init
	
	Author:  Steve Wilcox, Jeremy Cook
	
	Date:  2003-07-03
	
	Description: Provides the QCFit initialization routines.

\****************************************************************************/
#include <ansi_c.h>
#include "qcf.h"
#include "qcf_init.h"
#include "qcf_err.h"


/*---------------------------------------------------------------------------*/
/* Initializes data structures.                                    			 */
/*---------------------------------------------------------------------------*/
int InitializeStructures (datastruct *dat)
{
	int ig, ix, iy, ip, id, i, // indices for Graphs, X axis, Y axis, and Plane
		i5;				// index for link planes
	
	int freq_colors[] = {VAL_RED, VAL_GREEN, VAL_CYAN};
	pixelheader *ph;
	
	/* allocate the three-dimensional pixelhead array one level at a time */
	/* phead array is accessed as phead[X][Y][Plane] */
	for (ig = 0; ig < GRAPH_CNT; ig++)
	{
		dat->graphs[ig].phead = CNEW(XSIZE, pixelheader**);  	  				// allocate x axis
		for (ix = 0; ix < XSIZE; ix++)
		{
			dat->graphs[ig].phead[ix] = CNEW(YSIZE, pixelheader*); 				// allocate y axis  
			for (iy = 0; iy < YSIZE; iy++)
				dat->graphs[ig].phead[ix][iy] = CNEW(PLANE_CNT, pixelheader);	// allocate planes 
		}
	}
	
	/* initialize the graph structure and subordinate structures */
	for (ig = 0; ig < GRAPH_CNT; ig++)				// graph (airmass)
	{
		/* initialize the report list head and tail */
		if ((dat->graphs[ig].rpthead = CNEW(1, struct datalist)) == NULL)
			fatal_error(MEM_ALLOC_ERROR, "Graph structure initialization");
		if ((dat->graphs[ig].rpthead->rpt_next = CNEW(1, struct datalist)) == NULL)
			;// error;
		dat->graphs[ig].rpthead->rpt_next->rpt_next	= NULL;
		dat->graphs[ig].rpthead->date				= 0;			/* low date */;
		dat->graphs[ig].rpthead->rpt_next->date		= 0xFFFFFFFF;	/* high date */;
		
		/* drill down through the pixel array to initialize each element */
		for (ix = 0; ix < XSIZE; ix++)				// x axix
			for (iy = 0; iy < YSIZE; iy++)			// y axis
				for (ip = 0; ip < PLANE_CNT; ip++)	// plane
				{
					/* Point to the full phead address rather than compute it (or type it) */
					ph = &dat->graphs[ig].phead[ix][iy][ip];
					
					/* initialize the pixel header variables */
					ph->count		= 0;
					ph->bndry_flg	= -1;
					ph->density_val	= -9900;
					ph->excluded	= 0;
					ph->selected	= 0;
					if ((ph->years = CNEW(1, char)) == NULL)
						;// error;
					
					strcpy(ph->years, "\0"); // empty string
					
					/* initialize the list with head and tail */
					if ((ph->dathead = CNEW(1, struct datalist)) == NULL)
						;// error;
		
					/* one tail record, but all three planes point to it */
					if ((ph->dathead->dat_next[0] = CNEW(1, struct datalist)) == NULL)
							;// error;

					for (i5 = 1; i5 < 3; i5++)  // do tail links for links 2 and 3
						ph->dathead->dat_next[i5] = ph->dathead->dat_next[0];

					/* null all three links on the tail */
					for (i5 = 0; i5 < 3; i5++)
						ph->dathead->dat_next[i5]->dat_next[i5] = NULL;
						
					/* keep a permanent pointer to the tail */
					ph->dattail = ph->dathead->dat_next[0];
					
					/* initialize the other fields in head and tail */
					ph->dathead->kt						= -9900.0;
					ph->dathead->kn						= -9900.0;
					ph->dathead->kd						= -9900.0;
					ph->dathead->filenum				= 0;
					ph->dathead->fileptr				= 0L;
					ph->dathead->solzen					= 0.0;
					ph->dathead->date					= 0;			/* low date */    
					
					ph->dathead->dat_next[0]->kt		= -9900.0; 
					ph->dathead->dat_next[0]->kn		= -9900.0; 
					ph->dathead->dat_next[0]->kd		= -9900.0; 
					ph->dathead->dat_next[0]->filenum	= 0;
					ph->dathead->dat_next[0]->fileptr	= 0L;
					ph->dathead->dat_next[0]->solzen	= 0.0;
					ph->dathead->dat_next[0]->date		= 0xFFFFFFFF;	/* high date */

				}
	}
	
	dat->soldat = CNEW(1, struct posdata);
	
	S_init (dat->soldat);
	
	/* initialize the solpos structure */
	dat->soldat->function &= ~S_DOY;		/* set solpos for month and day dates */
	dat->soldat->aspect		= 0.0;
	dat->soldat->tilt		= 0.0;
	dat->soldat->second		= 0;

	dat->filelist_dat = CNEW(1, struct listfilestruct);
	if (dat->filelist_dat == NULL)
		;//error
	
	dat->filelist_dat->next = CNEW(1, struct listfilestruct);
	if (dat->filelist_dat->next == NULL)
		;//error
		
	dat->filelist_dat->next->next = NULL;
	
	strcpy(dat->filelist_dat->FilePath, "");
	strcpy(dat->filelist_dat->next->FilePath, "");
	
	strcpy(dat->dat_Folder, "");
	strcpy(dat->qc0_Folder, "");
	
	/* initialize the flags structure elements */
	dat->flags.QCF_flag 		= 0;
	dat->flags.QC0_flag 		= 0;
	dat->flags.FirstFileLoad 	= 1;
	dat->flags.NewSitePath	 	= 0;
	dat->flags.NewSiteID	 	= 0;
	dat->flags.NewSiteCreated 	= 0;
	
	/* init dat->years string to empty string */
	if ((dat->years = CNEW(1, char)) == NULL)
		;//error
	strcpy(dat->years, "\0");
	
	/* initialize the active pixel count to zero on each graph, each plane */
	/* also NULLs xData and yData plotting arrays */
	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		for (id = 0; id < DENSITY_RANGE; id++)	 // all densities plus selected year overlay
		{
			for (i =0; i < 2; i++)		// boundary status
			{
				for (ip=0; ip<PLANE_CNT; ip++)
				{
					dat->graphs[ig].pix_count[ip][id][i] = 0;
				}
				dat->graphs[ig].xData[id][i] = NULL;
				dat->graphs[ig].yData[id][i] = NULL;
			}
		}
	}
	
	/* initialize density structure */
	dat->density.pixelMax 	= 0;
	dat->density.pixelMin 	= 0;
	dat->density.d_func 	= DENS_EQ_FREQ;

	/* sets default selected plane to zero */
	dat->selPlane = 0;
	
	/* sets default autofit scale to 1.0 */
	dat->qcz_dat.Scale = 1.0;
	
	/* initialize the change flag */
	dat->qcz_dat.chngflg = 0;
	
	/* initialize the frequency plot structure */
	dat->freqplot.xData		= NULL;
	dat->freqplot.yData		= NULL;
	dat->freqplot.dat_cnt	= 0;
	for (ig = 0; ig < GRAPH_CNT; ig++)
	{
		dat->freqplot.colors[ig]	= freq_colors[ig];
		dat->freqplot.key_cnt[ig]	= 0;
	}
	
	/* initialize the month data lists */
	dat->file_dat.passflg = 1;
	for (i = 0; i < 12; i++)
	{
		if ((dat->file_dat.monthfiles[i].next = CNEW(1, struct monthfilestruct)) == NULL)
			fatal_error(MEM_ALLOC_ERROR, "month data list structure initialization");
		dat->file_dat.monthfiles[i].next->filenum	= -1;
		dat->file_dat.monthfiles[i].next->begptr	= -1;
		dat->file_dat.monthfiles[i].next->endptr	= -1;
		//dat->file_dat.monthfiles[i].next->endptr	= 2147483647;
		dat->file_dat.monthfiles[i].next->next		= NULL;
	}
	
	return 0;		
}
