/****************************************************************************\

	QCF Module qcf_init
	
	Author:  Steve Wilcox, Jeremy Cook
	
	Date:  2003-07-03
	
	Description: Header file for the qcf_init.c module

\****************************************************************************/
#ifndef __qcf_init_header
#define __qcf_init_header
#include "qcf.h"

int InitializeStructures (datastruct *dat);

#endif

