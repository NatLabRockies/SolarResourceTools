/**************************************************************************\
* National Renewable Energy Laboratory
* Scientific Applications Group
*
* Program: WinQCF.c
*  Author: Jeremy Cook and Steve Wilcox
*    Date: 08-10-2003
*
* Description: Graphic tool for adjusting curves for SERI QC.
*
* Modifications: 
*		12-29-2004 v0.23 
*
*		SMW added code to optimize input file reads so that subsequent 
*		reads of the same file will seek to the desired month within the 
*		file. 
*
*		Added a linked list of monthfilestructs to track the month breaks 
*		during the initial read. Also added command line parameters so 
*		that the program can be called from the command prompt.
*
*		Added command line functionality in the new do_commandline 
*		function. Didn't complete it; there are still some windows that 
*		popup when running from command line, most notable the input read 
*		progress bar.
*
*		Added input file name to print panel.
*
*		2/15/2007 v0.24. SMW added a blank read check in the ReadQCF function
*		to filter out bogus data that cause crashes.
*
*       12/9/2010 v0.25 SMW added solpos00 module. Should be no change in
*       functionality.
*		
*		5/11/2011 v0.26 SMW added line check in ReadQCF to reject lines that
*		are not in the expected format.
*
*		11/15/2011 v0.27 SMW added Software Disclaimer at spash screen
*
*		3/7/2019 v0.28 SMW added initialization for yr_tmp variable in 
*		ProcessQCF function
\**************************************************************************/
#include "ReadSavePng.h"
#include <utility.h>
#include <formatio.h>
#include "toolbar.h"
#include "WinQCF.h"
#include <cvirte.h>		
#include <userint.h>
#include "solpos00.h"
#include "qcf_init.h"
#include "qcf.h"
#include "qcf_misc.h"
#include "qcf_bndry.h"
#include "qcf_err.h"


static int mainPanel;
static int mainMenu;
static int editLow;
static int editMedium;
static int editHigh;
static int openFile;
static int printPan;
static int newSite;
static int waitPan;
static int editPan;
static int splPan;
static int frqPan;
static int integMenu;
static int toolPan;
static ToolbarType MainToolbar;

#define BINMAX 31

/* global airmass throttles (for kt and kn maximums) */
int am_throt[K_CNT][GRAPH_CNT] =
/*     low  med   hi   kspace */
	{{ 0,   3,  10},  /* kt    */
	 { 0,   5,  15}};  /* kn */




// Function prototypes 
int EditPanelLoad (datastruct *dat);
int ReadQC0 (void *callbackData);
int ProcessQCF(void *callbackData);
int ReadQCF(FILE *hFile, int filenum, QCFlinestruct *line, void *callbackData, int QCZ_Month, 
            int progHandle, long *fsize, filestruct *monthlist);
int Density (void *callbackData);
int Plot (void *callbackData);
int ReInitLists(void *callbackData);
int DisplayStats (void *callbackData);
int UpdateCurveDisplay (void *callbackData, int panel, int ig);
int DensityLegend (void *callbackData);
int SetupPrintPanel (void *callbackData);
int SaveQuit(int panel, int control, int event, void *callbackData);
int Save(int panel, int control, int event, void *callbackData);
int saveQC0(void *callbackData);
int save_confirm(void);
void UpdateStnList(int panel, void *callbackData, char *Folder);
void extract_site_dat(FILE *infile, char *site_desc, float *lat, float *lon, float *tz, int *integ, int *plane, float *filter,
		char *curves, char *path, char **comments);
int	do_commandline(datastruct *dat, int argc, char **argv);


/*---------------------------------------------------------------------------*/
/* Main Function.                                                			 */
/*---------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
	datastruct dat;
	int bitmap_id;
	char projdir[MAX_PATHNAME_LEN], fname[MAX_PATHNAME_LEN];

	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((mainPanel = LoadPanel (0, "WinQCF.uir", MAIN)) < 0)
		return -1;

	if (argc > 1)
	{
		InitializeStructures (&dat);
		dat.cmdline = 1;
		do_commandline(&dat, argc, argv);
	}
	else
	{
		dat.cmdline = 0;
	
		mainMenu 	= LoadMenuBar (mainPanel, "WinQCF.uir", MENU);
		integMenu 	= LoadMenuBar (0, "WinQCF.uir", POPUP);

		/* Passes dat structure into subordinate functions and callbacks.*/
		SetMenuBarAttribute (mainMenu, MENU_FILE_OPEN, ATTR_CALLBACK_DATA,
							 &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_QC0, ATTR_CALLBACK_DATA,
							 &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_EDIT, ATTR_CALLBACK_DATA,
							 &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_IMAGE_BMP,
							 ATTR_CALLBACK_DATA, &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_IMAGE_PNG,
							 ATTR_CALLBACK_DATA, &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_PRINT, ATTR_CALLBACK_DATA,
							 &dat);
		SetMenuBarAttribute (mainMenu, MENU_FILE_QUIT, ATTR_CALLBACK_DATA,
							 &dat);

		/* Passes dat.graph structures into controls. */
		SetCtrlAttribute (mainPanel, MAIN_LOW_GRAPH, ATTR_CALLBACK_DATA,
						  &dat);
		SetCtrlAttribute (mainPanel, MAIN_MED_GRAPH, ATTR_CALLBACK_DATA,
						  &dat);
		SetCtrlAttribute (mainPanel, MAIN_HIGH_GRAPH, ATTR_CALLBACK_DATA,
						  &dat);
		SetCtrlAttribute (mainPanel, MAIN_MONTH, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_YEAR, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_PLANE0, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_PLANE1, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_PLANE2, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_ANIMATE, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_ANIMATE_TIMER, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_DENS_OFF, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_1, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_2, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_3, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_3_FILTER, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_3_FILTER_APPLY, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_FPLOT, ATTR_CALLBACK_DATA, &dat);
		SetCtrlAttribute (mainPanel, MAIN_QUIT, ATTR_CALLBACK_DATA, &dat);
	
		/* Creates the toolbar on the main panel (using images from BUTTON panel).*/
    	toolPan = LoadPanel (0, "winqcf.uir", BUTTON);
		Toolbar_New (mainPanel, mainMenu, "Main Toolbar", 0, 0, 0, 1, &MainToolbar);

		/* extract each button image from BUTTON panel and save to temporary bmp file */
	    GetProjectDir(projdir);
	    MakePathname (projdir, "qcf$tmp.bmp", fname);
	    
	    GetCtrlBitmap (toolPan, BUTTON_OPEN, 0, &bitmap_id);
	    SaveBitmapToFile (fname, bitmap_id);
	    DiscardBitmap(bitmap_id);
		Toolbar_InsertItem (MainToolbar, 1, kCommandButton, 1, "Open",
							kMenuCallback, MENU_FILE_OPEN, 0, 0, fname);
	    
	    GetCtrlBitmap (toolPan, BUTTON_SAVE, 0, &bitmap_id);
	    SaveBitmapToFile (fname, bitmap_id);
	    DiscardBitmap(bitmap_id);
		Toolbar_InsertItem (MainToolbar, 2, kCommandButton, 1, "Save QC0",
							kMenuCallback, MENU_FILE_SAVE_QC0, 0, 0,fname);
		Toolbar_InsertItem (MainToolbar, 3, kSeparator, 1, "", kNoCallback, 0,
							0, 0, "");

	    GetCtrlBitmap (toolPan, BUTTON_PRINT, 0, &bitmap_id);
	    SaveBitmapToFile (fname, bitmap_id);
	    DiscardBitmap(bitmap_id);
		Toolbar_InsertItem (MainToolbar, 4, kCommandButton, 1, "Print",
							kMenuCallback, MENU_FILE_PRINT, 0, 0, fname);

		/* get rid of temporary stuff */
		DiscardPanel(toolPan);
		DeleteFile (fname);
		
		/* dim save and print buttons until files are loaded */
		Toolbar_DimItem (MainToolbar, 2, 1);
		Toolbar_DimItem (MainToolbar, 4, 1);
		Toolbar_Display (MainToolbar);

		/* Loads edit panels for all air masses */
		EditPanelLoad (&dat);
	
		/* Main panel display controls */
		DisplayPanel (mainPanel);
		about_qcf(NULL, NULL, NULL, NULL);
		SetCtrlAttribute (splPan, SPL_PAN_TIMER, ATTR_ENABLED, 1);
		InitializeStructures (&dat);	
		RunUserInterface ();
	
		DiscardPanel (editLow);
		DiscardPanel (editMedium);
		DiscardPanel (editHigh);
	DiscardPanel (mainPanel);
	}
	return 0;
}


/*  Main Panel Functions */
/*  -------------------- */


/*---------------------------------------------------------------------------*/
/* Changes the month and replots.                                 			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ChangeMonth (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	qczstruct *qcz_dat;
	flagstruct *flags;
	datastruct *dat;
	int retval, ig, ip;

	switch (event)
		{
		case EVENT_COMMIT:
			dat		= (datastruct*)callbackData;
			qcz_dat = &dat->qcz_dat;
			flags 	= &dat->flags;
			
			if (qcz_dat->chngflg)
				retval = save_confirm();
			else
				retval = SAVE_DISCARD; // no save necessary

			if (retval == SAVE_YES)
				saveQC0(callbackData);
			
			if (retval < SAVE_CANCEL)
			{
				qcz_dat->chngflg = 0;
				GetCtrlVal (mainPanel, MAIN_MONTH, &(qcz_dat->Month));
		
				ReadQC0(callbackData);
				if (flags->FirstFileLoad == 0)
					ReInitLists(callbackData);
				ProcessQCF(callbackData);
				
				/* call autofit if boundaries undefined */
				ip = dat->selPlane;
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					if (
						qcz_dat->Max_kn 								== 0 ||
						qcz_dat->Max_kt[qcz_dat->RightPosIndex] 		== 0 ||
						qcz_dat->LeftShape[ig]							== 0 ||
						qcz_dat->LeftPos[ig]							== 0 ||
						qcz_dat->RightShape[ig]							== 0 ||
						qcz_dat->RightPos[ig][qcz_dat->RightPosIndex] 	== 0)
					{
						autofit(dat, ig, ip, 1.0);
					}
				}
		
				BndryStatus(callbackData);
				DisplayStats(callbackData);
				Density(callbackData);
				DensityLegend (callbackData);
				Plot(callbackData);
			   	plot_freq (-1, -1, EVENT_LEFT_DOUBLE_CLICK, callbackData, 0, 0);

				/* set flags */
				flags->FirstFileLoad = 0;
			}
			else
				SetCtrlIndex (mainPanel, MAIN_MONTH, qcz_dat->Month);  // reset the original month
				
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Changes the year and replots.                                 			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ChangeYear (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, ip, ix, iy, iYrVal, iYrNdx;
	char yr_tmp[5];
	qczstruct *qcz_dat;
	flagstruct *flags;
	pixelheader *pixel;
	graphstruct *graph;
	datastruct *dat;
	
	switch (event)
		{
		case EVENT_RIGHT_CLICK:  // resets the control to 'ALL'
			SetCtrlVal (mainPanel, MAIN_YEAR, 0);
			/* fall through to the next section */
			
		case EVENT_COMMIT:
			/* shortcuts */
			dat 	= (datastruct*)callbackData;
			qcz_dat = &dat->qcz_dat;
			flags 	= &dat->flags;

			GetCtrlVal (mainPanel, MAIN_YEAR, &iYrVal);
			GetIndexFromValue (mainPanel, MAIN_YEAR, &iYrNdx, iYrVal);
			GetLabelFromIndex (mainPanel, MAIN_YEAR, iYrNdx, yr_tmp);

			if (iYrNdx > 0) // "All" is always 0, so >0 means a year is selected
			{
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					for (ip=0; ip<PLANE_CNT; ip++)
					{
						graph = &((datastruct*)callbackData)->graphs[ig];
						for (ix=XMIN; ix<XMAX; ix++)
							for (iy=YMIN; iy<YMAX; iy++)
							{
								/* flag pixel as year-selected */
								pixel = &graph->phead[ix][iy][ip];
								if (strstr (pixel->years, yr_tmp) != NULL)
								{
									/* decrement pixel count for range that pixel was moved from */
									graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]--;                                                                                        	
									/* change range to year range */
									pixel->density_val = (DENSITY_RANGE-1);
									/* increment year range counter */
									graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;                                                                                        	
								}
							}
					}
				}
				Plot(callbackData);
			}
			
			/* adjusts density ranges (density function controls year highlighting) and replots */
			else if (iYrNdx == 0) // "All" is selected
			{
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					for (ip=0; ip<PLANE_CNT; ip++)
					{
						graph = &((datastruct*)callbackData)->graphs[ig];
						for (ix=XMIN; ix<XMAX; ix++)
							for (iy=YMIN; iy<YMAX; iy++)
							{
								/* flag pixel as year-selected */
								pixel = &graph->phead[ix][iy][ip];
								if (graph->phead[ix][iy][ip].density_val == (DENSITY_RANGE-1))
								{
									/* change year range to 0 range */
									graph->phead[ix][iy][ip].density_val = 0;
									/* increment 0 range counter */
									graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;                                                                                        	
									/* decrement pixel count for year range */
									graph->pix_count[ip][DENSITY_RANGE-1][pixel->bndry_flg]--;                                                                                        	
								}
							}
					}
				}
				Density(callbackData);
				DensityLegend (callbackData);
				Plot(callbackData);
			}			
			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Changes the plane and replots.											*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK ChangePlane (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, editPan;
	char graph_title[254];

	datastruct *dat;

	switch (event)
		{
		case EVENT_COMMIT:
			dat 	= (datastruct*)callbackData;
			switch (control)
			{
			case MAIN_PLANE0:
				SetCtrlVal (mainPanel, MAIN_PLANE0, 1);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 0);
				dat->selPlane = 0;
				break;
			case MAIN_PLANE1:
				SetCtrlVal (mainPanel, MAIN_PLANE0, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 1);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 0);
				dat->selPlane = 1;
				break;				
			case MAIN_PLANE2:
				SetCtrlVal (mainPanel, MAIN_PLANE0, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 1);
				dat->selPlane = 2;
				break;
			}

			/* update edit panel graph titles */
			for (ig=0; ig<GRAPH_CNT; ig++)
			{
				strcpy (graph_title, "\0");
			
				/* Set editPan with ig. start title */
				switch (ig)
				{
					case 0:
						editPan = editLow;
						strcat (graph_title, "Low Air Mass - ");
						break;
					case 1:
						editPan = editMedium;
						strcat (graph_title, "Medium Air Mass - ");
						break;
					case 2:
						editPan = editHigh;
						strcat (graph_title, "High Air Mass - ");
						break;
				}
				
				/* finish each title with plane */
				switch (dat->selPlane)
				{
					case 0:
						strcat (graph_title, "Global, Direct");
						break;
					case 1:
						strcat (graph_title, "Global, Diffuse");
						break;
					case 2:
						strcat (graph_title, "Direct, Diffuse");
						break;
				}
				SetCtrlAttribute (editPan, EDIT_GRAPH, ATTR_LABEL_TEXT, graph_title);
			}
			
			/* call plotting functions */
			BndryStatus(callbackData);
			DisplayStats (callbackData);
			DensityLegend (callbackData);
			Plot(callbackData);
			
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Changes the density method and replots.									*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK ChangeDensity (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	densitystruct *density;

	switch (event)
		{
		case EVENT_COMMIT:
			density = &((datastruct*)callbackData)->density;
			switch (control)
			{
			case MAIN_DENS_OFF:
				SetCtrlVal (mainPanel, MAIN_DENS_OFF, 1);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_1, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_2, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_3, 0);
				SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_DIMMED, 1);
				density->d_func = DENS_OFF;
				break;
			case MAIN_DENS_MODE_1:
				SetCtrlVal (mainPanel, MAIN_DENS_OFF, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_1, 1);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_2, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_3, 0);
				SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_DIMMED, 1);
				density->d_func = DENS_EQ_FREQ;
				break;				
			case MAIN_DENS_MODE_2:
				SetCtrlVal (mainPanel, MAIN_DENS_OFF, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_1, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_2, 1);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_3, 0);
				SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_DIMMED, 1);
				density->d_func = DENS_EQ_RANGE;
				break;
			case MAIN_DENS_MODE_3:
			case MAIN_DENS_FAC:
				SetCtrlVal (mainPanel, MAIN_DENS_OFF, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_1, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_2, 0);
				SetCtrlVal (mainPanel, MAIN_DENS_MODE_3, 1);
				SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_DIMMED, 0);
				density->d_func = DENS_EXPONENTIAL;
				GetCtrlVal(mainPanel, MAIN_DENS_FAC, &density->factor);
				break;
			}

			/* Calculate density */
			Density(callbackData);
			DensityLegend (callbackData);
			
			/* Plot graphs */
			Plot(callbackData);

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


#if 0    /* formerly excluded lines */
/*--------------------------------------------------------------------------*/
/* Toggles the 3 Component Filtering controls.								*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK FilterToggle (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int toggle = 0;
	
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (mainPanel, MAIN_3_FILTER, &toggle);
			switch (toggle)
			{
			case OFF:
				SetCtrlAttribute (mainPanel, MAIN_KS_THOLD, ATTR_DIMMED, 1);
				SetCtrlAttribute (mainPanel, MAIN_3_FILTER_APPLY, ATTR_DIMMED, 1);
				SetCtrlVal (mainPanel, MAIN_KS_THOLD, 0.0);
				break;
			case ON:
				SetCtrlAttribute (mainPanel, MAIN_KS_THOLD, ATTR_DIMMED, 0);
				break;
			}
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Controls stuff related to changing the 3 Component Filtering adjustment	*/	
/* control.																	*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK FilterAdjust (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SetCtrlAttribute (mainPanel, MAIN_3_FILTER_APPLY, ATTR_DIMMED, 0);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


#endif   /* formerly excluded lines */
/*--------------------------------------------------------------------------*/
/* Applies the 3 Component Filtering.										*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK FilterApply (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	datastruct *dat;
	pixelheader *ph;
	int		ig, ip, ix, iy, iYear, rng_cnt, rng_ndx,
			filt_flg;		/* filter flag from panel control */
	
	float	filt_thrsh;		/* filter threshold from panel control */
	graphstruct *graph;
	char yr_tmp[6], yr_rng[6];
	char *yearlist_tmp;
	
	struct datalist *rec;
	struct tm *tblock;

	switch (event)
		{
		case EVENT_COMMIT:
			/* make sure that the filter check box is checked if callback is  
			   from Apply button) */
			if (control == MAIN_3_FILTER_APPLY)
				SetCtrlVal(mainPanel, MAIN_3_FILTER, 1);
			
			ProcessDrawEvents();
			if ((waitPan = LoadPanel (0, "WinQCF.uir", WAIT_PAN_2)) < 0)
				return -1;
			InstallPopup(waitPan);
			
			dat = (datastruct*)callbackData;
//			SetCtrlAttribute (mainPanel, MAIN_3_FILTER_APPLY, ATTR_DIMMED, 1);
			
			GetCtrlVal (mainPanel, MAIN_3_FILTER, &filt_flg);
			GetCtrlVal (mainPanel, MAIN_KS_THOLD, &filt_thrsh);
			
			/* get rid of the existing years */
			free(dat->years);
			if ((dat->years = CNEW(1, char)) == NULL)
				fatal_error(MEM_ALLOC_ERROR, "FilterApply"); // error
			strcpy(dat->years, "\0");

			/* prep yearlist ring control */
			ClearListCtrl (mainPanel, MAIN_YEAR);
			InsertListItem (mainPanel, MAIN_YEAR, -1, "All", 0);
			iYear = 1;

			for (ig = 0; ig < GRAPH_CNT; ig++)
			{
				/* shortcut to appropriate graph */
				graph = &dat->graphs[ig];
				
				/* first examine all the records under this graph (using plane zero) */
				for (ip = 0; ip < PLANE_CNT; ip++)
					for (ix = 0; ix < XSIZE; ix++)
						for (iy = 0; iy < YSIZE; iy++)
						{
							ph = &graph->phead[ix][iy][ip];
						
							/* get rid of the existing years */
							if (*(ph->years))
							{
								free(ph->years);
								if ((ph->years = CNEW(1, char)) == NULL)
									fatal_error(MEM_ALLOC_ERROR, "FilterApply pixel"); // error
								strcpy(ph->years, "\0");
							}
			
							/* start down the list of the zero plane */
							if (ip == 0)
							{
								rec = ph->dathead->dat_next[ip];
								while (rec->dat_next[ip])
								{
									rec->excluded = 0; // assume not excluded until otherwise proven
									if (filt_flg)
										if (rec->kt < MISS_K && rec->kn < MISS_K && rec->kd < MISS_K)
										{
											if (fabs(rec->kt - rec->kn - rec->kd) > filt_thrsh)
												rec->excluded = 1;
										} 
										else
											rec->excluded = 1;
									
									rec = rec->dat_next[ip];
								}
							}
						}
							
				/* next, count all unexcluded records */
				for (ip = 0; ip < PLANE_CNT; ip++)
				{
					for (ix = 0; ix < XSIZE; ix++)
					{
						for (iy = 0; iy < YSIZE; iy++)
						{
							ph = &graph->phead[ix][iy][ip];
							ph->count = 0;
							
							/* change year density range to 0 range to reset year filtering */
							if (ph->density_val == DENSITY_RANGE-1)
								ph->density_val = 0;
								
							rec = ph->dathead->dat_next[ip];
							while (rec->dat_next[ip])
							{
								if (!rec->excluded)
								{
									ph->count++;
									tblock = localtime(&rec->date);

									sprintf(yr_tmp, "%d ", tblock->tm_year + 1900);

									/* adds year to pixel's year list */
									if (strstr (ph->years, yr_tmp) == NULL)
									{
										yearlist_tmp = ph->years;
										if ((ph->years = CNEW((strlen(yearlist_tmp)+6), char)) == NULL)
											;//error
										strcpy (ph->years, yearlist_tmp);
										strcat (ph->years, yr_tmp);
										free(yearlist_tmp);
									}
										
									/* adds year to dat's year list */
									if (strstr (dat->years, yr_tmp) == NULL)
									{
										yearlist_tmp = dat->years;
										if ((dat->years = CNEW((strlen(yearlist_tmp)+6), char)) == NULL)
											;//error
										strcpy (dat->years, yearlist_tmp);
										strcat (dat->years, yr_tmp);
										free(yearlist_tmp);
										
										/* adds year to Year select ring control, sorted (after 'all' entry) */
										GetNumListItems (mainPanel, MAIN_YEAR, &rng_cnt);
										for (rng_ndx = 1; rng_ndx < rng_cnt; rng_ndx++)
										{
											/* find insertion point */
											GetLabelFromIndex (mainPanel, MAIN_YEAR, rng_ndx, yr_rng);
											str_trim(yr_tmp);
											if (strcmp(yr_tmp, yr_rng) < 0)
												break;
										}
										InsertListItem (mainPanel, MAIN_YEAR, rng_ndx, yr_tmp, iYear);
										iYear++;
									}
								}
								rec = rec->dat_next[ip];
							}
						}
					}
				}

			}
			/* call plotting functions */
			BndryStatus(callbackData);
			Density(callbackData);
			DiscardPanel(waitPan);
			DisplayStats (callbackData);
			DensityLegend (callbackData);
			Plot(callbackData);
			plot_freq (-1, -1, EVENT_LEFT_DOUBLE_CLICK, callbackData, 0, 0);
							
			
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Exits the program.                                             			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK ExitProgram (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int retval;
	
	switch (event)
	{
		case EVENT_COMMIT:
			if (((datastruct*)callbackData)->qcz_dat.chngflg)
				retval = save_confirm();
			else
				retval = SAVE_DISCARD; // no save necessary

			switch (retval) // save
			{
				case SAVE_YES:
					saveQC0(callbackData);
					QuitUserInterface(0);
					break;
					
				case SAVE_DISCARD:
					QuitUserInterface(0);
					
				case SAVE_CANCEL:
					break; // do nothing
			}
				
			break;
	}
	
	return 0;
}		



/*  Main Panel Menu Functions */
/*  ------------------------- */


/*---------------------------------------------------------------------------*/
/* Displays the openFile panel and passes the dat struct to		 			 */
/* OpenFileBrowse.                                                           */
/*---------------------------------------------------------------------------*/
void CVICALLBACK MenuOpenFile (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	qczstruct *qcz_dat;
	datastruct *dat;
	int retval, rng_cnt;
	
	dat		= (datastruct*)callbackData;
	qcz_dat	= &dat->qcz_dat;
	
	if (qcz_dat->chngflg)
		retval = save_confirm();
	else
		retval = SAVE_DISCARD; // no save necessary

	if (retval == SAVE_YES)
		saveQC0(callbackData);
	
	if (retval < SAVE_CANCEL)
	{
		openFile = LoadPanel (0, "WinQCF.uir", OPEN);
		UpdateStnList(openFile, callbackData, dat->qc0_Folder);
		GetNumListItems (openFile, OPEN_SITE, &rng_cnt);
		if (rng_cnt > 0)
		{
			SetCtrlVal(openFile, OPEN_SITE, 0);
			GetSiteInfo(openFile, OPEN_SITE, EVENT_COMMIT, callbackData, 0, 0); // force a callback to read the file
			strcpy(qcz_dat->QC0_FileName, dat->filelist_dat->next->FilePath);
		}
		InstallPopup (openFile);

		/* Passes the dat structure to subordinate callbacks. */
		SetCtrlAttribute (openFile, OPEN_BROWSE, ATTR_CALLBACK_DATA,
						  callbackData);
		SetCtrlAttribute (openFile, OPEN_BROWSE_QZ0, ATTR_CALLBACK_DATA,
						  callbackData);
		SetCtrlAttribute (openFile, OPEN_OK, ATTR_CALLBACK_DATA, callbackData);
		SetCtrlAttribute (openFile, OPEN_NEWSITE, ATTR_CALLBACK_DATA, callbackData);
		SetCtrlAttribute (openFile, OPEN_SITE, ATTR_CALLBACK_DATA, callbackData);
		qcz_dat->chngflg = 0;
	}
}


void CVICALLBACK MenuSaveImageBMP (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	int		Err;
	char	PathName[MAX_PATHNAME_LEN];
	int 	BmpId;

	/* load print panel */
	printPan = LoadPanel (0, "WinQCF.uir", PRINT);

	/* setup the print panel */
	SetupPrintPanel (callbackData);

	/* make bitmap */
	GetPanelDisplayBitmap (printPan, VAL_FULL_PANEL, VAL_ENTIRE_OBJECT, &BmpId);

	/* bring up save as dialog */
	Err = FileSelectPopup ("", "*.bmp", "*.bmp;", "Save BMP Image File",
						   VAL_SAVE_BUTTON, 0, 1, 1, 1, PathName);
	
	/* save bmp */
	/* Programmer's Toolbox function.  Only valid in CVI 5.5 */
	if (Err == VAL_EXISTING_FILE_SELECTED || Err == VAL_NEW_FILE_SELECTED)
	{
		SetWaitCursor (1);
	
		if (SaveBitmapToFile (PathName, BmpId) != 0)
			MessagePopup("Error", "An error prevented the image from being saved.  Click [OK] to continue.");
			
		SetWaitCursor (0);
	}
	
	/* discard panel */
	DiscardPanel (printPan);
}


void CVICALLBACK MenuSaveImagePNG (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	int		Err;
	char	PathName[MAX_PATHNAME_LEN];

	/* load print panel */
	printPan = LoadPanel (0, "WinQCF.uir", PRINT);

	/* setup the print panel */
	SetupPrintPanel (callbackData);

	/* bring up save as dialog */
	Err = FileSelectPopup ("", "*.png", "*.png;", "Save PNG Image File",
						   VAL_SAVE_BUTTON, 0, 1, 1, 1, PathName);

	/* save png */
	if (Err == VAL_EXISTING_FILE_SELECTED || Err == VAL_NEW_FILE_SELECTED)
	{
		SetWaitCursor(1);
		Png_SetParameters (0.5, 0, 72, Z_DEFAULT_COMPRESSION, 0);
		if (Png_SavePanelControlToFile (printPan, 0, PathName) != 0)
			MessagePopup("Error", "An error prevented the image from being saved.  Click [OK] to continue.");
		SetWaitCursor(0);
	}
	
	/* discard panel */
	DiscardPanel (printPan);
}


void CVICALLBACK MenuSiteConfiguration (int menuBar, int menuItem, void *callbackData,
		int panel)
{
}


void CVICALLBACK MenuExitProgram (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	int retval;
	
	if (((datastruct*)callbackData)->qcz_dat.chngflg)
		retval = save_confirm();
	else
		retval = SAVE_DISCARD; // no save necessary

 	switch (retval) // save
	{
		case SAVE_YES:
			saveQC0(callbackData);
			QuitUserInterface(0);
			break;
			
		case SAVE_DISCARD:
			QuitUserInterface(0);
			
		case SAVE_CANCEL:
			break; // do nothing; return to user interface
	}
		
}


void CVICALLBACK MenuSaveQC0 (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	saveQC0(callbackData);
}

int saveQC0(void *callbackData)
{
	FILE *iFile, *oFile;
	int ih;
	int iFileFail = 0, oFileFail = 0;
	char drive[MAX_DIRNAME_LEN], folder[MAX_DIRNAME_LEN], file[MAX_FILENAME_LEN];
	char oFileName[MAX_PATHNAME_LEN];
	char buf[254], newline[254];
	char C_mon3[12][4] = {"JAN", "FEB", "MAR", "APR", "MAY",
					"JUN", "JUL", "AUG", "SEP", "OCT",
					"NOV", "DEC"};
	qczstruct *qcz_dat;
	
	qcz_dat = &((datastruct*)callbackData)->qcz_dat;
	
	/* build newline */
	sprintf (newline, "%s: %02d-%02d/%02d/%02d/%02d; %d-%02d %d-%02d/%02d/%02d/%02d; %d-%02d %d-%02d/%02d/%02d/%02d; %d-%02d %d-%02d/%02d/%02d/%02d\n",
			C_mon3[qcz_dat->Month], qcz_dat->Max_kn, qcz_dat->Max_kt[0], qcz_dat->Max_kt[1], qcz_dat->Max_kt[2],
			qcz_dat->Max_kt[3], qcz_dat->LeftShape[0], qcz_dat->LeftPos[0], qcz_dat->RightShape[0], 
			qcz_dat->RightPos[0][0], qcz_dat->RightPos[0][1], qcz_dat->RightPos[0][2], qcz_dat->RightPos[0][3], 
			qcz_dat->LeftShape[1], qcz_dat->LeftPos[1], qcz_dat->RightShape[1], qcz_dat->RightPos[1][0], 
			qcz_dat->RightPos[1][1], qcz_dat->RightPos[1][2], qcz_dat->RightPos[1][3], qcz_dat->LeftShape[2], 
			qcz_dat->LeftPos[2], qcz_dat->RightShape[2], qcz_dat->RightPos[2][0], qcz_dat->RightPos[2][1], 
			qcz_dat->RightPos[2][2], qcz_dat->RightPos[2][3]);
			
	/* open input file stream */
	if ((iFile = fopen(qcz_dat->QC0_FileName, "r")) == NULL)
	{
		iFileFail = TRUE;
		;//error
	}
	
	/* build file name from QC0's path and #define'd TEMPFILE name */
	strcpy (oFileName, "\0");
	SplitPath (qcz_dat->QC0_FileName, drive, folder, file);
	sprintf (oFileName, "%s%s%s", drive, folder, TEMPFILE);

	/* open output file stream */
	if ((oFile = fopen (oFileName, "wt")) == NULL)
	{	
		oFileFail = TRUE;
		;//error
	}
	
	/* transfer header */
	for (ih = 0; ih < 9; ih++)
	{
		fgets(buf, 254, iFile);
		fputs (buf, oFile);		// insert QC0 file's line into oFile
	}
	
	if (feof(iFile))
		; //error
	
	/* transfer unaffected months previous to selected, replace selected month, then break out */
	for (ih = 0; ih < 12; ih++)
	{
		fgets(buf, 254, iFile);
		if (strstr (buf, C_mon3[qcz_dat->Month]) != NULL)
		{
			fputs (newline, oFile);	// insert newline into oFile
			break;
		}
		else
			fputs (buf, oFile);		// insert QC0 file's line into oFile
	}
	
	if (ih == 12)
		nonfatal_error(QC0_FORMAT_ERROR, "Month not found");
		
	
	/* transfer the rest of the file */
	fgets(buf, 254, iFile);
	while (!feof(iFile))
	{
		fputs (buf, oFile);		// insert QC0 file's line into oFile
		fgets(buf, 254, iFile);
	}
		
#if 0    /* formerly excluded lines */
	while (!feof(iFile))
	{
		/* transfer header to new file */
		for (; ih<9; ih++) // first field empty to prevent for-loop from running after 1st time thru while-loop
		{
			fputs (buf, oFile);		// insert QC0 file's line into oFile
			fgets(buf, 254, iFile);
		}
	
		fgets(buf, 254, iFile);
		if (strstr (buf, C_mon3[qcz_dat->Month]) != NULL)
			fputs (newline, oFile);	// insert newline into oFile
		else
			fputs (buf, oFile);		// insert QC0 file's line into oFile
	}
#endif   /* formerly excluded lines */
	
	if (!iFileFail)
		fclose(iFile);
	if (!oFileFail)
		fclose(oFile);
	
	if (DeleteFile (qcz_dat->QC0_FileName) != 0)
		;//error
	if (RenameFile (oFileName, qcz_dat->QC0_FileName) != 0)
		;//error
	
	qcz_dat->chngflg = 0;
	return 1;
}


void CVICALLBACK MenuPrint (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	/* load print panel */
	printPan = LoadPanel (0, "WinQCF.uir", PRINT);

	/* setup the print panel */
	SetupPrintPanel (callbackData);
	
	/* send to print spooler */
	SetWaitCursor (1);
	SetPrintAttribute (ATTR_PRINT_AREA_HEIGHT, VAL_USE_ENTIRE_PAPER);
	SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, VAL_INTEGRAL_SCALE);
	PrintPanel (printPan, "", 1, VAL_FULL_PANEL, 1);
	SetWaitCursor (0);

	/* discard panel */
	DiscardPanel (printPan);
}


/*  Edit Panel Functions */
/*  -------------------- */


/*---------------------------------------------------------------------------*/
/* Loads the Edit Panel for each Air Mass segment. 		   	                 */
/*---------------------------------------------------------------------------*/
int EditPanelLoad (datastruct *dat)
{
	int editPan, ig;
	char graph_title[254];
	qczstruct *qcz_dat;
	sitestruct *site_dat;

	qcz_dat = &dat->qcz_dat;
	site_dat = &dat->site_dat;
	
	/* Load panels */
	editLow = LoadPanel (0, "WinQCF.uir", EDIT);
	editMedium = LoadPanel (0, "WinQCF.uir", EDIT);
	editHigh = LoadPanel (0, "WinQCF.uir", EDIT);

	
	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		strcpy (graph_title, "\0");

		/* Set editPan with ig */
		switch (ig)
		{
			case 0:
				editPan = editLow;
				strcat (graph_title, "Low Air Mass - Global, Direct");
				break;
			case 1:
				editPan = editMedium;
				strcat (graph_title, "Medium Air Mass - Global, Direct");
				break;
			case 2:
				editPan = editHigh;
				strcat (graph_title, "High Air Mass - Global, Direct");
				break;
		}
		SetCtrlAttribute (editPan, EDIT_GRAPH, ATTR_LABEL_TEXT, graph_title);

		/* Passes dat structure to subordinate callbacks. */
		SetCtrlAttribute (editPan, EDIT_LESS_ERR, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_MORE_ERR, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_CURVE_SHAPE_LEFT, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_CURVE_POS_LEFT, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_CURVE_SHAPE_RIGHT, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_CURVE_POS_RIGHT, ATTR_CALLBACK_DATA,
						  dat);
		SetCtrlAttribute (editPan, EDIT_KN_MAX, ATTR_CALLBACK_DATA,
						  dat);		
		SetCtrlAttribute (editPan, EDIT_KT_MAX, ATTR_CALLBACK_DATA,
						  dat);		
		SetCtrlAttribute (editPan, EDIT_NAR_LEFT, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_NAR_RIGHT, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_NAR_BOTH, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_WIDE_LEFT, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_WIDE_RIGHT, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_WIDE_BOTH, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_LIST, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_EXCLUDE, ATTR_CALLBACK_DATA, dat);
		SetCtrlAttribute (editPan, EDIT_RESET, ATTR_CALLBACK_DATA, dat);

	}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Displays the Edit Panel for each Air Mass segment.    	                 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditPanel (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int editPan;
	
	datastruct *dat;
	
	dat = (datastruct*)callbackData;

	switch (event)
	{
		case EVENT_LEFT_DOUBLE_CLICK:
			/* Set editPan with ig */
			switch (control)
				{
				case MAIN_LOW_GRAPH:
					editPan = editLow;
					break;
				case MAIN_MED_GRAPH:
					editPan = editMedium;
					break;
				case MAIN_HIGH_GRAPH:
					editPan = editHigh;
					break;
				}

			DisplayPanel(editPan);
			break;
	}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls the function of the Close button on each edit window.            */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditClose (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
		{
		case EVENT_COMMIT:
			SetCtrlAttribute (panel, EDIT_OK, ATTR_CALLBACK_DATA, callbackData);
			EditOk(panel, control, event, &callbackData, eventData1, eventData2);
			break;

		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Controls the function of the Ok button on each edit window.				*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditOk (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
//	/* Receives the dat structure from the main() function. */
//	qczstruct *qcz_dat;
//	struct posdata *soldat;
//	int ig;
//	char compare[260];
	
	switch (event)
		{
		case EVENT_COMMIT:
			HidePanel (panel);
			break;

		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Controls the function of the Less Err and More Err buttons.				*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditErr (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, ip;
	char compare[260];

	qczstruct *qcz_dat;
	datastruct *dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;
			dat = (datastruct*)callbackData;

			/* get plane index */
			ip = dat->selPlane;

			/* Set ig based on title of panel so values are correctly saved for each air mass. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Err adjustment corrupted.");

			switch (control)
			{
			case EDIT_LESS_ERR:
				qcz_dat->Scale = qcz_dat->Scale * 10;
				break;
				
			case EDIT_MORE_ERR:
				qcz_dat->Scale = qcz_dat->Scale / 10;
				break;
			}
			
			/* get the error level as plus or minus integer increments */
			sprintf(compare, "%d", -RoundRealToNearestInteger(log(qcz_dat->Scale) / log(2.0)));
			SetCtrlVal (panel, EDIT_ERR_LEVEL, compare);
			
			autofit(dat, ig, ip, qcz_dat->Scale);
			
			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			UpdateCurveDisplay (callbackData, panel, ig);
			Plot(callbackData);

			qcz_dat->chngflg = 1;

			break;

		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Update the X and Y-coordinate of the marker when it is moved (the marker	*/
/* is the cursor on the Graph indicated by a short cross.  This function is	*/
/* called whenever the Graph cursors are moved.  When a graph control has	*/
/* cursors, it can be used as a Hot input-mode control.						*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditUpdateMarker (int panel, int control, int event,
                              void *callbackData, int eventData1,
                              int eventData2)
{
	double x1, x2;
	double y1, y2;

	if (event == EVENT_COMMIT)
	{
		/* Get the cursor's position */
		GetGraphCursor (panel, EDIT_GRAPH, 1, &x1, &y1);
		GetGraphCursor (panel, EDIT_GRAPH, 2, &x2, &y2);
        
		/* Display the data */
		SetCtrlVal (panel, EDIT_CURSOR_1_X, x1);
		SetCtrlVal (panel, EDIT_CURSOR_1_Y, y1);
		SetCtrlVal (panel, EDIT_CURSOR_2_X, x2);
		SetCtrlVal (panel, EDIT_CURSOR_2_Y, y2);
	}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Toggles the cursor controls on and off.									*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditCursorToggle (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int toggle = OFF;
	
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panel, EDIT_CURSOR_TOGGLE, &toggle);
			switch (toggle)
				{
				case ON:
					/* Activates cursor controls. */
					SetCtrlAttribute (panel, EDIT_GRAPH, ATTR_NUM_CURSORS, 2);
					SetCursorAttribute (panel, EDIT_GRAPH, 1, ATTR_CURSOR_ENABLED, 1);
					SetCursorAttribute (panel, EDIT_GRAPH, 2, ATTR_CURSOR_ENABLED, 1);
					SetCursorAttribute (panel, EDIT_GRAPH, 1, ATTR_CURSOR_COLOR, VAL_BLUE);
					SetCursorAttribute (panel, EDIT_GRAPH, 2, ATTR_CURSOR_COLOR,
										VAL_GREEN);
					SetGraphCursor (panel, EDIT_GRAPH, 1, 20, 80);
					SetGraphCursor (panel, EDIT_GRAPH, 2, 80, 20);

			        /* Display the data */
					EditUpdateMarker (panel, control, event, callbackData, eventData1, eventData2);

					/* Undims the cursor controls */
					SetCtrlAttribute (panel, EDIT_LIST, ATTR_DIMMED, 0);
					SetCtrlAttribute (panel, EDIT_EXCLUDE, ATTR_DIMMED, 0);
					SetCtrlAttribute (panel, EDIT_ZOOM, ATTR_DIMMED, 0);
					SetCtrlAttribute (panel, EDIT_RESTORE, ATTR_DIMMED, 0);
					SetCtrlAttribute (panel, EDIT_RESET, ATTR_DIMMED, 0);
					break;

				case OFF:
					/* Restores the graph to it's original non-zoomed self */
					EditRestoreGraph (panel, EDIT_GRAPH, event, callbackData, eventData1, eventData2);

					/* Deactivates cursor controls. */
					SetCtrlAttribute (panel, EDIT_GRAPH, ATTR_NUM_CURSORS, 0);  				

			        /* Display the data */
					SetCtrlVal (panel, EDIT_CURSOR_1_X, 0.0);
					SetCtrlVal (panel, EDIT_CURSOR_1_Y, 0.0);
					SetCtrlVal (panel, EDIT_CURSOR_2_X, 0.0);
					SetCtrlVal (panel, EDIT_CURSOR_2_Y, 0.0);

					/* Dims the cursor controls */
					SetCtrlAttribute (panel, EDIT_LIST, ATTR_DIMMED, 1);
					SetCtrlAttribute (panel, EDIT_EXCLUDE, ATTR_DIMMED, 1);
					SetCtrlAttribute (panel, EDIT_ZOOM, ATTR_DIMMED, 1);
					SetCtrlAttribute (panel, EDIT_RESTORE, ATTR_DIMMED, 1);
					SetCtrlAttribute (panel, EDIT_RESET, ATTR_DIMMED, 1);
					break;
				}
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* The ZoomIn function simulates a zoom operation on the graph by rescaling  */
/* it.  When the Zoom button is pushed, this function gets the current       */
/* position of the two cursors and rescales the graph based on these.  The   */
/* graph cursors define the zoom region.                                     */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditZoomIn (int panel, int control, int event, void *callbackData,
                        int eventData1, int eventData2)
{
    double x1;
    double x2;
    double y1;
    double y2;
    double temp;
    
    if (event == EVENT_COMMIT)
        {
        	/* Get the current position of both cursors.  Notive that the        */
	        /* position is relative to the Graph's coordinate system (your plots)*/
			GetGraphCursor (panel, EDIT_GRAPH, 1, &x1, &y1);
			GetGraphCursor (panel, EDIT_GRAPH, 2, &x2, &y2);
        
	        /* Get positive range values, and rescale the Graph */
	        if (x1 > x2)
	            {
	            temp 	= x1;
	            x1 		= x2;
	            x2 		= temp;
	            }
	        if (y1 > y2)
	            {
	            temp 	= y1;
	            y1 		= y2;
	            y2 		= temp;
	            }
			SetAxisRange (panel, EDIT_GRAPH, VAL_MANUAL, x1, x2, VAL_MANUAL,
						  y1, y2);
						  
		/* Updates coordinate indicators */
		EditUpdateMarker (panel, control, event, callbackData, eventData1, eventData2);
        }
    return 0;
}


/*---------------------------------------------------------------------------*/
/* Restores the graph control to its original state, before any zooming was  */
/* done.  This is done simply by resetting the X and Y-axis ranges to their  */
/* original values to rescale the graph.                                     */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditRestoreGraph (int panel, int control, int event,
                              void *callbackData, int eventData1,
                              int eventData2)
{
    if (event == EVENT_COMMIT)
    {
		SetAxisRange (panel, EDIT_GRAPH, VAL_MANUAL, 0, 100, VAL_MANUAL,
					  0, 100);
						  
		/* Updates coordinate indicators */
		EditUpdateMarker (panel, control, event, callbackData, eventData1, eventData2);
	}
    return 0;
}


/*--------------------------------------------------------------------------*/
/* Adjusts Kt Max and updates on main and all edit panels.					*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditKtMax (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, rpi;
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/* Set ig based on title of panel. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Kt Max adjustment corrupted.");

			rpi = qcz_dat->RightPosIndex;
			switch (ig)
			{
				case 0:
					GetCtrlVal (panel, control, &qcz_dat->Max_kt[rpi]);
					qcz_dat->Max_kt[rpi] = MIN(qcz_dat->Max_kt[rpi], XMAX-1-am_throt[KT][LOW]);
					SetCtrlVal (editMedium, EDIT_KT_MAX, (qcz_dat->Max_kt[rpi] - am_throt[KT][MED]));
					SetCtrlVal (editHigh, EDIT_KT_MAX, (qcz_dat->Max_kt[rpi] - am_throt[KT][HI]));
					break;
				case 1:
					GetCtrlVal (panel, control, &qcz_dat->Max_kt[rpi]);
					qcz_dat->Max_kt[rpi] += am_throt[KT][MED];
					qcz_dat->Max_kt[rpi] = MIN(qcz_dat->Max_kt[rpi], XMAX-1-am_throt[KT][LOW]);
					SetCtrlVal (editLow, EDIT_KT_MAX, qcz_dat->Max_kt[rpi] - am_throt[KT][LOW]);
					SetCtrlVal (editHigh, EDIT_KT_MAX, (qcz_dat->Max_kt[rpi] - am_throt[KT][HI]));
					break;
				case 2:
					GetCtrlVal (panel, control, &qcz_dat->Max_kt[rpi]);
					qcz_dat->Max_kt[rpi] += am_throt[KT][HI];
					qcz_dat->Max_kt[rpi] = MIN(qcz_dat->Max_kt[rpi], XMAX-1-am_throt[KT][LOW]);
					SetCtrlVal (editLow, EDIT_KT_MAX, qcz_dat->Max_kt[rpi]- am_throt[KT][LOW]);
					SetCtrlVal (editMedium, EDIT_KT_MAX, (qcz_dat->Max_kt[rpi] - am_throt[KT][MED]));
					break;
			}

			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);
			
			qcz_dat->chngflg = 1;

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Adjusts Kn Max and updates on main and all edit panels.					*/
/*--------------------------------------------------------------------------*/
int CVICALLBACK EditKnMax (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig;
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/* Set ig based on title of panel. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Kn Max adjustment corrupted.");

			switch (ig)
			{
				case 0:
					GetCtrlVal (panel, control, &qcz_dat->Max_kn);
					qcz_dat->Max_kn = MIN(qcz_dat->Max_kn, YMAX-1-am_throt[KN][LOW]);
					SetCtrlVal (editMedium, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][MED]));
					SetCtrlVal (editHigh, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][HI]));
					break;
				case 1:
					GetCtrlVal (panel, control, &qcz_dat->Max_kn);
					qcz_dat->Max_kn += am_throt[KN][MED];
					qcz_dat->Max_kn = MIN(qcz_dat->Max_kn, YMAX-1-am_throt[KN][LOW]);
					SetCtrlVal (editLow, EDIT_KN_MAX, qcz_dat->Max_kn - am_throt[KN][LOW]);
					SetCtrlVal (editHigh, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][HI]));
					break;
				case 2:
					GetCtrlVal (panel, control, &qcz_dat->Max_kn);
					qcz_dat->Max_kn += am_throt[KN][HI];
					qcz_dat->Max_kn = MIN(qcz_dat->Max_kn, YMAX-1-am_throt[KN][LOW]);
					SetCtrlVal (editLow, EDIT_KN_MAX, qcz_dat->Max_kn - am_throt[KN][LOW]);
					SetCtrlVal (editMedium, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][MED]));
					break;
			}

			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);

			qcz_dat->chngflg = 1;
			
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/* File Ingest Module */
/*--------------------*/


/*---------------------------------------------------------------------------*/
/* Pulls up the multi-file browser window and inserts selected file names    */
/* into the FILENAME text box  File names are stored in the file_dat struct. */
/*---------------------------------------------------------------------------*/
int CVICALLBACK OpenFileBrowse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int FileStatus = 0, i;
	char drive[MAX_DRIVENAME_LEN], dir[MAX_DIRNAME_LEN], file[MAX_FILENAME_LEN];
	filestruct *file_dat;
	flagstruct *flags;
	datastruct *dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			dat			= (datastruct*)callbackData;
			file_dat 	= &dat->file_dat;
			flags 		= &dat->flags;
			
			FileStatus = MultiFileSelectPopup (dat->dat_Folder, "*.QCF", "*.QCF",
											   "Open", 0, 1, 1,
											   &file_dat->numFiles,
											   &file_dat->MFileName);
			if (FileStatus != VAL_NO_FILE_SELECTED)
			{
				/* Adds selected files to file list on openFile panel. */
				ResetTextBox (openFile, OPEN_FILENAME, "");
				for (i=0; i<file_dat->numFiles; i++)
				{
					SetCtrlVal (openFile, OPEN_FILENAME, file_dat->MFileName[i]);
					SetCtrlVal (openFile, OPEN_FILENAME, "\n");
				}
		
				/* if no QC0 file defaults exist, search the the same directory for QC0 files */
				if (strcmp(dat->dat_Folder, "") != NULL)
				{
					/* take the path to the first file name and search directory for QC0 files */
					SplitPath (file_dat->MFileName[0], drive, dir, file);
					sprintf(dat->dat_Folder, "%s\\%s", drive, dir);
				}
				
				/* Sets QC0 flag and checks for both flags set.  If yes, then undim OK button. */
				flags->QCF_flag = 1;
				if (flags->QCF_flag == 1 && flags->QC0_flag == 1)
					SetCtrlAttribute (panel, OPEN_OK, ATTR_DIMMED, 0);
			}
			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Opens files selected in file_dat struct with selected parameters from the */
/* openFile panel.                                                           */
/*---------------------------------------------------------------------------*/
int CVICALLBACK OpenFileOk (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i, ig, ip, iRing;
	double Alog_4=1.386294361; /*, DegRad=0.017453292; */
	struct posdata *soldat;
	qczstruct *qcz_dat;
	datastruct *dat;
	flagstruct *flags;
	struct monthfilestruct *monthfile, *tmpptr;
	
	switch (event)
		{
		case EVENT_COMMIT:
			/* Shortcuts */
			qcz_dat 		= &((datastruct*)callbackData)->qcz_dat;
			soldat 			= ((datastruct*)callbackData)->soldat;
			flags 			= &((datastruct*)callbackData)->flags;
			dat				= (datastruct*)callbackData;
		
			/* Gets site, month, and time interval from OpenFile panel */
			GetCtrlVal (panel, OPEN_SITE, &iRing);
			GetCtrlVal (panel, OPEN_MONTH, &(qcz_dat->Month));
			GetCtrlVal (panel, OPEN_TIME, &soldat->interval);
		
			/* Get plane selection */
			ip = dat->selPlane;
		
			/* Calculates the RPI from time invertal */
			qcz_dat->RightPosIndex = ((int) ( 1.49 + log(soldat->interval) / Alog_4 ) - 1);
		
			/* Gets QC0 file name from location selected on ring control */
//			if (flags->NewSiteCreated == 0)
//			{
//				strcpy(Folder, dat->qc0_Folder);
//				strcat(Folder, "*.QC0");
//				GetFileStatus = GetFirstFile (Folder, 1, 0, 0, 0, 0, 0, FileName);
//				for (i=0; i<iRing; i++)
//				{
//					GetFileStatus = GetNextFile (FileName);
//				}
//				strcat(qcz_dat->QC0_FileName, FileName);
//			}
		
			/* Dump OpenFile panel */
			DiscardPanel (panel);

			/* discard the month file lists */
			for (i = 0; i < 12; i++)
			{
				monthfile = dat->file_dat.monthfiles[i].next;
		
				while (monthfile->next)
				{
					tmpptr = monthfile;;
					monthfile = monthfile->next;
					free (tmpptr);
				}
				dat->file_dat.monthfiles[i].next = monthfile;
			}
			dat->file_dat.passflg = 1;
			
			/* Calls QC0 read-in function */
			ReadQC0(callbackData);
		
			/* If this is NOT the QC0 file loaded, reinitialize the lists */
			if (flags->FirstFileLoad == 0)
				ReInitLists(callbackData);
		
			/* Read and process QCF */
			ProcessQCF(callbackData);
		
			/* call autofit if boundaries undefined */
			for (ip = 0; ip < PLANE_CNT; ip++)
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					if (
						qcz_dat->Max_kn 								== 0 ||
						qcz_dat->Max_kt[qcz_dat->RightPosIndex] 		== 0 ||
						qcz_dat->LeftShape[ig]							== 0 ||
						qcz_dat->LeftPos[ig]							== 0 ||
						qcz_dat->RightShape[ig]							== 0 ||
						qcz_dat->RightPos[ig][qcz_dat->RightPosIndex] 	== 0)
					{
						autofit(dat, ig, ip, 1.0);
					}
				}
		
			/* Calculate boundaries */
			BndryStatus(callbackData);
		
			/* Display stats */
			DisplayStats(callbackData);

			/* Calculate density */
			Density(callbackData);
			DensityLegend (callbackData);
		
			/* Plot graphs */
			Plot(callbackData);
			plot_freq (-1, -1, EVENT_LEFT_DOUBLE_CLICK, callbackData, 0, 0);

			/* set flags */
			flags->FirstFileLoad 	= 0;
			flags->QCF_flag 		= 0;
			flags->QC0_flag 		= 0;
		
			/* Undims mainPanel controls */
			SetCtrlAttribute (mainPanel, MAIN_TIME, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_MONTH, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_YEAR, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_PLANE, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_PLANE0, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_PLANE1, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_PLANE2, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_ANIMATE, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENSITY, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENS_OFF, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_1, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_2, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENS_MODE_3, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_DENS_FAC, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_LOW_GRAPH, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_MED_GRAPH, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_HIGH_GRAPH, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_3_FILTER, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_KS_THOLD, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_3_FILTER_APPLY, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_FPLOT, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_FPLOTLABEL, ATTR_DIMMED, 0);
			SetCtrlAttribute (mainPanel, MAIN_FPLOTZERO, ATTR_DIMMED, 0);

			/* undims menu items */
			SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_QC0, ATTR_DIMMED, 0);
			SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_IMAGE_BMP, ATTR_DIMMED,
								 0);
			SetMenuBarAttribute (mainMenu, MENU_FILE_SAVE_IMAGE_PNG, ATTR_DIMMED,
								 0);
			SetMenuBarAttribute (mainMenu, MENU_FILE_PRINT, ATTR_DIMMED, 0);

			/* undims toolbar items */
			Toolbar_DimItem (MainToolbar, 2, 0);
			Toolbar_DimItem (MainToolbar, 4, 0);

			/* Initialize plane control */
			ip = dat->selPlane;
		
			if (ip == 0)
			{
				SetCtrlVal (mainPanel, MAIN_PLANE0, 1);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 0);
			}
			else if (ip == 1)
			{
				SetCtrlVal (mainPanel, MAIN_PLANE0, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 1);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 0);
			}
			else if (ip == 2)
			{
				SetCtrlVal (mainPanel, MAIN_PLANE0, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE1, 0);
				SetCtrlVal (mainPanel, MAIN_PLANE2, 1);
			}
			
			
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls the function of the Cancel button on the openFile window.        */
/*---------------------------------------------------------------------------*/
int CVICALLBACK Cancel (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			DiscardPanel (panel);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls the function of the Integration Time numberic control on the 	 */
/* openFile window.                                                          */
/*---------------------------------------------------------------------------*/
int CVICALLBACK OpenFileTime (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int top, left, width, selection, value;
	
	switch (event)
		{
		case EVENT_COMMIT:

			break;
		case EVENT_RIGHT_CLICK:
				GetCtrlVal (panel, control, &value);
				GetCtrlAttribute (panel, control, ATTR_TOP, &top);
				GetCtrlAttribute (panel, control, ATTR_LEFT, &left);
				GetCtrlAttribute (panel, control, ATTR_WIDTH, &width);
				selection = RunPopupMenu (integMenu, POPUP_INTEG, panel, top,
										  left+width, 10, 10, 10, 10);
										  
				switch (selection)
				{
					case POPUP_INTEG_I01:
						value = 1;
						break;
						
					case POPUP_INTEG_I03:
						value = 3;
						break;
						
					case POPUP_INTEG_I05:
						value = 5;
						break;
						
					case POPUP_INTEG_I10:
						value = 10;
						break;
						
					case POPUP_INTEG_I15:
						value = 15;
						break;
						
					case POPUP_INTEG_I20:
						value = 20;
						break;
						
					case POPUP_INTEG_I30:
						value = 30;
						break;
						
					case POPUP_INTEG_I60:
						value = 60;
						break;
					
					default:
						; // do nothing
				}
						
				SetCtrlVal (panel, control, value);

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Opens the folder browse window, and allows the user to select a location  */
/* QC0 files.  After the browse window is OK'd, the selected folder is		 */
/* scanned for QC0 files and the Site ID is extracted from each QC0 and added*/
/* to the Site ID ring control.                                              */
/*---------------------------------------------------------------------------*/
int CVICALLBACK OpenFileBrowseFolder (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char Folder[MAX_PATHNAME_LEN];
	datastruct *dat;
	int retval, rng_cnt;
	
	switch (event)
		{
		case EVENT_COMMIT:
			dat = (datastruct*)callbackData;
			retval = DirSelectPopup (dat->qc0_Folder, "Select Directory for QC0 Files", 1, 0, Folder);
			if (retval == VAL_DIRECTORY_SELECTED)
			{
//				SplitPath (Folder, drive, path, tmpstr);
//				sprintf(dat->qc0_Folder, "%s%s", drive, path);
				strcpy(dat->qc0_Folder, Folder);
				UpdateStnList(panel, callbackData, Folder);
				GetNumListItems (openFile, OPEN_SITE, &rng_cnt);
				if (rng_cnt > 0)
				{
					SetCtrlVal(openFile, OPEN_SITE, 0);
					GetSiteInfo(openFile, OPEN_SITE, EVENT_COMMIT, callbackData, 0, 0); // force a callback to read the file
				}
			}
			
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

void UpdateStnList(int panel, void *callbackData, char *Folder)
{
	FILE *hFile;
	int i;
	int GetFileStatus = 0, index = 0;
	char FileName[MAX_PATHNAME_LEN];
	char ShrtFile[MAX_PATHNAME_LEN];
	char Folder_temp[MAX_PATHNAME_LEN];	
	char buf[260];
	char site_id[260];
	char *ptr;	
	struct listfilestruct *filelist_dat, *next_ptr, *save;
	qczstruct *qcz_dat;
	flagstruct *flags;

	filelist_dat 	= ((datastruct*)callbackData)->filelist_dat;
	qcz_dat 		= &((datastruct*)callbackData)->qcz_dat;
	flags 			= &((datastruct*)callbackData)->flags;
	
	/* empty the linked list */
	next_ptr = filelist_dat;
	while (next_ptr->next->next)
	{
		save = next_ptr->next;
		next_ptr->next = next_ptr->next->next;
		free(save);
	}
		
	ClearListCtrl (panel, OPEN_SITE);
	if (strcmp(Folder, "") == NULL)
		strcpy(Folder, ".\\");
	i=MakePathname (Folder, "*.QC0", Folder_temp);
//	strcat(Folder_holder, "\\");
	strcpy(qcz_dat->QC0_FileName, Folder);
//	strcat(Folder, "*.QC0");
	GetFileStatus = GetFirstFile (Folder_temp, 1, 0, 0, 0, 0, 0, ShrtFile);
	while (GetFileStatus == 0)
	{
		MakePathname(Folder, ShrtFile, FileName);
//		strcpy(Folder_temp, Folder_holder);
//		strcat(Folder_temp, FileName);
//		strcpy(FileName, Folder_temp);
		hFile = fopen(FileName, "r");
		if (hFile != NULL)
		{
			/* find the end of the list */
			next_ptr = filelist_dat;
			while (next_ptr->next->next != NULL)
			{
				next_ptr = next_ptr->next;
			}
			
			/* insert new record at the end */
			save = next_ptr->next;
			next_ptr->next = CNEW(1, struct listfilestruct);
			if (next_ptr->next == NULL)
				;//error
			next_ptr->next->next = save;
			strcpy(next_ptr->next->FilePath, FileName);
			
			fgets(buf, 254, hFile);
			ptr = strchr(buf, ':');
			if (ptr != NULL)
				strcpy(site_id, ptr+1);
			else
				; //error
			str_trim(site_id);
			InsertListItem (panel, OPEN_SITE, -1, site_id, index);
			index++;
			fclose(hFile);
			GetFileStatus = GetNextFile (ShrtFile);
		}
	}
	
	/* Sets QC0 flag and checks for both flags set.  If yes, then un-dim OK button. */
	flags->QC0_flag = 1;
	if (flags->QCF_flag == 1 && flags->QC0_flag == 1)
		SetCtrlAttribute (panel, OPEN_OK, ATTR_DIMMED, 0);			
}

int CVICALLBACK OpenFileNewSite (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			// load new panel with fields for location name, lat, long, & time zone
			newSite = LoadPanel (0, "WinQCF.uir", NEWSITE);

			/* Passes dat structure to subordinate callbacks. */
			SetCtrlAttribute (newSite, NEWSITE_BROWSE_QC0, ATTR_CALLBACK_DATA, callbackData);
			SetCtrlAttribute (newSite, NEWSITE_BROWSE_DATA, ATTR_CALLBACK_DATA, callbackData);
			SetCtrlAttribute (newSite, NEWSITE_SITE_ID, ATTR_CALLBACK_DATA, callbackData);
			SetCtrlAttribute (newSite, NEWSITE_OK, ATTR_CALLBACK_DATA, callbackData);
			SetCtrlAttribute (newSite, NEWSITE_CANCEL, ATTR_CALLBACK_DATA, callbackData);

			InstallPopup (newSite);

			// NewSiteOk will create and save new QC0 file
			// return user to openfile panel with new location name listed
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Reads in the QC0 file.                                          			 */
/*---------------------------------------------------------------------------*/
int ReadQC0 (void *callbackData)
{
	FILE *hFile;
	char inputline[260];
	char site_id[260];
	char C_3in[255];
	qczstruct *qcz_dat;
	sitestruct *site_dat;
	struct posdata *soldat;
	int i = 0, j = 0, ig, editPan;
	char *endptr, *title, *title2;
	char time[3];
	char C_mon3[12][4] = {"JAN", "FEB", "MAR", "APR", "MAY",
					"JUN", "JUL", "AUG", "SEP", "OCT",
					"NOV", "DEC"};
	
	qcz_dat 	= &((datastruct*)callbackData)->qcz_dat;
	site_dat 	= &((datastruct*)callbackData)->site_dat;
	soldat 		= ((datastruct*)callbackData)->soldat;

	hFile = fopen(qcz_dat->QC0_FileName, "r");
	if (hFile != NULL)
	{
		/* Gets the site name and trims off the white space. */
		fgets(inputline, 254, hFile);
		endptr = strchr(inputline, ':');
		if (endptr != NULL)
			strcpy(site_id, endptr+1);
		else
			; //error
		str_trim(site_id);
		
		/* allocates mem for site_dat->site_id and copies site id into it */
		if ((site_dat->site_desc = CNEW((strlen(site_id)+1), char)) == NULL)
			;//error
		strcpy (site_dat->site_desc, site_id);
		
		/* Sets info on main panel. */
		if ((title = CNEW((strlen(site_id)+9), char)) == NULL)
			;//error
		strcpy (title, site_id);
		strcat (title, " - QCFIT");
		SetPanelAttribute (mainPanel, ATTR_TITLE, title);
		SetCtrlVal (mainPanel, MAIN_MONTH, qcz_dat->Month);
		sprintf (time, "%d", soldat->interval);
		SetCtrlVal (mainPanel, MAIN_TIME, time);
				
		/* get Lat, Lon, and Time Zone for solpos */
		fscanf(hFile, "%*s %*s %lf\n", &site_dat->Lat);
		fscanf(hFile, "%*s %*s %lf\n", &site_dat->Lon);
		fscanf(hFile, "%*s %*s %*s %lf\n", &site_dat->TZone);

		/* inform solpos of the site parameters */
		soldat->latitude  = site_dat->Lat;
		soldat->longitude = site_dat->Lon;
		soldat->timezone  = site_dat->TZone;

		/* (Fast-forward to the month in question.)
			- adjusted to skip 5 comment lines - MAA */
		for (i=0;i<((qcz_dat->Month)+5);i++)
		{
			fgets(inputline, 254, hFile);
		}
		strncpy(C_3in,inputline,4);

		qcz_dat->Max_kn = (int)strtol(inputline+5, &endptr, 10);
		/* 971212 RJN Bug fix qcz_dat->Max_kt_1 = (int)strtol(endptr, &endptr, 10); */
		
		for (i = 0; i < 4; i++)
			qcz_dat->Max_kt[i] = (int)strtol(endptr+1, &endptr, 10); 
		
		for (i=0;i<3;i++)
		{
			qcz_dat->LeftShape[i] 	= (int)strtol(endptr+1, &endptr, 10);
			qcz_dat->LeftPos[i] 	= (int)strtol(endptr+1, &endptr, 10);
			qcz_dat->RightShape[i] 	= (int)strtol(endptr+1, &endptr, 10);
			for (j=0;j<4;j++)
			{
				qcz_dat->RightPos[i][j] = (int)strtol(endptr+1, &endptr, 10);
			}
		}
		
		/* compare month in line selected to C_mon3 month 
		listing to check for corrupted QC0 file. */
		if ( strncmp(C_3in,C_mon3[qcz_dat->Month],3) != 0 )
			nonfatal_error(QC0_FORMAT_ERROR, "Expected month not found");
		fclose(hFile);
	}
	else
	{
		nonfatal_error(FILE_OPEN_ERROR, "QC0 File");
		return 1;
	}

	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		switch (ig)
		{
			case 0:
				editPan = editLow;
				if ((title2 = CNEW((strlen(LOW_TITLE) + 1), char)) == NULL)
					advisory_error(MEM_ALLOC_ERROR, "Edit panel title initialization");
				title2 = LOW_TITLE;
				break;
			case 1:
				editPan = editMedium;
				if ((title2 = CNEW((strlen(MED_TITLE) + 1), char)) == NULL)
					advisory_error(MEM_ALLOC_ERROR, "Edit panel title initialization");
				title2 = MED_TITLE;
				break;
			case 2:
				editPan = editHigh;
				if ((title2 = CNEW((strlen(HI_TITLE) + 1), char)) == NULL)
					advisory_error(MEM_ALLOC_ERROR, "Edit panel title initialization");
				title2 = HI_TITLE;
				break;
		}

		/* initialize edit panel titles */
		if ((title = CNEW((strlen(site_dat->site_desc) + strlen(title2) + 1), char)) == NULL)
			advisory_error(MEM_ALLOC_ERROR, "Edit panel title initialization");
		strcpy (title, site_dat->site_desc);
		strcat (title, title2);
		SetPanelAttribute (editPan, ATTR_TITLE, title);
		free(title);

		/* initialize curve displays */
		SetCtrlVal (editPan, EDIT_CURVE_SHAPE_LEFT, 
					qcz_dat->LeftShape[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_POS_LEFT, 
					qcz_dat->LeftPos[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_SHAPE_RIGHT, 
					qcz_dat->RightShape[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_POS_RIGHT,
					qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]);
	}

	/* initialize kn_max, kt_max on edit panels */
	SetCtrlVal (editLow, EDIT_KN_MAX, qcz_dat->Max_kn);
	SetCtrlVal (editLow, EDIT_KT_MAX, qcz_dat->Max_kt[qcz_dat->RightPosIndex]);
	SetCtrlVal (editMedium, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][MED]));
	SetCtrlVal (editMedium, EDIT_KT_MAX, (qcz_dat->Max_kt[qcz_dat->RightPosIndex] - am_throt[KT][MED]));
	SetCtrlVal (editHigh, EDIT_KN_MAX, (qcz_dat->Max_kn - am_throt[KN][HI]));
	SetCtrlVal (editHigh, EDIT_KT_MAX, (qcz_dat->Max_kt[qcz_dat->RightPosIndex] - am_throt[KT][HI]));
	
	qcz_dat->chngflg = 0;
	
	return 0;
}


/*---------------------------------------------------------------------------*/
/* initializes the QCF linked lists.                             			 */
/*---------------------------------------------------------------------------*/
int ReInitLists(void *callbackData)
{
	int ib, id, ig, ix, iy, ip = 0;
	
	graphstruct *graph;
	pixelheader *pixel;
	densitystruct *density;
	qczstruct *qcz_dat;
	datastruct *dat;
	int waitPan;
	
	struct datalist *datapoint, *save;
	
	waitPan = LoadPanel (0, "WINQcf.uir", WAIT_PAN);
	InstallPopup(waitPan);
	
	/* reset yearlist for yearlist control */
	dat = (datastruct*)callbackData;
	free(dat->years);
	if ((dat->years = CNEW(1, char)) == NULL)
		;// error;
	strcpy(dat->years, "\0"); // empty string
	
	/* reset density variables */
	density = &((datastruct*)callbackData)->density;
	density->pixelMax 	= 0;
	density->pixelMin 	= 0;
	
	/* reset autofit scale */
	qcz_dat = &((datastruct*)callbackData)->qcz_dat;
	qcz_dat->Scale = 1.0;

	/* reset main data linked list */
	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		graph = &((datastruct*)callbackData)->graphs[ig];
		
		for (ip=0; ip<PLANE_CNT; ip++)
			for (id=0; id<DENSITY_RANGE; id++)
				for (ib=0; ib<2; ib++)
					graph->pix_count[ip][id][ib] = 0;
		
		for (ix=0; ix<XSIZE; ix++)
		{
			for (iy=0; iy<YSIZE; iy++)
			{
				for (ip=0; ip<PLANE_CNT; ip++)
				{
					pixel = &graph->phead[ix][iy][ip];
					datapoint = pixel->dathead->dat_next[ip];
					
					/* Free the list only on the last pass */
					if (ip == PLANE_CNT-1)
						while (datapoint->dat_next[ip] != NULL)
						{
							save = datapoint->dat_next[ip];
							if (ip == PLANE_CNT-1)
								free(datapoint);
							datapoint = save;
						}
				
					/* reset the tail */
					pixel->dathead->dat_next[ip] = pixel->dattail;

					/* initialize each pixel variable */
					pixel->count 		= 0;
					pixel->bndry_flg	= -1;
					pixel->density_val	= -9900;
					pixel->excluded		= 0;
					pixel->selected		= 0;
					if (*(pixel->years))  // has something other than null
					{
						free(pixel->years);
						if ((pixel->years 	= CNEW(1, char)) == NULL)
								;// error;
						strcpy(pixel->years, "\0"); // empty string
					}
				}
			}
		}
	}
	
	
	DiscardPanel(waitPan);
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Processes the QCF files.                                        			 */
/*---------------------------------------------------------------------------*/
int ProcessQCF(void *callbackData)
{
	FILE *hFile;
	QCFlinestruct line;
	filestruct *file_dat;
	qczstruct *qcz_dat;
	struct posdata *soldat;
	graphstruct *graph;
	pixelheader *pixel;
	datastruct *dat;
	struct monthfilestruct *filemonth, *tmpfm;
	struct datalist *datapoint, *ins_pt, *save;
	struct tm tblock;
	
	float kt = 0.0, kn = 0.0, kd = 0.0, kt1 = 0.0, kn1 = 0.0;
	int ikt = 0, ikn = 0, ikd = 0, ikt1 = 0, ikn1 = 0;
	int iFile, ip, iYear, QCZ_Month = 0;
	int retcode = 0;
	int gr_ndx = 0;
	int x[3], y[3];
	int retval;
	int filt_flg;	   /* flag for three-component filtering */
	int rng_cnt, rng_ndx;
	float filt_thrsh;  /* threshold for three-component filtering */
	char yr_tmp[6], yr_rng[6];
	char msg[100];
	
	int progHandle;
	char *yearlist_tmp;
	char tmpstr[MAX_PATHNAME_LEN], fname[MAX_PATHNAME_LEN];
	long fsize;

	// shortcut casts to the dat structure's elements.
	file_dat 	= &((datastruct*)callbackData)->file_dat;
	qcz_dat 	= &((datastruct*)callbackData)->qcz_dat;
	soldat 		= ((datastruct*)callbackData)->soldat;
	dat			= (datastruct*)callbackData;

	line.sec = 0;
	QCZ_Month = qcz_dat->Month;
	
	GetCtrlVal(mainPanel, MAIN_3_FILTER, &filt_flg);
	GetCtrlVal(mainPanel, MAIN_KS_THOLD, &filt_thrsh);
	
	/* prep year select ring control */
	ClearListCtrl (mainPanel, MAIN_YEAR);
	InsertListItem (mainPanel, MAIN_YEAR, -1, "All", 0);
	iYear = 1;
	progHandle = -1;
	retval = FEOF;
	
	if (file_dat->passflg < 1)
	{
		filemonth = file_dat->monthfiles[QCZ_Month].next;
		if (filemonth->next)
		{
			tmpfm = filemonth;
			while (tmpfm->filenum == tmpfm->next->filenum)
				tmpfm = tmpfm->next;
			fsize = tmpfm->endptr;
		}
		else
			fsize = 0;
	}

	
	for (iFile=0; iFile<file_dat->numFiles; iFile++)
	{
		/* on subsequent reads, bypass this file if it doesn't include this months data */
		if (file_dat->passflg < 1 && iFile != filemonth->filenum)
			continue;
			
		hFile = fopen(file_dat->MFileName[iFile], "r");
		if (hFile != NULL)
		{
			if (file_dat->passflg == 1)
			{
				/* get the file size */
				fseek (hFile, 0, SEEK_END);
				fsize = ftell (hFile);
				fseek (hFile, 0, SEEK_SET);
			}
			else
			{
				/* use only the portion of the file containing this months data */
				fseek (hFile, filemonth->begptr, SEEK_SET);
			}
			
			SplitPath (file_dat->MFileName[iFile], tmpstr, tmpstr, fname);
			if (!dat->cmdline)
			{
				if (progHandle >= 0)
					DiscardProgressDialog (progHandle);
				sprintf(tmpstr, "Loading File %s", fname);
				progHandle = CreateProgressDialog (tmpstr, "Percent Complete", 1,
												   VAL_FULL_MARKERS, "__Cancel");
			}
			
			while (!(retval = ReadQCF(hFile, iFile, &line, callbackData, QCZ_Month, progHandle, &fsize, file_dat))!= NULL)
			{
				
				soldat->year 	= line.yr;
				soldat->month 	= line.mon;
				soldat->day 	= line.day;
				soldat->hour 	= line.hr;
				soldat->minute 	= line.min;
				soldat->second 	= line.sec;
				
				retcode = midsol(soldat);
				if (retcode != 0)
				{
					sprintf(msg, "SolPos return code %d", retcode);
					nonfatal_error(SOLPOS_ERROR, msg);
				}

				if (soldat->zenref < ZEN_MAX)
				{
					/* check for valid data, then calc kd if ok */
					if (line.dif < MISS_VAL)
					{
						kd = line.dif / soldat->etr;
						/* if kd ok, check for valid line.dir.. if ok, calc kn and kt1 */
						if (line.dir < MISS_VAL)
						{
							kn 	= line.dir / soldat->etrn;
							kt1 = kn + kd;
						}
						/* if kn not ok, kn and kt1 missing */
						else
						{
							kn 	= MISS_K;
							kt1 = MISS_K;
						}
						/* if kd ok, check for valid line.glo.. if ok, calc kt and kn1 */
						if (line.glo < MISS_VAL)
						{
							kt 	= line.glo / soldat->etr;
							kn1 = kt - kd;
						}
						/* if kt not ok, kt and kn1 missing */
						else
						{
							kt 	= MISS_K;
							kn1 = MISS_K;
						}
					}
					/* if kd not ok, then kd, kt1, and kn1 missing */
					else
					{
						kd 	= MISS_K;
						kt1 = MISS_K;
						kn1 = MISS_K;
						/* check for valid data, then calc kn, otherwise kn missing */
						if (line.dir < MISS_VAL) // valid data
							kn = line.dir / soldat->etrn;
						else
							kn = MISS_K;
						/* check for valid data, then calc kt, otherwise kt missing */
						if (line.glo < MISS_VAL) // valid data
							kt = line.glo / soldat->etr;
						else
							kt = MISS_K;
					}
					/* calc indexes*/
					if (kd != MISS_K)
					{
						ikd = kd * 100;
						if (kn != MISS_K)
						{
							ikn 	= (int) RoundRealToNearestInteger(kn * 100.0);
							ikt1 	= (int) RoundRealToNearestInteger(kt1 * 100.0);
							ikn 	= MAX(ikn, 0);
							ikn 	= MIN(ikn, 100);
							ikt1 	= MAX(ikt1, 0);
							ikt1 	= MIN(ikt1, 100);
						}
						else
						{
							ikn 	= MISS_PIX;
							ikt1 	= MISS_PIX;
						}	
						if (kt != MISS_K)   
						{
							ikt 	= (int) RoundRealToNearestInteger(kt * 100.0);
							ikn1 	= (int) RoundRealToNearestInteger(kn1 * 100.0);
							ikt 	= MAX(ikt, 0);
							ikt 	= MIN(ikt, 100);
							ikn1 	= MAX(ikn1, 0);
							ikn1 	= MIN(ikn1, 100);
						}
						else
						{
							ikt 	= MISS_PIX;
							ikn1 	= MISS_PIX;
						}
					}
					else
					{
						ikt1 = MISS_PIX;
						ikn1 = MISS_PIX;
						if (kn != MISS_K)
						{
							ikn 	= (int) RoundRealToNearestInteger(kn * 100.0);
							ikn 	= MAX(ikn, 0);
							ikn 	= MIN(ikn, 100);
						}
						else
							ikn = MISS_PIX;
						if (kt != MISS_K)
						{
							ikt = (int) RoundRealToNearestInteger(kt * 100.0);
							ikt = MAX(ikt, 0);
							ikt = MIN(ikt, 100);						
						}
						else
							ikt = MISS_PIX;
					}
					
					tblock.tm_year 	= line.yr-1900;
					tblock.tm_mon 	= line.mon-1;
					tblock.tm_mday 	= line.day;
					tblock.tm_hour 	= line.hr-1;
					tblock.tm_min 	= line.min;
					tblock.tm_sec 	= line.sec;
					
					/* Airmass regimes: 0=Low, 1=Middle, 2=High */
					if 		(soldat->amass > 2.5)
						gr_ndx = HI;
					else if (soldat->amass > 1.25)
						gr_ndx = MED;
					else
						gr_ndx = LOW;

					datapoint = CNEW(1, struct datalist);
					if (datapoint == NULL)
						;//error
					datapoint->kt 		= kt;
					datapoint->kn 		= kn;
					datapoint->kd 		= kd;
					datapoint->filenum	= iFile;
					datapoint->fileptr 	= line.fp;
					datapoint->solzen 	= soldat->zenref;
					datapoint->date 	= mktime(&tblock);

					/* three component filtering */
					datapoint->excluded = 0;
					if (filt_flg)
						if (kt < MISS_K && kn < MISS_K && kd < MISS_K)
						{
							if (fabs(kt - kn - kd) > filt_thrsh)
								datapoint->excluded = 1;
							else
								;
						}
						else
							datapoint->excluded = 1;

					/* assign coordinate values */
					x[0] = ikt;
					y[0] = ikn;
					x[1] = ikt;
					y[1] = ikn1;
					x[2] = ikt1;
					y[2] = ikn;

					/* shortcut to appropriate graph */
					graph = &((datastruct*)callbackData)->graphs[gr_ndx];
					
					/* attach data point to a pixel on each plane */
					for(ip=0; ip<PLANE_CNT; ip++)
					{
						/* shortcut to the current pixel's year list */
						pixel = &graph->phead[x[ip]][y[ip]][ip];
					
						/* shortcut to the datapoint used in this iteration. */
						ins_pt 					= pixel->dathead;
						save 					= ins_pt->dat_next[ip];
						ins_pt->dat_next[ip] 	= datapoint;
						datapoint->dat_next[ip] = save;
							
						if (!datapoint->excluded)
						{
							/* increment the count of datapoints for the pixel. */
							pixel->count++;

							/* adds year to pixel's year list */
							sprintf(yr_tmp, "%d ", line.yr); // SMW added to initialize yr_tmp - 3/7/19
							if (strstr (pixel->years, yr_tmp) == NULL)
							{

								yearlist_tmp = pixel->years;
								if ((pixel->years = CNEW((strlen(yearlist_tmp)+7), char)) == NULL)
									;//error
								strcpy (pixel->years, yearlist_tmp);
								strcat (pixel->years, yr_tmp);
								free(yearlist_tmp);
							}
						}
					}
					
					/* adds year to dat's year list */
					if (!datapoint->excluded)
					{
						sprintf(yr_tmp, "%d ", line.yr);
						if (strstr (dat->years, yr_tmp) == NULL)
						{
							yearlist_tmp = dat->years;
							if ((dat->years = CNEW((strlen(yearlist_tmp)+7), char)) == NULL)
								;//error
							strcpy (dat->years, yearlist_tmp);
							strcat (dat->years, yr_tmp);
							free(yearlist_tmp);
						
							/* adds year to Year select ring control, sorted (after 'all' entry) */
							GetNumListItems (mainPanel, MAIN_YEAR, &rng_cnt);
							for (rng_ndx = 1; rng_ndx < rng_cnt; rng_ndx++)
							{
								/* find insertion point */
								GetLabelFromIndex (mainPanel, MAIN_YEAR, rng_ndx, yr_rng);
								str_trim(yr_tmp);
								if (strcmp(yr_tmp, yr_rng) < 0)
									break;
							}
							InsertListItem (mainPanel, MAIN_YEAR, rng_ndx, yr_tmp, iYear);
							iYear++;
						}
					}

				}
				if (retval == CANCEL)
					break;  // break out of the while loop
			}
		}
		else
			fatal_error(FILE_OPEN_ERROR, file_dat->MFileName[iFile]);
			
		if (file_dat->passflg < 1) // move to next record
		{
			filemonth = filemonth->next;
			while (filemonth->filenum == iFile)
				filemonth = filemonth->next;
			tmpfm = filemonth;
			while (tmpfm->next && tmpfm->filenum == tmpfm->next->filenum)
				tmpfm = tmpfm->next;
			fsize = tmpfm->endptr;
		}
	}
	if (progHandle >= 0)
		DiscardProgressDialog(progHandle);
	if (retval == CANCEL)
		ReInitLists(callbackData);
	else
		file_dat->passflg = 0;
	return 0;
}


/*--------------------------------------------------------------------------*/
/* Reads in the QCF files and controls the processing.						*/
/* This function is called from within the ProcessQCF function.				*/
/*--------------------------------------------------------------------------*/
int ReadQCF(FILE *hFile, int filenum, QCFlinestruct *line, void *callbackData, int QCZ_Month, 
            int progHandle, long *fsize, filestruct *filedat)
{
	int cancelled, progress, retval, retscan;
	static int oldprogress	= -1;
	static int oldmonth		= -1;
	static int oldfile		= -1;
	char inputline[260], dummy[100];
	struct monthfilestruct *tmpptr;
	static struct monthfilestruct *lstptr;

	retval = 0;
	line->mon = -1;
	cancelled = 0;
	
	if (filedat->passflg == 0)
	{
		lstptr = filedat->monthfiles[QCZ_Month].next;
		filedat->passflg = -1;
	}
	
	line->fp = ftell (hFile);
	fgets(inputline, 259, hFile);
	while (line->mon != (QCZ_Month+1) && !feof(hFile) && !cancelled)
	{	
		/* Read a line, including a dummy string at the end.   
		   Reject line if not exactly 8 elements (dummy would make it nine) */
		while ((retscan = sscanf(inputline, FORMAT, &line->yr, &line->mon, &line->day, 
				&line->hr, &line->min, /*&line->sec,*/ &line->glo, &line->dir, &line->dif, dummy)) != 8)
		{
			printf("Bad Line: %s\n", inputline);
			if (!feof(hFile))
				fgets(inputline, 259, hFile);
			else
				break;
		}
		
		if (retscan == 8)
		{
			if (progHandle >= 0)
			{
				progress = (int)((float)line->fp * 100.0 / (float)*fsize ) ;
				if (progress != oldprogress)
				{
					cancelled = UpdateProgressDialog (progHandle, progress, 1);
					oldprogress = progress;
				}
			}
		
			/* at month change, make new month file list record */
			if (filedat->passflg == 1)
			{
				if (line->mon != oldmonth || filenum != oldfile)
				{
					lstptr = &filedat->monthfiles[line->mon-1];
					while (lstptr->next->next)
						lstptr = lstptr->next;
					tmpptr = lstptr->next;
					lstptr->next = CNEW(1, struct monthfilestruct);
					lstptr->next->next = tmpptr;
					lstptr = lstptr->next;
					lstptr->begptr	= line->fp;
					lstptr->filenum	= filenum;
				
				}
				lstptr->endptr	= line->fp;
				oldmonth		= line->mon;
				oldfile			= filenum;
			}
			else // skip through the file to this month's data as needed (month data for other years)
			{
				if (line->fp > lstptr->endptr)
				{
					if (lstptr->filenum == lstptr->next->filenum)
					{
						lstptr = lstptr->next;
						fseek(hFile, lstptr->begptr, SEEK_SET);
					}
					else // new file or end of list; force end of file
					{
						fseek (hFile, 0, SEEK_END);
						fgets(inputline, 259, hFile);
						lstptr = lstptr->next;
					}
				}
			}
			line->fp = ftell (hFile);
			if (line->mon != (QCZ_Month+1))
				fgets(inputline, 259, hFile);
		}
		else
			fgets(inputline, 259, hFile);
		
	}
	
	/* if new month, make new month file list record */
	if (filedat->passflg == 1 && line->mon >= 0)
	{
		if ((line->mon != oldmonth) || filenum != oldfile)
		{
			lstptr = &filedat->monthfiles[line->mon-1];
			while (lstptr->next->next)
				lstptr = lstptr->next;
			tmpptr = lstptr->next;
			lstptr->next = CNEW(1, struct monthfilestruct);
			lstptr->next->next = tmpptr;
			lstptr = lstptr->next;
			lstptr->begptr	= line->fp;
			lstptr->filenum	= filenum;
			
		}
		lstptr->endptr	= line->fp;
		oldmonth		= line->mon;
		oldfile			= filenum;
	}
	
		

	if (line->yr < 100)
		if (line->yr > 50)
			line->yr += 1900;
		else
			line->yr += 2000;
	if (line->yr < 1950 || line->yr > 2050)
		;//error
	
	if (feof(hFile) || cancelled)
		oldprogress = -1;
	
	if (feof(hFile))
		retval = FEOF;
	if (cancelled)
		retval = CANCEL;
	return retval;
}


/* Plotting Module */
/*-----------------*/


/*---------------------------------------------------------------------------*/
/* Handles the density calculations (three types)							 */
/*---------------------------------------------------------------------------*/
int Density(void *callbackData)
{
	densitystruct *density;		/* shortcut to density structure */
	pixelheader *pixel;			/* shortcut to pixel header */
	datastruct *dat;			/* shortcut to data structure */
	graphstruct *graph;			/* shortcut to graph structure */
	
	int		ig, 				/* graph loop index */
			ip, 				/* plane loop index */
			ib,					/* boundary status */
			id,					/* density value */
			ix,					/* x axis loop index */
			iy,					/* y axis loop index */
			p_ctr,				/* pixel counter */
			u_ctr,				/* unique density counter */
			ndx,				/* array index */
			i,					/* utility integer */
			rng_lo,				/* low value in density range */
			rng_hi,				/* high value in density range */
			cutoff[DENSITY_RANGE-1]; /* density range cutoff */
		
	float	bin_size, 			/* size of the density bin */
			thresh,				/* current bin cutoff threshold */
			*cnt_array,			/* array of counts of density values */
			inc,				/* increment between density ranges */
			ratio,				/* ratio of pixel count to maximum */
			bin_ratio[DENSITY_RANGE-1]; /* threshold ratio values for each bin */

	dat		= (datastruct*)callbackData;
	
	density	= &dat->density;	

	/* initialize the category counters and range strings */
	for (ig = 0; ig < GRAPH_CNT; ig++)
		for (ip = 0; ip < PLANE_CNT; ip++)
			for (id = 0; id < DENSITY_RANGE; id++)
				for (ib = 0; ib < 2; ib++)
					dat->graphs[ig].pix_count[ip][id][ib] = 0;
	for (ip = 0; ip < PLANE_CNT; ip++)
		for (id = 0; id < DENSITY_RANGE-1; id++)
			strcpy(density->range[ip][id], "----   ");

	for (ip=0; ip<PLANE_CNT; ip++)
	{
		density->pixelMax 	= -2000000000;
		density->pixelMin 	= 2000000000;
		p_ctr				= 0;
		u_ctr				= 0;
		
		/* determine the min and max densities, and count the number of active pixels */
		for (ig=0; ig<GRAPH_CNT; ig++)
		{
			graph = &((datastruct*)callbackData)->graphs[ig];
			for (ix=XMIN; ix<XMAX; ix++)
				for (iy=YMIN; iy<YMAX; iy++)
				{
					pixel = &graph->phead[ix][iy][ip];
					if (pixel->count > 0 && !pixel->excluded)
					{
						density->pixelMax 	= MAX(density->pixelMax, pixel->count);
						density->pixelMin 	= MIN(density->pixelMin, pixel->count);
						p_ctr++;
					}
				}
		}

		/* make sure data exists somewhere in the graphs */
		if (density->pixelMax > 0)
		{
			/* Equal sized bins */
			if (density->d_func == DENS_EQ_FREQ)
			{
				/* allocate an array to hold all possible densities in the graphs */
				if ((cnt_array = CNEW(density->pixelMax+1, float)) == NULL)
					fatal_error(MEM_ALLOC_ERROR, "density count array");
		
				/* for each graph, count the frequency of each density encountered */
				ndx = 0;
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					graph = &((datastruct*)callbackData)->graphs[ig];
					for (ix=XMIN; ix<XMAX; ix++)
						for (iy=YMIN; iy<YMAX; iy++)
						{
							pixel = &graph->phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
								cnt_array[pixel->count]++;  // increment count for this density bin
						}
				}
	
				/* go through the density count array and create a cumulative frequency distribution */
				ndx			= 0;
				bin_size	= 1.0 / (float)(DENSITY_RANGE-1);
				thresh		= bin_size;
				
				/* initial values going into the loop */
				rng_lo		= density->pixelMin;
				cnt_array[ndx] /= (float)p_ctr;

				for (i = 1; i < density->pixelMax+1; i++)
				{
					cnt_array[i] /= (float)p_ctr;	/* normalize for frequency distribution */
					cnt_array[i] += cnt_array[i-1];	/* accumulate */
					if (i == density->pixelMax)  	/* roundoff may not add to 1.0 */
						cnt_array[i] = 1.0;
					while (cnt_array[i] >= thresh)  /* if bin threshold exceeded, mark the bin cutoff */
					{
						cutoff[ndx] = i;	  /* cutoff */
						rng_hi = i;			  /* high range of  bin */
						thresh += bin_size;   /* get the next bin threshold */
						if (cnt_array[i] >= thresh)   /* no data for current bin */
						{
							cutoff[ndx] = 0;  /* force cutoff to pass all data */
							sprintf(density->range[ip][ndx], "----   ");
						}
						else
						{
							if (rng_hi == rng_lo)
								sprintf(density->range[ip][ndx], "%d", rng_lo);
							else
								sprintf(density->range[ip][ndx], "%d-%d", rng_lo, rng_hi);
							rng_lo = rng_hi+1;
						}
					
						ndx++;
						while (ndx >= DENSITY_RANGE-1)  // keep ndx within bounds
							ndx--;
					}
				}
					
				
				/* if lower ranges are empty, move the first one to the lowest bin (better color distribution) */
				if (cutoff[0] == 0)
				{
					for (ndx = 1; ndx < DENSITY_RANGE-1; ndx++) // find first non-zero bin
						if (cutoff[ndx] != 0)
							break;
					
					/* move non-zero bin to lowest bin, then blank it */
					cutoff[0]	= cutoff[ndx];
					cutoff[ndx]	= 0;
					strcpy(density->range[ip][0], density->range[ip][ndx]);
					strcpy(density->range[ip][ndx], "----   ");
				}
						
				/* go through the graph and set the pixel density values based on the cutoffs */
				for (ig=0; ig<GRAPH_CNT; ig++)                                                                                                                                       
				{                                                                                                                                                                    
					graph = &((datastruct*)callbackData)->graphs[ig];                                                                                                                
					for (ix=XMIN; ix<XMAX; ix++)                                                                                                                                     
						for (iy=YMIN; iy<YMAX; iy++)                                                                                                                                 
						{                                                                                                                                                            	
							pixel = &graph->phead[ix][iy][ip];                                                                                                                       	
							if (pixel->count > 0 && !pixel->excluded)                                                                                                                                    	
							{
								for (ndx = 0; ndx < DENSITY_RANGE-1; ndx++) // look for cutoff
									if (pixel->count <= cutoff[ndx])
										break;
							
								/* assign this pixel's density value, then increment appropriate pixel count */
								if (pixel->density_val < DENSITY_RANGE-1) // don't do it for year filtering
									pixel->density_val = ndx;   	
								
								graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;                                                                                        	
							}                                                                                                                                                        	
						}                                                                                                                                                            	
				}
				free(cnt_array);
			}

			/* equal range density */
			else if (density->d_func == DENS_EQ_RANGE)
			{
				/* go through the graphs and calculate the density values based on proportional bins */
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					graph = &((datastruct*)callbackData)->graphs[ig];
					for (ix=XMIN; ix<XMAX; ix++)
					{
						for (iy=YMIN; iy<YMAX; iy++)
						{
							pixel = &graph->phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
							{
								if (pixel->density_val < DENSITY_RANGE-1) // don't do it for year filtering
								{
									pixel->density_val = (int)((float)(pixel->count - density->pixelMin) / (float)(density->pixelMax - density->pixelMin) * (float)(DENSITY_RANGE-1));
									if (pixel->density_val == DENSITY_RANGE-1)
										pixel->density_val--;
								}
								graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;
							}
						}
					}
				
				}
			
				/* determine the high and low ranges for each bin */
				rng_lo = density->pixelMin;
				inc = (float)(density->pixelMax - density->pixelMin + 1) / (float)(DENSITY_RANGE-1);
				for (i = 0; i < DENSITY_RANGE-1; i++)
				{
					rng_hi = RoundRealToNearestInteger(inc * (float)(i+1)) + density->pixelMin;
					if (rng_hi == rng_lo)
						strcpy(density->range[ip][i], "----   ");
					else if (rng_hi-1 == rng_lo)
						sprintf(density->range[ip][i], "%d", rng_lo);
					else
						sprintf(density->range[ip][i], "%d-%d", rng_lo, rng_hi-1);
					rng_lo = rng_hi;
				}
			}
		
			/* exponential density */
			else if (density->d_func == DENS_EXPONENTIAL)
			{
				for (i = 0; i < DENSITY_RANGE-1; i++)
					bin_ratio[i] = 1.0 / pow(density->factor, DENSITY_RANGE-2-i);
				
				/* go through the graphs and calculate the density values based on proportional bins */
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					graph = &((datastruct*)callbackData)->graphs[ig];
					for (ix=XMIN; ix<XMAX; ix++)
					{
						for (iy=YMIN; iy<YMAX; iy++)
						{
							pixel = &graph->phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
							{
								if (pixel->density_val < DENSITY_RANGE-1) // don't do it for year filtering
								{
									ratio = (float)(pixel->count - density->pixelMin) / (float)(density->pixelMax - density->pixelMin);
									for (i = 0; i < DENSITY_RANGE-1; i++)
									{
										if (ratio <= bin_ratio[i])
											break;
									}
									pixel->density_val = i;
									if (pixel->density_val == DENSITY_RANGE-1)
										pixel->density_val--;
									
								}
								graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;
							}
						}
					}
				
				}
			
				/* determine the high and low ranges for each bin */
				rng_lo = density->pixelMin;
				for (i = 0; i < DENSITY_RANGE-1; i++)
				{
					rng_hi = RoundRealToNearestInteger(density->pixelMax * bin_ratio[i]) + density->pixelMin;
					if (rng_hi == rng_lo && rng_lo != density->pixelMin)
						strcpy(density->range[ip][i], "----   ");
					else if (rng_hi == rng_lo && rng_lo)
						strcpy(density->range[ip][i], "----   ");
					else if (rng_hi-1 == rng_lo)
						sprintf(density->range[ip][i], "%d", rng_lo);
					else
						sprintf(density->range[ip][i], "%d-%d", rng_lo, rng_hi-1);
					rng_lo = rng_hi;
				}
			}
		
			/* No density */
			else if (density->d_func == DENS_OFF)
			{
				/* go through the graphs and mark each pixel density as zero */
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					graph = &((datastruct*)callbackData)->graphs[ig];
					for (ix=XMIN; ix<XMAX; ix++)
						for (iy=YMIN; iy<YMAX; iy++)
						{
							pixel = &graph->phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
							{
								if (pixel->density_val < DENSITY_RANGE-1) // don't do it for year filtering
								{
									pixel->density_val = 0;
									graph->pix_count[ip][pixel->density_val][pixel->bndry_flg]++;
								}
							}
						}
				}
				sprintf(density->range[ip][0], "%d-%d", density->pixelMin, density->pixelMax);
				for (i = 1; i < DENSITY_RANGE-1; i++)
					sprintf(density->range[ip][i], "----   ");
			}
			else
				fatal_error(INTERNAL_ERROR, "No density function selected");

		}
	}
	
	return 0;
}



/*---------------------------------------------------------------------------*/
/* Pulls up the multi-file browser window and inserts selected file names    */
/* into the FILENAME text box  File names are stored in the file_dat struct. */
/*---------------------------------------------------------------------------*/
int Plot (void *callbackData)
{
	datastruct *dat;
	graphstruct *graph;
	int ib, id, ig, ip, ix, iy, pc, control = 0, editPan;
	int iplot[DENSITY_RANGE][2];
	int color[DENSITY_RANGE][2] =
	{{DEN_0_OUT,		DEN_0_IN},
	 {DEN_1_OUT,		DEN_1_IN},
	 {DEN_2_OUT,		DEN_2_IN},
	 {DEN_3_OUT,		DEN_3_IN},
	 {DEN_4_OUT,		DEN_4_IN},
	 {VAL_DK_BLUE,		VAL_BLUE}};

	dat = (datastruct*)callbackData;
	ip	= dat->selPlane;

	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		graph = &((datastruct*)callbackData)->graphs[ig];

		/* initialize each counter to zero */
			for (id=0; id<DENSITY_RANGE; id++)
				for (ib=0; ib<2; ib++)
					iplot[id][ib] = 0;
		
		/* xData, yData init to NULL in qcf_init.  if not NULL here, will free them, then reallocate.
			otherwise, performs initial allocation. */
		for (id=0; id<DENSITY_RANGE; id++)
			for (ib=0; ib<2; ib++)
			{
				if (graph->xData[id][ib] != NULL)
				{
					free(graph->xData[id][ib]);
					graph->xData[id][ib] = NULL;
				}
				if (graph->yData[id][ib] != NULL)
				{
					free(graph->yData[id][ib]);
					graph->yData[id][ib] = NULL;
				}
				
				pc = graph->pix_count[ip][id][ib];
				if (pc > 0)
				{
					if ((graph->xData[id][ib] = CNEW(pc, int)) == NULL)
						;//error
					if ((graph->yData[id][ib] = CNEW(pc, int)) == NULL)
						;//error
				}
			}

		/* give x,y coordinate to x and y array for appropriate density range and boundry flag */
		for (ix=XMIN; ix<XMAX; ix++)
			for (iy=YMIN; iy<YMAX; iy++)
			{
				if(graph->phead[ix][iy][ip].count > 0 && !graph->phead[ix][iy][ip].excluded)
				{
					id = graph->phead[ix][iy][ip].density_val;
					ib = graph->phead[ix][iy][ip].bndry_flg;
					graph->xData[id][ib][iplot[id][ib]] = ix;
					graph->yData[id][ib][iplot[id][ib]] = iy;
					iplot[id][ib]++;
				}
			}

		/* choose plane */
		switch (ig)
		{
			case 0:
				control = MAIN_LOW_GRAPH;
				editPan = editLow;
				break;

			case 1:
				control = MAIN_MED_GRAPH;
				editPan = editMedium;
				break;

			case 2:
				control = MAIN_HIGH_GRAPH;
				editPan = editHigh;
				break;
		}
		
		/* Clear main and edit panel graphs */
		DeleteGraphPlot (mainPanel, control, -1, VAL_DELAYED_DRAW);
		DeleteGraphPlot (editPan, EDIT_GRAPH, -1, VAL_DELAYED_DRAW);

		/* delay drawing */
		SetCtrlAttribute (mainPanel, control, ATTR_REFRESH_GRAPH, 0);
		SetCtrlAttribute (editPan, EDIT_GRAPH, ATTR_REFRESH_GRAPH, 0);

		/* Plot diagonal on main and edit panels */
		PlotLine (mainPanel, control, 0, 0, 100, 100, VAL_BLACK);
		PlotLine (editPan, EDIT_GRAPH, 0, 0, 100, 100, VAL_BLACK);


		/* Plot data points */
		for (id=0; id<DENSITY_RANGE; id++)
			for (ib=0; ib<2; ib++)
				if (graph->pix_count[ip][id][ib] > 0)
				{
					PlotXY (mainPanel, control, graph->xData[id][ib], graph->yData[id][ib],
							graph->pix_count[ip][id][ib], VAL_INTEGER, VAL_INTEGER, 
							VAL_SCATTER, VAL_SOLID_CIRCLE, VAL_SOLID, 1, color[id][ib]);
					PlotXY (editPan, EDIT_GRAPH, graph->xData[id][ib], graph->yData[id][ib],
							graph->pix_count[ip][id][ib], VAL_INTEGER, VAL_INTEGER, VAL_SCATTER,
							VAL_SOLID_CIRCLE, VAL_SOLID, 1, color[id][ib]);
				}

		/* Plot boundary on main and edit panels */
		plot_boundary(dat, ig, mainPanel, control);
		plot_boundary(dat, ig, editPan, EDIT_GRAPH);

		/* refresh */
		SetCtrlAttribute (mainPanel, control, ATTR_REFRESH_GRAPH, 1);
		SetCtrlAttribute (editPan, EDIT_GRAPH, ATTR_REFRESH_GRAPH, 1);
	}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Displays the stats on the main and edit panels.		           			 */
/*---------------------------------------------------------------------------*/
int DisplayStats (void *callbackData)
{
	int ig, ip, rpi;
	int editPan;
	char string[3];

	datastruct *dat;
	statstruct *stats;
	qczstruct *qcz_dat;
	
	dat = (datastruct*)callbackData;
	qcz_dat = &dat->qcz_dat;
	ip = dat->selPlane;
	
	stats = &dat->graphs[LOW].stats[ip];
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_IN, stats->cnt_inside);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_OUT, stats->cnt_outside);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_ACT, stats->cnt_active);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_IGN, stats->cnt_invalid);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_TOT, stats->cnt_total);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_OUT_PERC, stats->error_out);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_R_PERC, stats->error_rgt);
	SetCtrlVal (mainPanel, MAIN_STAT_LOW_L_PERC, stats->error_lft);

	stats = &((datastruct*)callbackData)->graphs[MED].stats[ip];
	SetCtrlVal (mainPanel, MAIN_STAT_MED_IN, stats->cnt_inside);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_OUT, stats->cnt_outside);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_ACT, stats->cnt_active);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_IGN, stats->cnt_invalid);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_TOT, stats->cnt_total);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_OUT_PERC, stats->error_out);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_R_PERC, stats->error_rgt);
	SetCtrlVal (mainPanel, MAIN_STAT_MED_L_PERC, stats->error_lft);

	stats = &((datastruct*)callbackData)->graphs[HI].stats[ip];
	SetCtrlVal (mainPanel, MAIN_STAT_HI_IN, stats->cnt_inside);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_OUT, stats->cnt_outside);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_ACT, stats->cnt_active);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_IGN, stats->cnt_invalid);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_TOT, stats->cnt_total);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_OUT_PERC, stats->error_out);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_R_PERC, stats->error_rgt);
	SetCtrlVal (mainPanel, MAIN_STAT_HI_L_PERC, stats->error_lft);

	rpi = qcz_dat->RightPosIndex;
	sprintf (string, "%d", qcz_dat->Max_kn-am_throt[KN][LOW]);
	SetCtrlVal(mainPanel, MAIN_LOW_KN, string);
	sprintf (string, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][LOW]);
	SetCtrlVal(mainPanel, MAIN_LOW_KT, string);
	
	sprintf (string, "%d", qcz_dat->LeftShape[LOW]);
	SetCtrlVal(mainPanel, MAIN_LOW_L_SHAPE, string);
	sprintf (string, "%d", qcz_dat->LeftPos[LOW]);
	SetCtrlVal(mainPanel, MAIN_LOW_L_POS, string);
	sprintf (string, "%d", qcz_dat->RightShape[LOW]);
	SetCtrlVal(mainPanel, MAIN_LOW_R_SHAPE, string);
	sprintf (string, "%d", qcz_dat->RightPos[LOW][rpi]);
	SetCtrlVal(mainPanel, MAIN_LOW_R_POS, string);

	sprintf (string, "%d", qcz_dat->Max_kn-am_throt[KN][MED]);
	SetCtrlVal(mainPanel, MAIN_MED_KN, string);
	sprintf (string, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][MED]);
	SetCtrlVal(mainPanel, MAIN_MED_KT, string);
	
	sprintf (string, "%d", qcz_dat->LeftShape[MED]);
	SetCtrlVal(mainPanel, MAIN_MED_L_SHAPE, string);
	sprintf (string, "%d", qcz_dat->LeftPos[MED]);
	SetCtrlVal(mainPanel, MAIN_MED_L_POS, string);
	sprintf (string, "%d", qcz_dat->RightShape[MED]);
	SetCtrlVal(mainPanel, MAIN_MED_R_SHAPE, string);
	sprintf (string, "%d", qcz_dat->RightPos[MED][rpi]);
	SetCtrlVal(mainPanel, MAIN_MED_R_POS, string);

	sprintf (string, "%d", qcz_dat->Max_kn-am_throt[KN][HI]);
	SetCtrlVal(mainPanel, MAIN_HI_KN, string);
	sprintf (string, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][HI]);
	SetCtrlVal(mainPanel, MAIN_HI_KT, string);
	
	sprintf (string, "%d", qcz_dat->LeftShape[HI]);
	SetCtrlVal(mainPanel, MAIN_HI_L_SHAPE, string);
	sprintf (string, "%d", qcz_dat->LeftPos[HI]);
	SetCtrlVal(mainPanel, MAIN_HI_L_POS, string);
	sprintf (string, "%d", qcz_dat->RightShape[HI]);
	SetCtrlVal(mainPanel, MAIN_HI_R_SHAPE, string);
	sprintf (string, "%d", qcz_dat->RightPos[HI][rpi]);
	SetCtrlVal(mainPanel, MAIN_HI_R_POS, string);

	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		switch (ig)
		{
			case 0:
				editPan = editLow;
				break;
			case 1:
				editPan = editMedium;
				break;
			case 2:
				editPan = editHigh;
				break;
		}
		
		/* Set stats on edit panel. */
		stats = &dat->graphs[ig].stats[ip];
		SetCtrlVal (editPan, EDIT_STAT_IN, stats->cnt_inside);
		SetCtrlVal (editPan, EDIT_STAT_OUT, stats->cnt_outside);
		SetCtrlVal (editPan, EDIT_STAT_ACT, stats->cnt_active);
		SetCtrlVal (editPan, EDIT_STAT_IGN, stats->cnt_invalid);
		SetCtrlVal (editPan, EDIT_STAT_TOT, stats->cnt_total);
		SetCtrlVal (editPan, EDIT_STAT_OUT_PERC, stats->error_out);
		SetCtrlVal (editPan, EDIT_STAT_R_PERC, stats->error_rgt);
		SetCtrlVal (editPan, EDIT_STAT_L_PERC, stats->error_lft);
		
		/* make sure the curves are updated */
		SetCtrlVal (editPan, EDIT_KN_MAX, qcz_dat->Max_kn - am_throt[KN][ig]);
		SetCtrlVal (editPan, EDIT_KT_MAX, qcz_dat->Max_kt[rpi] - am_throt[KT][ig]);
		SetCtrlVal (editPan, EDIT_CURVE_SHAPE_LEFT, qcz_dat->LeftShape[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_SHAPE_RIGHT, qcz_dat->RightShape[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_POS_LEFT, qcz_dat->LeftPos[ig]);
		SetCtrlVal (editPan, EDIT_CURVE_POS_RIGHT, qcz_dat->RightPos[ig]);
		
	}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls curve ring control for left shape.			           			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditCurveShapeLeft (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, s_control;
	char string[3];
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/* set ig from edit panel title */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
			{
					ig = 0;
					s_control = MAIN_LOW_L_SHAPE;
			}
			else if (strstr(compare, MED_TITLE) != NULL)
			{
					ig = 1;
					s_control = MAIN_MED_L_SHAPE;
			}
			else if (strstr(compare, HI_TITLE) != NULL)
			{
					ig = 2;
					s_control = MAIN_HI_L_SHAPE;
			}
			else
				nonfatal_error(INTERNAL_ERROR, "Curve values not saved correctly.");

			GetCtrlVal (panel, control, &qcz_dat->LeftShape[ig]);
			sprintf (string, "%d", qcz_dat->LeftShape[ig]);
			SetCtrlVal(mainPanel, s_control, string);
			
			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);

			qcz_dat->chngflg = 1;

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls curve ring control for right shape.			           			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditCurveShapeRight (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, s_control;
	char string[3];
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/*  */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
			{
					ig = 0;
					s_control = MAIN_LOW_R_SHAPE;
			}
			else if (strstr(compare, MED_TITLE) != NULL)
			{
					ig = 1;
					s_control = MAIN_MED_R_SHAPE;
			}
			else if (strstr(compare, HI_TITLE) != NULL)
			{
					ig = 2;
					s_control = MAIN_HI_R_SHAPE;
			}
			else
				nonfatal_error(INTERNAL_ERROR, "Curve values not saved correctly.");

			GetCtrlVal (panel, control, &qcz_dat->RightShape[ig]);
			sprintf (string, "%d", qcz_dat->RightShape[ig]);
			SetCtrlVal(mainPanel, s_control, string);

			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);
			
			qcz_dat->chngflg = 1;

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls curve ring control for left position.		           			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditCurvePosLeft (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, s_control;
	char string[3];
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/*  */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
			{
					ig = 0;
					s_control = MAIN_LOW_L_POS;
			}
			else if (strstr(compare, MED_TITLE) != NULL)
			{
					ig = 1;
					s_control = MAIN_MED_L_POS;
			}
			else if (strstr(compare, HI_TITLE) != NULL)
			{
					ig = 2;
					s_control = MAIN_HI_L_POS;
			}
			else
				nonfatal_error(INTERNAL_ERROR, "Curve values not saved correctly.");

			GetCtrlVal (panel, control, &qcz_dat->LeftPos[ig]);
			sprintf (string, "%d", qcz_dat->LeftPos[ig]);
			SetCtrlVal(mainPanel, s_control, string);

			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);
			
			qcz_dat->chngflg = 1;

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Controls curve ring control for right position.		           			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditCurvePosRight (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, s_control;
	char string[3];
	char compare[260];
	qczstruct *qcz_dat;
	
	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/*  */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
			{
					ig = 0;
					s_control = MAIN_LOW_R_POS;
			}
			else if (strstr(compare, MED_TITLE) != NULL)
			{
					ig = 1;
					s_control = MAIN_MED_R_POS;
			}
			else if (strstr(compare, HI_TITLE) != NULL)
			{
					ig = 2;
					s_control = MAIN_HI_R_POS;
			}
			else
				nonfatal_error(INTERNAL_ERROR, "Curve values not saved correctly.");

			GetCtrlVal (panel, control, &qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]);
			sprintf (string, "%d", qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]);
			SetCtrlVal(mainPanel, s_control, string);

			BndryStatus(callbackData);
			Density(callbackData);
			DisplayStats (callbackData);
			Plot(callbackData);

			qcz_dat->chngflg = 1;

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


/*---------------------------------------------------------------------------*/
/* Doesn't do anything right now.						           			 */
/*---------------------------------------------------------------------------*/
void CVICALLBACK update_integ (int menuBar, int menuItem, void *callbackData,
		int panel)
{
}


/*---------------------------------------------------------------------------*/
/* Updates the curve indicators on the main and edit panels.       			 */
/*---------------------------------------------------------------------------*/
int UpdateCurveDisplay (void *callbackData, int panel, int ig)
{
	int pl_control, pr_control, sl_control, sr_control;
	char string [3];
	qczstruct *qcz_dat;

	qcz_dat = &((datastruct*)callbackData)->qcz_dat;

	/* set main panel curve display */
	if 		(ig == 0)
	{
		pl_control = MAIN_LOW_L_POS;
		pr_control = MAIN_LOW_R_POS;
		sl_control = MAIN_LOW_L_SHAPE;
		sr_control = MAIN_LOW_R_SHAPE;
	}
	else if (ig == 1)
	{
		pl_control = MAIN_MED_L_POS;
		pr_control = MAIN_MED_R_POS;
		sl_control = MAIN_MED_L_SHAPE;
		sr_control = MAIN_MED_R_SHAPE;
	}
	else if (ig == 2)
	{
		pl_control = MAIN_HI_L_POS;
		pr_control = MAIN_HI_R_POS;
		sl_control = MAIN_HI_L_SHAPE;
		sr_control = MAIN_HI_R_SHAPE;
	}

	/* update left pos */
	sprintf (string, "%d", qcz_dat->LeftPos[ig]);
	SetCtrlVal(mainPanel, pl_control, string);
	SetCtrlVal (panel, EDIT_CURVE_POS_LEFT, qcz_dat->LeftPos[ig]);
	/* update right pos */
	sprintf (string, "%d", qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]);
	SetCtrlVal(mainPanel, pr_control, string);
	SetCtrlVal (panel, EDIT_CURVE_POS_RIGHT, qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]);
	/* update left shape */
	sprintf (string, "%d", qcz_dat->LeftShape[ig]);
	SetCtrlVal(mainPanel, sl_control, string);
	SetCtrlVal (panel, EDIT_CURVE_SHAPE_LEFT, qcz_dat->LeftShape[ig]);
	/* update right shape */
	sprintf (string, "%d", qcz_dat->RightShape[ig]);
	SetCtrlVal(mainPanel, sr_control, string);
	SetCtrlVal (panel, EDIT_CURVE_SHAPE_RIGHT, qcz_dat->RightShape[ig]);

	return 0;
}


/*---------------------------------------------------------------------------*/
/* Updates the curve indicators on the main and edit panels.       			 */
/*---------------------------------------------------------------------------*/
int DensityLegend (void *callbackData)
{
	int ip;
	datastruct *dat;
	densitystruct *density;

	dat = (datastruct*)callbackData;
	density = &((datastruct*)callbackData)->density;

	ip = dat->selPlane;

	switch (density->d_func)
	{
		case DENS_OFF:
			SetCtrlAttribute (mainPanel, MAIN_DR0_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR2_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR3_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR4_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR0_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR2_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR3_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (mainPanel, MAIN_DR4_OUT, ATTR_VISIBLE, 0);
			break;
		case DENS_EQ_FREQ:
			SetCtrlAttribute (mainPanel, MAIN_DR0_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR0_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_OUT, ATTR_VISIBLE, 1);
			break;
		case DENS_EQ_RANGE:
			SetCtrlAttribute (mainPanel, MAIN_DR0_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR0_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_OUT, ATTR_VISIBLE, 1);
			break;
		case DENS_EXPONENTIAL:
			SetCtrlAttribute (mainPanel, MAIN_DR0_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_IN, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR0_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR1_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR2_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR3_OUT, ATTR_VISIBLE, 1);
			SetCtrlAttribute (mainPanel, MAIN_DR4_OUT, ATTR_VISIBLE, 1);
			break;
	}
	
	SetCtrlVal (mainPanel, MAIN_RANGE_0, density->range[ip][0]);
	SetCtrlVal (mainPanel, MAIN_RANGE_1, density->range[ip][1]);
	SetCtrlVal (mainPanel, MAIN_RANGE_2, density->range[ip][2]);
	SetCtrlVal (mainPanel, MAIN_RANGE_3, density->range[ip][3]);
	SetCtrlVal (mainPanel, MAIN_RANGE_4, density->range[ip][4]);

	return 0;
}


/*---------------------------------------------------------------------------*/
/* Updates the curve indicators on the main and edit panels.       			 */
/*---------------------------------------------------------------------------*/
int CVICALLBACK EditNarrowAndWide (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig;
	char compare[260];
	qczstruct *qcz_dat;

	switch (event)
		{
		case EVENT_COMMIT:
			/* shortcuts */
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			/* Set ig based on title of panel. */
			GetPanelAttribute (panel, ATTR_TITLE, compare);
			if 		(strstr(compare, LOW_TITLE) != NULL)
					ig = 0;
			else if (strstr(compare, MED_TITLE) != NULL)
					ig = 1;
			else if (strstr(compare, HI_TITLE) != NULL)
					ig = 2;
			else
					nonfatal_error(INTERNAL_ERROR, "Air mass incorrectly detected.  Err adjustment corrupted.");

			/* determine appropriate action based on control used. */
			switch (control)
			{
				case EDIT_NAR_LEFT:
					qcz_dat->LeftPos[ig]++;
					break;
					
				case EDIT_NAR_RIGHT:
					qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]--;
					break;
					
				case EDIT_NAR_BOTH:
					qcz_dat->LeftPos[ig]++;
					qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]--;
					break;
					
				case EDIT_WIDE_LEFT:
					qcz_dat->LeftPos[ig]--;
					break;
					
				case EDIT_WIDE_RIGHT:
					qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]++;
					break;
					
				case EDIT_WIDE_BOTH:
					qcz_dat->LeftPos[ig]--;
					qcz_dat->RightPos[ig][qcz_dat->RightPosIndex]++;
					break;
			}
			
			/* limit the excursion to defined values */
			qcz_dat->LeftPos[ig] = MAX(qcz_dat->LeftPos[ig], 1);
			qcz_dat->LeftPos[ig] = MIN(qcz_dat->LeftPos[ig], 20);
			qcz_dat->RightPos[ig][qcz_dat->RightPosIndex] = MAX(qcz_dat->RightPos[ig][qcz_dat->RightPosIndex], 1);
			qcz_dat->RightPos[ig][qcz_dat->RightPosIndex] = MIN(qcz_dat->RightPos[ig][qcz_dat->RightPosIndex], 20);
			
			/* update display */
			BndryStatus(callbackData);
			Density(callbackData);	  // required for the stats
			DisplayStats (callbackData);
			UpdateCurveDisplay (callbackData, panel, ig);
			Plot(callbackData);

			qcz_dat->chngflg = 1;

		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}


int SetupPrintPanel (void *callbackData)
{
	/* plotting declarations */
	int ib, id, ig, ip, control = 0, rpi;
	int color[DENSITY_RANGE][2] =
	{{DEN_0_OUT,		DEN_0_IN},
	 {DEN_1_OUT,		DEN_1_IN},
	 {DEN_2_OUT,		DEN_2_IN},
	 {DEN_3_OUT,		DEN_3_IN},
	 {DEN_4_OUT,		DEN_4_IN},
	 {DEN_Y_OUT,		DEN_Y_IN}};

	/* location-month title declarations */
	int temp = 0;
	float tmpval;
	char *string;
	char stat[3];
	char tmpstr[1000];
	char Months[12][10] = {"January", "February", "March", "April", "May",
						"June", "July", "August", "September", "October",
						"November", "December"};

	/* struct shortcut declarations */
	datastruct *dat;
	sitestruct *site_dat;
	graphstruct *graph;
	statstruct *stats;
	qczstruct *qcz_dat;
	densitystruct *density;
	freqplotstruct *freqplot;
	struct posdata *soldat;
	
	/* shortcuts */
	dat = (datastruct*)callbackData;
	site_dat = &dat->site_dat;
	soldat = dat->soldat;
	qcz_dat = &dat->qcz_dat;
	density = &dat->density;
	freqplot = &dat->freqplot;

	/* get plane */
	ip	= dat->selPlane;

	/* set location-month title */
	if ((string = CNEW((strlen(site_dat->site_desc)+13), char)) == NULL)
		;//error
	strcpy (string, site_dat->site_desc);
	strcat (string, " - ");
	GetCtrlVal (mainPanel, MAIN_MONTH, &temp);
	strcat (string, Months[temp]);
	SetCtrlVal (printPan, PRINT_TITLE_LOCATION, string);
	
	/* set plane title */
	switch (ip)
	{
		case 0:
			SetCtrlVal (printPan, PRINT_PLANE, "Global / Direct");
			break;
		case 1:
			SetCtrlVal (printPan, PRINT_PLANE, "Global / Diffuse");
			break;
		case 2:
			SetCtrlVal (printPan, PRINT_PLANE, "Diffuse / Direct");
			break;
	}
	
	/* set 3 comp filtering */
	GetCtrlVal (mainPanel, MAIN_3_FILTER, &temp);
	switch (temp)
	{
		case OFF:
			SetCtrlVal (printPan, PRINT_3_COMP, "Off");
			SetCtrlVal (printPan, PRINT_KS_THOLD, "----");
			break;
		case ON:
			SetCtrlVal (printPan, PRINT_3_COMP, "On");
			GetCtrlVal (mainPanel, MAIN_KS_THOLD, &tmpval);
			sprintf(tmpstr, "%0.3f", tmpval);
			SetCtrlVal (printPan, PRINT_KS_THOLD, tmpstr);
			break;
	}

	/* set integration time */
	sprintf (stat, "%d", soldat->interval);
	SetCtrlVal (printPan, PRINT_TIME, stat);
	
	/* set input file */
	strcpy(tmpstr, dat->file_dat.MFileName[0]);
	if (dat->file_dat.numFiles > 1)
		strcat(tmpstr,  " (+)");
	SetCtrlVal(printPan, PRINT_INFILE, tmpstr);
		
	/* set density legend */
	switch (density->d_func)
	{
		case DENS_OFF:
			SetCtrlVal (printPan, PRINT_DENS_MODE, "Density Off");
			SetCtrlAttribute (printPan, PRINT_DENS_BKGRND, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DENSITY, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_RANGE_0, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_RANGE_1, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_RANGE_2, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_RANGE_3, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_RANGE_4, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR0_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR1_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR2_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR3_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR4_IN, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR0_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR1_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR2_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR3_OUT, ATTR_VISIBLE, 0);
			SetCtrlAttribute (printPan, PRINT_DR4_OUT, ATTR_VISIBLE, 0);
			break;
		case DENS_EQ_FREQ:
			SetCtrlVal (printPan, PRINT_DENS_MODE, "Equal Freq");
			SetCtrlVal (printPan, PRINT_RANGE_0, density->range[ip][0]);
			SetCtrlVal (printPan, PRINT_RANGE_1, density->range[ip][1]);
			SetCtrlVal (printPan, PRINT_RANGE_2, density->range[ip][2]);
			SetCtrlVal (printPan, PRINT_RANGE_3, density->range[ip][3]);
			SetCtrlVal (printPan, PRINT_RANGE_4, density->range[ip][4]);
			break;
		case DENS_EQ_RANGE:
			SetCtrlVal (printPan, PRINT_DENS_MODE, "Equal Range");
			SetCtrlVal (printPan, PRINT_RANGE_0, density->range[ip][0]);
			SetCtrlVal (printPan, PRINT_RANGE_1, density->range[ip][1]);
			SetCtrlVal (printPan, PRINT_RANGE_2, density->range[ip][2]);
			SetCtrlVal (printPan, PRINT_RANGE_3, density->range[ip][3]);
			SetCtrlVal (printPan, PRINT_RANGE_4, density->range[ip][4]);
			break;
		case DENS_EXPONENTIAL:
			sprintf(tmpstr, "Exponential (%0.1f)", density->factor);
			SetCtrlVal (printPan, PRINT_DENS_MODE, tmpstr);
			SetCtrlVal (printPan, PRINT_RANGE_0, density->range[ip][0]);
			SetCtrlVal (printPan, PRINT_RANGE_1, density->range[ip][1]);
			SetCtrlVal (printPan, PRINT_RANGE_2, density->range[ip][2]);
			SetCtrlVal (printPan, PRINT_RANGE_3, density->range[ip][3]);
			SetCtrlVal (printPan, PRINT_RANGE_4, density->range[ip][4]);
			break;
	}
	
	/* set curves */
	rpi = qcz_dat->RightPosIndex;
	sprintf (stat, "%d", qcz_dat->Max_kn-am_throt[KN][LOW]);
	SetCtrlVal(printPan, PRINT_LOW_KN, stat);
	sprintf (stat, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][LOW]);
	SetCtrlVal(printPan, PRINT_LOW_KT, stat);
	
	sprintf (stat, "%d", qcz_dat->LeftShape[LOW]);
	SetCtrlVal(printPan, PRINT_LOW_L_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->LeftPos[LOW]);
	SetCtrlVal(printPan, PRINT_LOW_L_POS, stat);
	sprintf (stat, "%d", qcz_dat->RightShape[LOW]);
	SetCtrlVal(printPan, PRINT_LOW_R_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->RightPos[LOW][rpi]);
	SetCtrlVal(printPan, PRINT_LOW_R_POS, stat);

	sprintf (stat, "%d", qcz_dat->Max_kn-am_throt[KN][MED]);
	SetCtrlVal(printPan, PRINT_MED_KN, stat);
	sprintf (stat, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][MED]);
	SetCtrlVal(printPan, PRINT_MED_KT, stat);
	
	sprintf (stat, "%d", qcz_dat->LeftShape[MED]);
	SetCtrlVal(printPan, PRINT_MED_L_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->LeftPos[MED]);
	SetCtrlVal(printPan, PRINT_MED_L_POS, stat);
	sprintf (stat, "%d", qcz_dat->RightShape[MED]);
	SetCtrlVal(printPan, PRINT_MED_R_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->RightPos[MED][rpi]);
	SetCtrlVal(printPan, PRINT_MED_R_POS, stat);

	sprintf (stat, "%d", qcz_dat->Max_kn-am_throt[KN][HI]);
	SetCtrlVal(printPan, PRINT_HI_KN, stat);
	sprintf (stat, "%d", qcz_dat->Max_kt[rpi]-am_throt[KT][HI]);
	SetCtrlVal(printPan, PRINT_HI_KT, stat);
	
	sprintf (stat, "%d", qcz_dat->LeftShape[HI]);
	SetCtrlVal(printPan, PRINT_HI_L_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->LeftPos[HI]);
	SetCtrlVal(printPan, PRINT_HI_L_POS, stat);
	sprintf (stat, "%d", qcz_dat->RightShape[HI]);
	SetCtrlVal(printPan, PRINT_HI_R_SHAPE, stat);
	sprintf (stat, "%d", qcz_dat->RightPos[HI][rpi]);
	SetCtrlVal(printPan, PRINT_HI_R_POS, stat);
	
	/* set stats */
	stats = &((datastruct*)callbackData)->graphs[LOW].stats[ip];
	SetCtrlVal (printPan, PRINT_STAT_LOW_IN, stats->cnt_inside);
	SetCtrlVal (printPan, PRINT_STAT_LOW_OUT, stats->cnt_outside);
	SetCtrlVal (printPan, PRINT_STAT_LOW_ACT, stats->cnt_active);
	SetCtrlVal (printPan, PRINT_STAT_LOW_IGN, stats->cnt_invalid);
	SetCtrlVal (printPan, PRINT_STAT_LOW_TOT, stats->cnt_total);
	SetCtrlVal (printPan, PRINT_STAT_LOW_OUT_PERC, stats->error_out);
	SetCtrlVal (printPan, PRINT_STAT_LOW_R_PERC, stats->error_rgt);
	SetCtrlVal (printPan, PRINT_STAT_LOW_L_PERC, stats->error_lft);

	stats = &((datastruct*)callbackData)->graphs[MED].stats[ip];
	SetCtrlVal (printPan, PRINT_STAT_MED_IN, stats->cnt_inside);
	SetCtrlVal (printPan, PRINT_STAT_MED_OUT, stats->cnt_outside);
	SetCtrlVal (printPan, PRINT_STAT_MED_ACT, stats->cnt_active);
	SetCtrlVal (printPan, PRINT_STAT_MED_IGN, stats->cnt_invalid);
	SetCtrlVal (printPan, PRINT_STAT_MED_TOT, stats->cnt_total);
	SetCtrlVal (printPan, PRINT_STAT_MED_OUT_PERC, stats->error_out);
	SetCtrlVal (printPan, PRINT_STAT_MED_R_PERC, stats->error_rgt);
	SetCtrlVal (printPan, PRINT_STAT_MED_L_PERC, stats->error_lft);

	stats = &((datastruct*)callbackData)->graphs[HI].stats[ip];
	SetCtrlVal (printPan, PRINT_STAT_HI_IN, stats->cnt_inside);
	SetCtrlVal (printPan, PRINT_STAT_HI_OUT, stats->cnt_outside);
	SetCtrlVal (printPan, PRINT_STAT_HI_ACT, stats->cnt_active);
	SetCtrlVal (printPan, PRINT_STAT_HI_IGN, stats->cnt_invalid);
	SetCtrlVal (printPan, PRINT_STAT_HI_TOT, stats->cnt_total);
	SetCtrlVal (printPan, PRINT_STAT_HI_OUT_PERC, stats->error_out);
	SetCtrlVal (printPan, PRINT_STAT_HI_R_PERC, stats->error_rgt);
	SetCtrlVal (printPan, PRINT_STAT_HI_L_PERC, stats->error_lft);

	/* plot graphs */
	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		graph = &((datastruct*)callbackData)->graphs[ig];

		/* choose plane */
		switch (ig)
		{
			case 0:
				control = PRINT_LOW_GRAPH;
				break;

			case 1:
				control = PRINT_MED_GRAPH;
				break;

			case 2:
				control = PRINT_HIGH_GRAPH;
				break;
		}
		
		/* Clear main and edit panel graphs */
		DeleteGraphPlot (printPan, control, -1, VAL_IMMEDIATE_DRAW);

		/* Plot diagonal on main and edit panels */
		PlotLine (printPan, control, 0, 0, 100, 100, VAL_BLACK);

		/* Plot data points */
		for (id=0; id<DENSITY_RANGE; id++)
			for (ib=0; ib<2; ib++)
				if (graph->pix_count[ip][id][ib] > 0)
				{
					PlotXY (printPan, control, graph->xData[id][ib], graph->yData[id][ib],
							graph->pix_count[ip][id][ib], VAL_INTEGER, VAL_INTEGER, 
							VAL_SCATTER, VAL_SOLID_CIRCLE, VAL_SOLID, 1, color[id][ib]);
				}

		/* Plot boundary on main and edit panels */
		plot_boundary(dat, ig, printPan, control);
	}

	/* do the frequency plot */
	if (freqplot->dat_cnt > 0)
	{
		PlotXY (printPan, PRINT_FPLOT, freqplot->xData, freqplot->yData, BINMAX, VAL_FLOAT,
								VAL_FLOAT, VAL_VERTICAL_BAR, VAL_NO_POINT, VAL_SOLID, 1, VAL_DK_BLUE);
		for (ig = 0; ig < GRAPH_CNT; ig++)
		{
			if (freqplot->key_cnt[ig] > 0)
			{
				PlotXY (printPan, PRINT_FPLOT, freqplot->keydatX[ig], freqplot->keydatY[ig], 2, VAL_FLOAT, VAL_FLOAT,
						VAL_FAT_LINE, VAL_NO_POINT, VAL_SOLID, 1, freqplot->colors[ig]);

				/* set the key colors */
				switch(ig)
				{
					case 0: control = PRINT_KEY_LO;
						break;
					case 1: control = PRINT_KEY_MED;
						break;
					case 2: control = PRINT_KEY_HI;
						break;
				}
			
				SetCtrlAttribute (printPan, control, ATTR_FRAME_COLOR, freqplot->colors[ig]);
			}
		}
	}
	else
		SetCtrlAttribute (printPan, PRINT_NODAT, ATTR_VISIBLE, 1);

	/* auto scaling doesn't work for the bitmap functions; have to set the scaling manually */
	SetAxisScalingMode (printPan, PRINT_FPLOT, VAL_LEFT_YAXIS, VAL_MANUAL,
						0.0, freqplot->binmax);
	
	return 0;

}

int CVICALLBACK NewSiteOk (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	FILE *hFile;
	int i;
	int status;
	int im;
	int site_id_len = 0;
	int str_len;
	int integ;
	int editing;
	int rng_cnt, rng_ndx;
	int plane_array[3] = {NEWSITE_PLANE0, NEWSITE_PLANE1, NEWSITE_PLANE2};
	float thold;
	char Folder[MAX_PATHNAME_LEN];
	char site[260], site_rng[260];
	char tmpstr[200];
	char *str;
	char C_mon3[12][4] = {"JAN", "FEB", "MAR", "APR", "MAY",
					"JUN", "JUL", "AUG", "SEP", "OCT",
					"NOV", "DEC"};
	
	datastruct *dat;
	qczstruct *qcz_dat;
	sitestruct *site_dat;
	flagstruct *flags;

	switch (event)
		{
		case EVENT_COMMIT:
			dat = (datastruct*)callbackData;
			qcz_dat = &dat->qcz_dat;
			site_dat = &dat->site_dat;
			flags = &dat->flags;

			/* get site id for qczstruct */
			GetCtrlVal (panel, NEWSITE_SITE_ID, site_dat->Site);

			/* alloc mem for site_dat->site_id and get value from control */
			if (GetTextBoxLineLength (panel, NEWSITE_SITE_DESC, 0, &site_id_len) != 0)
				site_id_len = 0;
			if ((site_dat->site_desc = CNEW((site_id_len+1), char)) == NULL)
				;//error
			GetCtrlVal (panel, NEWSITE_SITE_DESC, site_dat->site_desc);

			/* get tzone, lat and lon for qczstruct */
			GetCtrlVal (panel, NEWSITE_TZONE, &site_dat->TZone);
			GetCtrlVal (panel, NEWSITE_LAT, &site_dat->Lat);
			GetCtrlVal (panel, NEWSITE_LON, &site_dat->Lon);

			/* generate file name */
			strcpy (Folder, "\0");
			GetCtrlVal (panel, NEWSITE_QC0_PATH, Folder);
			strcat (Folder, "\\s_");
			strcat (Folder, site_dat->Site);
			strcat (Folder, ".QC0");
			strcpy (qcz_dat->QC0_FileName, Folder);
			
			GetCtrlVal (panel, NEWSITE_DAT_PATH, Folder);
			GetCtrlVal (panel, NEWSITE_INTEGRATION, &integ);

			/* open new file stream and create new QC0 file */
			hFile = fopen (qcz_dat->QC0_FileName, "wt");

			fprintf(hFile, "  Site Identifier: %s, %s\n",  site_dat->Site, site_dat->site_desc);
			fprintf(hFile, " --- Latitude: %9.4f\n", site_dat->Lat);
			fprintf(hFile, " -- Longitude: %9.4f\n", site_dat->Lon);
			fprintf(hFile, " -- Time Zone: %9.4f\n\n", site_dat->TZone);
			fprintf(hFile, "     ---Max Code---  ---Low Airmass---   --Medium Airmass--  ---High Airmass---\n");
			fprintf(hFile, "     KN ----KT-----  Left ----Right----  Left ----Right----  Left ----Right----\n");
			fprintf(hFile, "         1  5 15 60  S  P S  1  5 15 60  S  P S  1  5 15 60  S  P S  1  5 15 60\n");
			
			/* if the curves box is empty, fill it with zero curves\
			   (if not empty, it's been filled from the edit function) */
			GetCtrlAttribute (panel, NEWSITE_CURVES, ATTR_STRING_TEXT_LENGTH, &str_len);
			if (str_len == 0)
			{
				for (im=0; im<12; im++)
				{
					sprintf(tmpstr, "%s: 00-00/00/00/00; 0-00 0-00/00/00/00; 0-00 0-00/00/00/00; 0-00 0-00/00/00/00\n", C_mon3[im]); 
					SetCtrlVal(panel, NEWSITE_CURVES, tmpstr);
				}
				editing = 0;
			}
			else
				editing = 1;

			/* write out the curves (if new site, there will be none) */
			GetCtrlAttribute (panel, NEWSITE_CURVES, ATTR_STRING_TEXT_LENGTH, &str_len);
			if (str_len > 0)
			{
				fprintf(hFile, "\n");
				if ((str = CNEW(str_len+1, char)) == NULL)
					nonfatal_error(MEM_ALLOC_ERROR, "list_save");
				else
				{
					GetCtrlVal(panel, NEWSITE_CURVES, str);
					fputs(str, hFile);
					free(str);
				}
			}

			/* defaults */
			
			/* get the plane control and configure the output string */
			for (i = 0; i < 3; i++)
			{
				GetCtrlVal(panel, plane_array[i], &status);
				if (status)
					break;
			}
			if (i == 3)
				nonfatal_error(INTERNAL_ERROR, "New Site Plane");
			
			switch (plane_array[i])
			{
				case NEWSITE_PLANE0:
					strcpy(tmpstr, "0 Kt-Kn");
					break;
				
				case NEWSITE_PLANE1:
					strcpy(tmpstr, "1 Kt-Kd");
					break;
				
				case NEWSITE_PLANE2:
					strcpy(tmpstr, "2 Kn-Kd");
					break;
			}
			
			/* get the 3-component filter status and value */
			GetCtrlVal (panel, NEWSITE_3_FILTER, &status);
			GetCtrlVal (panel, NEWSITE_KS_THOLD, &thold);
			
			fprintf(hFile, "\n%s\n",    DFLT_0);
			fprintf(hFile, " %s %2d\n", DFLT_1, integ);
			fprintf(hFile, " %s %s\n",  DFLT_2, Folder);
			fprintf(hFile, " %s %s\n",  DFLT_3, tmpstr);
			fprintf(hFile, " %s %f\n",  DFLT_4, status ? thold : -1.0);  // -1 if filter is off
									    
			
			GetCtrlAttribute (panel, NEWSITE_COMMENTS, ATTR_STRING_TEXT_LENGTH, &str_len);
			
			if (str_len > 0)
			{
				fprintf(hFile, "\n");
				if ((str = CNEW(str_len+1, char)) == NULL)
					nonfatal_error(MEM_ALLOC_ERROR, "list_save");
				else
				{
					GetCtrlVal(panel, NEWSITE_COMMENTS, str);
					fputs(str, hFile);
					if (*(str+strlen(str)-1) != '\n') // always terminate file with newline
						fputs("\n", hFile);
					free(str);
				}
			}

			fclose(hFile);

			if (!editing)
			{
				/* update the site ring control, then select the new site */
				sprintf(site, "%s, %s", site_dat->Site, site_dat->site_desc);
				str_trim(site);
				UpdateStnList(openFile, callbackData, dat->qc0_Folder);

				/* Locate the site in the list and force a selection */
				GetNumListItems (openFile, OPEN_SITE, &rng_cnt);
				for (rng_ndx = 1; rng_ndx < rng_cnt; rng_ndx++)
				{
					/* find insertion point */
					GetLabelFromIndex (openFile, OPEN_SITE, rng_ndx, site_rng);
					str_trim(site_rng);
					if (strcmp(site, site_rng) == 0)
						break;
				}
				SetCtrlVal(openFile, OPEN_SITE, rng_ndx);
				GetSiteInfo(openFile, OPEN_SITE, EVENT_COMMIT, callbackData, 0, 0); // force a callback to read the file
//				ClearListCtrl (openFile, OPEN_SITE);
//				InsertListItem (openFile, OPEN_SITE, -1, site, 0);

				/* Sets QC0 flag and checks for both flags set.  If yes, then un-dim OK button. */
				flags->QC0_flag = 1;
				if (flags->QCF_flag == 1 && flags->QC0_flag == 1)
					SetCtrlAttribute (panel, OPEN_OK, ATTR_DIMMED, 0);
				
				flags->NewSiteCreated = 1;
			}
			free(site_dat->site_desc);

			DiscardPanel (panel);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

int CVICALLBACK NewSiteQC0Path (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char Folder[MAX_PATHNAME_LEN];
	datastruct *dat;

	qczstruct *qcz_dat;
	flagstruct *flags;

	switch (event)
		{
		case EVENT_COMMIT:
			dat		= (datastruct*)callbackData;
			qcz_dat	= &dat->qcz_dat;
			flags	= &dat->flags;

			DirSelectPopup (dat->qc0_Folder, "Select Directory Location to save QC0 File", 1,
							1, Folder);
			/* save the user's selected path */
			strcpy(dat->qc0_Folder, Folder);
			SetCtrlVal (panel, NEWSITE_QC0_PATH, Folder);

			/* if all info is set, undim Ok. */
			flags->NewSitePath = 1;
			if (flags->NewSitePath == 1 && flags->NewSiteID == 1)
				SetCtrlAttribute (panel, NEWSITE_OK, ATTR_DIMMED, 0);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

int CVICALLBACK NewSiteDataPath (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char Folder[MAX_PATHNAME_LEN];		    

	qczstruct *qcz_dat;

	switch (event)
		{
		case EVENT_COMMIT:
			qcz_dat = &((datastruct*)callbackData)->qcz_dat;

			DirSelectPopup ("", "Default Directory for Data Files", 1,
							1, Folder);
			SetCtrlVal (panel, NEWSITE_DAT_PATH, Folder);

			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

int CVICALLBACK NewSiteCancel (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	flagstruct *flags;

	switch (event)
		{
		case EVENT_COMMIT:
			flags = &((datastruct*)callbackData)->flags;

			flags->NewSitePath	= 0;
			flags->NewSiteID	= 0;

			DiscardPanel (panel);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

int CVICALLBACK NewSiteID (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	flagstruct *flags;

	switch (event)
		{
		case EVENT_VAL_CHANGED:
			flags = &((datastruct*)callbackData)->flags;

			/* if all info is set, undim Ok. */
			flags->NewSiteID = 1;
			if (flags->NewSitePath == 1 && flags->NewSiteID == 1)
				SetCtrlAttribute (panel, NEWSITE_OK, ATTR_DIMMED, 0);
			break;
		case EVENT_RIGHT_CLICK:

			break;
		}
	return 0;
}

int save_confirm(void)
{
	int retval;
	
	retval = GenericMessagePopup ("Unsaved Changes",
					  "Do you want to save boundary changes?", "Save",
					  "Discard", "Cancel", 0, 0, 0,
					  VAL_GENERIC_POPUP_BTN1,
					  VAL_GENERIC_POPUP_BTN1,
					  VAL_GENERIC_POPUP_BTN3);

	return (retval - 1); // Map to the type enumeration
}

int CVICALLBACK GetSiteInfo (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	FILE *hFile;
	int iRing, i, integ, plane;
	float filter;
	flagstruct *flags;
	datastruct *dat;
	qczstruct *qcz_dat;
	struct listfilestruct *flist;

	switch (event)
		{
		case EVENT_COMMIT:
			dat		= (datastruct*)callbackData;
			flist	= dat->filelist_dat->next;
			flags 	= &((datastruct*)callbackData)->flags;
			qcz_dat	= &((datastruct*)callbackData)->qcz_dat;
	
			GetCtrlIndex(panel, control, &iRing);
			if (iRing >= 0)  // -1 if nothing present
			{
				for (i=0; i<iRing; i++)
				{
					flist = flist->next;
					if (flist == NULL)
					{
						nonfatal_error(INTERNAL_ERROR, "Get Site Info");
						break;
					}
				}

				if ((hFile = fopen(flist->FilePath, "rt")) == NULL)
					nonfatal_error(FILE_OPEN_ERROR, flist->FilePath);
				else
				{
					strcpy(qcz_dat->QC0_FileName, flist->FilePath);
					extract_site_dat(hFile, NULL, NULL, NULL, NULL, &integ, &plane, &filter, NULL, dat->dat_Folder, NULL);
					fclose(hFile);
				}
			
				SetCtrlVal(openFile, OPEN_TIME, integ);
				
				/* set the plane radio buttons */
				SetCtrlVal(mainPanel, MAIN_PLANE0, 0);
				SetCtrlVal(mainPanel, MAIN_PLANE1, 0);
				SetCtrlVal(mainPanel, MAIN_PLANE2, 0);
				switch (plane)
				{
					case 0: control = MAIN_PLANE0;
							break;
					case 1: control = MAIN_PLANE1;
							break;
					case 2: control = MAIN_PLANE2;
							break;
					default: control = MAIN_PLANE0;
				}
				SetCtrlVal(mainPanel, control, 1);
				dat->selPlane = plane;
		
				/* set the filter settings */
				if (filter > -0.9)  // above the -1 flag value; qc0 has specified a threshold
				{
					SetCtrlVal (mainPanel, MAIN_3_FILTER, 1);
					SetCtrlVal (mainPanel, MAIN_KS_THOLD, filter);
				}
				else
				{
					SetCtrlVal (mainPanel, MAIN_3_FILTER, 0);
					SetCtrlVal (mainPanel, MAIN_KS_THOLD, 0.05);
				}
		
			}
			

			break;
		}
	return 0;
}


void extract_site_dat(FILE *infile, char *site_desc, float *lat, float *lon, float *tz, int *integ, int *plane, float *filter,
		char *curves, char *path, char **comments)
{
	char io[260], *ptr, error_str[1000];
	long fptr;
	int comlen,  /* length of comments */
		i;
		
	/* set default defaults if not present */
	strcpy(path, "");
	strcpy(error_str, "");
	*integ	= 60;
	*plane	= 0;
	*filter	= -1.0;
	
	/*  Site description line (note: side ID is not extracted) */
	if (site_desc)
	{
			fgets(io, 259, infile);
			if (strstr(io, "Site Identifier:"))
			{
				ptr = strchr(io, ','); // look for comma between ID and description
				if (ptr == NULL)
					ptr = strchr(io, ':');  // no comma... just take whole string after colon
				if (ptr)
				{
					ptr++;
					str_trim(ptr);
					strcpy(site_desc, ptr);
				}
				else
					strcat(error_str, "QC0 File - Site Identifier\n");
			}
			else
				strcat(error_str, "QC0 File - Site Identifier\n");
	}
	
	/*  Latitude line  */
	if (lat)
	{
		fgets(io, 259, infile);
		if (strstr(io, "Latitude:"))
		{
			ptr = strchr(io, ':');
			if (ptr)
			{
				ptr++;
				*lat = atof (ptr);
			}
			else
				strcat(error_str, "QC0 File - Latitude\n");
		}
		else
			strcat(error_str, "QC0 File - Latitude\n");
	}
	
	/*  Longitude line  */
	if (lon)
	{
		fgets(io, 259, infile);
		if (strstr(io, "Longitude:"))
		{
			ptr = strchr(io, ':');
			if (ptr)
			{
				ptr++;
				*lon = atof (ptr);
			}
			else
				strcat(error_str, "QC0 File - Longitude\n");
		}
		else
			strcat(error_str, "QC0 File - Longitude\n");
	}
	
	
	/*  Time Zone */
	if (tz)
	{
		fgets(io, 259, infile);
		if (strstr(io, "Time Zone:"))
		{
			ptr = strchr(io, ':');
			if (ptr)
			{
				ptr++;
				*tz = atof(ptr);
			}
			else
				strcat(error_str, "QC0 File - Time Zone\n");
		}
		else
			strcat(error_str, "QC0 File - Time Zone\n");
	}
	

	/*Spin through the header and months */
	if (curves)
		strcpy(curves, "");
		
	fgets(io, 259, infile);
	while (strstr(io, "JAN:") == NULL && !feof(infile))
		fgets(io, 259, infile);
	
	/* write January, then spin through the other eleven */
	if (curves)
		strcat(curves, io);
	for (i = 0; i < 11; i++)
	{
		fgets(io, 259, infile);
		if (curves)
			strcat(curves, io);
	}
		
		
	if (feof(infile))
		strcat(error_str, "QC0 File - Data Lines");
			
	if (*error_str)
		nonfatal_error(FILE_READ_ERROR, error_str);
	else
	{
		fgets(io, 259, infile);
		fptr = ftell(infile); // save the file pointer in case no defaults found
	
		while (strstr(io, DFLT_1) == NULL && !feof(infile))
			fgets(io, 259, infile);

		/* if not eof, found integration line; validate and retain */
		if (!feof(infile))
		{
	
			ptr = strchr(io, ':');
			if (ptr)
			{
				ptr++;
				*integ = atoi(ptr);
				*integ = MAX(MIN(*integ, 60), 1);
			}

			/* continue looking for data path line */
			while (strstr(io, DFLT_2) == NULL && !feof(infile))
				fgets(io, 259, infile);
	
			/* if not eof, found it; validate and retain */
			if (!feof(infile))
			{
				ptr = strchr(io, ':');
				if (ptr)
				{
					ptr++;
					str_trim(ptr);
					strcpy(path, ptr);
//					strcat(path, "\\");
				}
			}
			
			/* continue looking for plane line */
			while (strstr(io, DFLT_3) == NULL && !feof(infile))
				fgets(io, 259, infile);
	
			/* if not eof, found it; validate and retain */
			if (!feof(infile))
			{
				ptr = strchr(io, ':');
				if (ptr)
				{
					ptr++;
					*plane = atoi(ptr);
				}
			}
			
			/* continue looking for 3-component filter line */
			while (strstr(io, DFLT_4) == NULL && !feof(infile))
				fgets(io, 259, infile);
	
			/* if not eof, found it; validate and retain */
			if (!feof(infile))
			{
				ptr = strchr(io, ':');
				if (ptr)
				{
					ptr++;
					*filter = atof(ptr);
				}
			}
			fptr = ftell(infile); // comments now follow config stuff
		}
		
		/* spin through the rest of the file looking for comments */
		fseek (infile, fptr, SEEK_SET); // rewind to search for comments
		
		/* determine length of comments */
		if (comments)
		{
			comlen = 0;
			fgets(io, 259, infile);
		
			while (!feof(infile))
			{
				comlen += strlen(io);
				fgets(io, 259, infile);
			}
		
			/* now go back, allocate space, and save comments */
			if (comlen > 0)
			{
				if ((*comments = CNEW(comlen+1, char)) == NULL)
					nonfatal_error(MEM_ALLOC_ERROR, "QC0 comments");
				else
				{
					fseek (infile, fptr, SEEK_SET); // rewind to gather comments
					strcpy(*comments, "");

					fgets(io, 259, infile);
					str_trim(io);
					if (strlen(io) == 0)	   // purge possible dead line before comments 
						fgets(io, 259, infile); 
					while (!feof(infile))
					{
						strcat(*comments, io);
						fgets(io, 259, infile);
					}
				}
			}
			else
				*comments = NULL;
		}
	}
}


void CVICALLBACK edit_qc0 (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	char fname[MAX_PATHNAME_LEN];
	char qc0path[MAX_PATHNAME_LEN], datpath[MAX_PATHNAME_LEN], *comments, site_desc[100], site_id[100],*ptr;
	char tmpstr[MAX_PATHNAME_LEN], curves[2000], drive[MAX_DRIVENAME_LEN];
	float lat, lon, tz, filter;
	int integ, retval, plane, control;
	FILE *infile;
	
	retval = FileSelectPopup ("", "*.QC0", "*.QC0", "Select QC0 File",
					 VAL_LOAD_BUTTON, 0, 0, 1, 0, fname);
	
	if (retval == VAL_EXISTING_FILE_SELECTED)
	{
		if ((infile = fopen(fname, "rt")) == NULL)
			nonfatal_error(FILE_OPEN_ERROR, fname);
		else
		{
			extract_site_dat(infile, site_desc, &lat, &lon, &tz, &integ, &plane, &filter, curves, datpath, &comments);
			fclose(infile);
		}
		
		SplitPath (fname, drive, qc0path, tmpstr);

		/* save the path to qc0 files */
		sprintf(tmpstr, "%s%s", drive, qc0path);
		strcpy(qc0path, tmpstr);
	
		StringUpperCase(fname);
	
	
		if ((ptr = strstr(fname, "S_")) == NULL)
			nonfatal_error(GENERIC_ERROR, "Improperly formed QC0 file name - Site ID");
		else
		{
			strcpy(site_id, ptr+2);
			if ((ptr = strstr(site_id, ".QC0")) == NULL)
				nonfatal_error(GENERIC_ERROR, "Improperly formed QC0 file name - QC0 extension");
			else
				*ptr = '\0';
		}
			
			
		
		editPan = LoadPanel (0, "WinQCF.uir", NEWSITE);
	
		SetPanelAttribute (editPan, ATTR_TITLE, "Edit Site");
		SetCtrlVal(editPan, NEWSITE_SITE_ID, site_id);
		SetCtrlVal(editPan, NEWSITE_SITE_DESC, site_desc);
		SetCtrlVal(editPan, NEWSITE_LAT, lat);
		SetCtrlVal(editPan, NEWSITE_LON, lon);
		SetCtrlVal(editPan, NEWSITE_TZONE, tz);
		SetCtrlVal(editPan, NEWSITE_INTEGRATION, integ);
		SetCtrlVal(editPan, NEWSITE_DAT_PATH, datpath);
		SetCtrlVal(editPan, NEWSITE_QC0_PATH, qc0path);
		if (comments)
			SetCtrlVal(editPan, NEWSITE_COMMENTS, comments);
		if (curves)
			SetCtrlVal(editPan, NEWSITE_CURVES, curves);
		
		/* set the plane radio buttons */
		SetCtrlVal(editPan, NEWSITE_PLANE0, 0);
		SetCtrlVal(editPan, NEWSITE_PLANE1, 0);
		SetCtrlVal(editPan, NEWSITE_PLANE2, 0);
		switch (plane)
		{
			case 0: control = NEWSITE_PLANE0;
					break;
			case 1: control = NEWSITE_PLANE1;
					break;
			case 2: control = NEWSITE_PLANE2;
					break;
			default: control = NEWSITE_PLANE0;
		}
		SetCtrlVal(editPan, control, 1);
		
		/* set the filter settings */
		if (filter > -0.9)  // above the -1 flag value; QC0 has specified a threshold
		{
			SetCtrlVal (editPan, NEWSITE_3_FILTER, 1);
			SetCtrlVal (editPan, NEWSITE_KS_THOLD, filter);
			SetCtrlAttribute (editPan, NEWSITE_KS_THOLD, ATTR_DIMMED, 0);
		}
		else
		{
			SetCtrlVal (editPan, NEWSITE_3_FILTER, 0);
			SetCtrlVal (editPan, NEWSITE_KS_THOLD, 0.05);
			SetCtrlAttribute (editPan, NEWSITE_KS_THOLD, ATTR_DIMMED, 1);
		}
		
		/* other misc settings */
		SetCtrlAttribute (editPan, NEWSITE_QC0_PATH, ATTR_VISIBLE, 0);
		SetCtrlAttribute (editPan, NEWSITE_BROWSE_QC0, ATTR_VISIBLE, 0);
		SetCtrlAttribute (editPan, NEWSITE_OK, ATTR_DIMMED, 0);
		SetCtrlAttribute (editPan, NEWSITE_SITE_ID, ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (editPan, NEWSITE_OK, ATTR_CALLBACK_DATA, callbackData);
		SetCtrlAttribute (editPan, NEWSITE_CANCEL, ATTR_CALLBACK_DATA, callbackData);
	
		InstallPopup(editPan);
	
		if (comments)
			free(comments);
	}
}

int CVICALLBACK set_tz (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	double longitude, tz;
	
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal(panel, NEWSITE_LON, &longitude);
			tz = (double)(int)RoundRealToNearestInteger(longitude / 15.0);
			SetCtrlVal (panel, NEWSITE_TZONE, tz);

			break;
		}
	return 0;
}

/**************************************************************************\

  Function about_qcf()
  
  Loads the splash screen
						 
\**************************************************************************/

void CVICALLBACK about_qcf (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	char ver_msg[30];

	splPan = LoadPanel (0, "WinQCF.uir", SPL_PAN);
	strcpy(ver_msg, "WinQCFIT v");
	strcat(ver_msg, VERSION);
	SetCtrlVal (splPan, SPL_PAN_VER, ver_msg); 
	DisplayPanel (splPan);

}

int CVICALLBACK exit_splash (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_TIMER_TICK:
		case EVENT_LEFT_CLICK:
			DiscardPanel(splPan);
			

			break;
		}
	return 0;
}

int CVICALLBACK animate (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
		{
		case EVENT_COMMIT:
			/* disable the animate button and fire off the animation timer to call the K_animation routine */
			SetCtrlAttribute (mainPanel, MAIN_ANIMATE, ATTR_CTRL_MODE, VAL_INDICATOR);
			SetCtrlAttribute (mainPanel, MAIN_ANIMATE_TIMER, ATTR_ENABLED, 1);
			break;
		}
	return 0;
}

int CVICALLBACK K_animation (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	static int first_plane = -1; /* current plane (-1 indicates first time through) */
	int i;
	int		status, 			/* status of the plane radio button */
			next_plane, 		/* the next plane to display */
			plane_array[3] = {MAIN_PLANE0, MAIN_PLANE1, MAIN_PLANE2};
	
	switch (event)
		{
		case EVENT_TIMER_TICK:
		
			/* look for the control that is selected */
			for (i = 0; i < 3; i++)
			{
				GetCtrlVal(mainPanel, plane_array[i], &status);
				if (status)
					break;
			}
			if (i == 3)
				nonfatal_error(INTERNAL_ERROR, "Animation");
					
			
			/* if we're not back to the beginning plane, make the changes */
			if (plane_array[i] != first_plane)
			{
				switch (plane_array[i])
				{
					case MAIN_PLANE0:
						next_plane = MAIN_PLANE1;
						break;
					
					case MAIN_PLANE1:
						next_plane = MAIN_PLANE2;
						break;
					
					case MAIN_PLANE2:
						next_plane = MAIN_PLANE0;
						break;
				}
					
				SetCtrlVal(mainPanel, plane_array[i], 0);
				SetCtrlVal(mainPanel, next_plane, 1);
				ChangePlane (mainPanel, next_plane, EVENT_COMMIT, callbackData, 0, 0);
			}

			/* keep track of where in the loop we are */
			if (first_plane == -1)			  // first time through
			{
				first_plane = plane_array[i];
				SetCtrlAttribute (mainPanel, MAIN_ANIMATE_TIMER, ATTR_INTERVAL, 0.333);
			}
			else if (plane_array[i] == first_plane)  // done with the loop; shut down timer and reset
			{
				SetCtrlAttribute (mainPanel, MAIN_ANIMATE_TIMER, ATTR_ENABLED, 0);
				SetCtrlAttribute (mainPanel, MAIN_ANIMATE_TIMER, ATTR_INTERVAL, 0.1);
				SetCtrlAttribute (mainPanel, MAIN_ANIMATE, ATTR_CTRL_MODE, VAL_HOT);
				first_plane = -1;
			}
			break;
		}
	return 0;
}

int CVICALLBACK ChangeNewsitePlane (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			switch (control)
			{
			case NEWSITE_PLANE0:
				SetCtrlVal (panel, NEWSITE_PLANE0, 1);
				SetCtrlVal (panel, NEWSITE_PLANE1, 0);
				SetCtrlVal (panel, NEWSITE_PLANE2, 0);
				break;
			case NEWSITE_PLANE1:
				SetCtrlVal (panel, NEWSITE_PLANE0, 0);
				SetCtrlVal (panel, NEWSITE_PLANE1, 1);
				SetCtrlVal (panel, NEWSITE_PLANE2, 0);
				break;				
			case NEWSITE_PLANE2:
				SetCtrlVal (panel, NEWSITE_PLANE0, 0);
				SetCtrlVal (panel, NEWSITE_PLANE1, 0);
				SetCtrlVal (panel, NEWSITE_PLANE2, 1);
				break;
			}


			break;
		}
	return 0;
}

int CVICALLBACK NewSiteFilterEnable (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int status;
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panel, NEWSITE_3_FILTER, &status);
			SetCtrlAttribute (panel, NEWSITE_KS_THOLD, ATTR_DIMMED, !status);
			break;
		}
	return 0;
}






int CVICALLBACK plot_freq (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ig, ip, ix, iy, binMax, cnt_array[BINMAX], i, indx, bin, tmpCtrl, key_ctrl;
	float residual, tot[GRAPH_CNT];
	pixelheader *pixel;
	graphstruct *graph;
	datastruct *dat;
	freqplotstruct *freqplot;
	struct datalist *rec;
	
	
	switch (event)
		{
			case EVENT_LEFT_DOUBLE_CLICK:
				dat = (datastruct*)callbackData;
				freqplot = &dat->freqplot;
				ip = dat->selPlane;
				
				/* make sure the data arrays are clear */
				freqplot->dat_cnt = 0;
				if (freqplot->xData != NULL)
				{
					free(freqplot->xData);
					freqplot->xData = NULL;
				}
				if (freqplot->yData != NULL)
				{
					free(freqplot->yData);
					freqplot->yData = NULL;
				}
					
				
				for (i =0; i < BINMAX; i++)
					cnt_array[i] = 0;
				
				if (panel > -1) // do the enlarged plot
				{
					frqPan	= LoadPanel (0, "WinQCF.uir", FREQ);
					tmpCtrl	= FREQ_PLOT;
					InstallPopup(frqPan);
				}
				else		   // just do the small main panel plot
				
				{
					frqPan	= mainPanel;
					tmpCtrl	= MAIN_FPLOT;
				}

				DeleteGraphPlot (frqPan, tmpCtrl, -1, VAL_IMMEDIATE_DRAW);
				
				/* for each graph, count the frequency of each density encountered */
				for (ig=0; ig<GRAPH_CNT; ig++)
				{
					tot[ig] = 0.0;
					freqplot->key_cnt[ig] = 0.0;
					graph = &dat->graphs[ig];
					for (ix=XMIN; ix<XMAX; ix++)
					{
						for (iy=YMIN; iy<YMAX; iy++)
						{
							pixel = &graph->phead[ix][iy][ip];
							if (pixel->count > 0 && !pixel->excluded)
							{
								rec = pixel->dathead->dat_next[ip];
								while (rec->dat_next[ip])
								{
									if (!rec->excluded && rec->kt < MISS_K && rec->kn < MISS_K && rec->kd < MISS_K)
									{
										residual = (rec->kt - rec->kn - rec->kd);
										bin = RoundRealToNearestInteger(residual*100.0);
										bin = MIN(MAX(bin,-15), 15);
										bin += 15;			// translate -15/+15 to 31 non-negative  bins
										if (cnt_array[bin] == 0)
											freqplot->dat_cnt++;	   // number of live bins
										cnt_array[bin]++;  // increment count for this bin
										
										/* increment the mean counters */
										tot[ig] += residual;
										freqplot->key_cnt[ig] ++;
									}
									rec = rec->dat_next[ip];
								}
							}
						}
					}
				}
				
				if (freqplot->dat_cnt > 0)
				{
					if ((freqplot->xData = CNEW(BINMAX, float)) == NULL)
						fatal_error(MEM_ALLOC_ERROR, "FREQ xData array");
					if ((freqplot->yData = CNEW(BINMAX, float)) == NULL)
						fatal_error(MEM_ALLOC_ERROR, "FREQ yData array");
						
					indx = 0;
					binMax = -1;
					for (i = 0; i < BINMAX; i++)
					{
//						if (cnt_array[i] > 0)
						{
						freqplot->xData[indx] = (float)(i-15) / 100.0;
											 
						freqplot->yData[indx] = (float)cnt_array[i];
						indx++;
						if (indx > BINMAX)
							fatal_error(INTERNAL_ERROR, "FREQ data array overrun");
						}
						binMax = MAX(binMax, cnt_array[i]);
					}
					
					freqplot->binmax = binMax;
					
					i=PlotXY (frqPan, tmpCtrl, freqplot->xData, freqplot->yData, BINMAX, VAL_FLOAT,
								VAL_FLOAT, VAL_VERTICAL_BAR, VAL_NO_POINT, VAL_SOLID, 1,
								VAL_DK_BLUE);
								
					/* put the means on the plot */
					for (ig = 0; ig < GRAPH_CNT; ig++)
					{
						if (freqplot->key_cnt[ig] > 0)
						{
							tot[ig] /= freqplot->key_cnt[ig];
							tot[ig] = MAX(MIN(tot[ig], 15.0), -15.0);
							freqplot->keydatX[ig][0] = tot[ig];
							freqplot->keydatY[ig][0] = 0.0;
							freqplot->keydatX[ig][1] = tot[ig];
							freqplot->keydatY[ig][1] = (float)binMax / 20.0;
							
							if (panel > -1) // only do it for the larger graph
							{
								PlotXY (frqPan, tmpCtrl, freqplot->keydatX[ig], freqplot->keydatY[ig], 2, 
										VAL_FLOAT, VAL_FLOAT, VAL_FAT_LINE, VAL_NO_POINT, VAL_SOLID, 
										1, freqplot->colors[ig]);

								/* set the key colors */
								switch(ig)
								{
									case 0: key_ctrl = FREQ_KEY_LO;
										break;
									case 1: key_ctrl = FREQ_KEY_MED;
										break;
									case 2: key_ctrl = FREQ_KEY_HI;
										break;
								}
									
								SetCtrlAttribute (frqPan, key_ctrl, ATTR_FRAME_COLOR, freqplot->colors[ig]);
								
							}
						}
					}
				}
				else if (panel > -1)
					SetCtrlAttribute (frqPan, FREQ_NODAT, ATTR_VISIBLE, 1);
					
			break;
		}
	return 0;
}

int CVICALLBACK quit_freq (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			DiscardPanel(frqPan);

			break;
		}
	return 0;
}

int do_commandline(datastruct *dat, int argc, char **argv)
{
	int	i, outputtype, ip, ig, BmpId;
	double Alog_4=1.386294361; /*, DegRad=0.017453292; */
	char tmpstr[1000];

	enum cmdline {PROG, SITE, QC0PATH, MONTH, INTERVAL, PLANE, DENSITY, DENSFAC, INFILE, OUTPUT, ARGCNT};
	enum outtype {BMP, PNG, PRN, PRT};
	
	/* check the input arguments */
	if (argc < ARGCNT)
	{
		sprintf(tmpstr, "usage: qcfit <site> <qc0 path> <month> <interval> <plane> <density> <density factor> <input file> <output file>\n"
						"  <site>: QC-Zero Site Identifier\n"
						"  <qc0 path>: Path to QC-Zero file\n"
						"  <month>: Month of year (1-12)\n"
						"  <interval>: data integration interval (1-60)\n"
						"  <plane>: 1=Global/Direct; 2=Global/Diffuse; 3= Direct/Diffuse\n"
						"  <density>: 1=Off; 2=Equal Frequency; 3=Equal Range; 4=Exponential\n"
						"  <density factor>: factor for exponential density mode (ignored for non-exponential)\n"
						"  <input file>: Name of input QCFIT file\n"
						"  <output>: Name of printer or output file (for file include .BMP, .PNG, or .PRN extension)");
		MessagePopup ("Command Line Usage", tmpstr);
		exit(0);
	}
	
	/* output file */
	strcpy(tmpstr, argv[OUTPUT]);
	StringUpperCase(tmpstr);
	if (strstr(tmpstr, ".BMP"))
		outputtype = BMP;
	else if (strstr(tmpstr, ".PNG"))
		outputtype = PNG;
	else if (strstr(tmpstr, ".PRN"))
		outputtype = PRN;
	else
		outputtype = PRT;
	
	/* month */
	i = atoi(argv[MONTH]) - 1;
	if (i < 0 || i > 11)
	{
		sprintf(tmpstr, "Incorrect month <%d> (1-12)\n", i);
		MessagePopup ("Command Line Error", tmpstr);
		exit(0);
	}
	dat->qcz_dat.Month = i;
	
	/* interval */
	i = atoi(argv[INTERVAL]);
	if (i < 1 || i > 60)
	{
		sprintf(tmpstr, "Incorrect interval <%d> (1-60)\n", i);
		MessagePopup ("Command Line Error", tmpstr);
		exit(0);
	}
	dat->soldat->interval = i;
	
	/* plane */
	dat->selPlane = atoi(argv[PLANE]);
	if (dat->selPlane < 1 || dat->selPlane > 3)
	{
		sprintf(tmpstr, "Incorrect plane <%d> (1-3)\n", dat->selPlane);
		MessagePopup ("Command Line Error", tmpstr);
		exit(0);
	}
	dat->selPlane--; //convert to zero-based
	
	/* density */
	dat->density.d_func = atoi(argv[DENSITY]);
	if (dat->density.d_func  < 1 || dat->density.d_func > 4)
	{
		sprintf(tmpstr, "Incorrect density <%d> (1-3)\n", dat->density.d_func);
		MessagePopup ("Command Line Error", tmpstr);
		exit(0);
	}
	dat->density.d_func--; //convert to zero-based 
	
	dat->density.factor = atof(argv[DENSFAC]);

	/* qczero file */
	sprintf( dat->qcz_dat.QC0_FileName, "%s\\S_%s.QC0", argv[QC0PATH], argv[SITE]);
	
	dat->file_dat.numFiles = 1;
	dat->file_dat.MFileName = CNEW(1, char*);
	dat->file_dat.MFileName[0] = CNEW(MAX_PATHNAME_LEN, char);
	strcpy(dat->file_dat.MFileName[0], argv[INFILE]);
	
	dat->qcz_dat.RightPosIndex = ((int) ( 1.49 + log(dat->soldat->interval) / Alog_4 ) - 1);

	if (ReadQC0(dat) == 1)
		exit(0);
		;
	ProcessQCF(dat);
	
	/* call autofit if boundaries undefined */
	ip = dat->selPlane;
	for (ig=0; ig<GRAPH_CNT; ig++)
	{
		if (
//			dat->qcz_dat.Max_kn 								== 0 ||
//			dat->qcz_dat.Max_kt[dat->qcz_dat.RightPosIndex] 	== 0 ||
			dat->qcz_dat.LeftShape[ig]							== 0 ||
			dat->qcz_dat.LeftPos[ig]							== 0 ||
			dat->qcz_dat.RightShape[ig]							== 0 ||
			dat->qcz_dat.RightPos[ig][dat->qcz_dat.RightPosIndex] 	== 0)
		{
			autofit(dat, ig, ip, 1.0);
		}
	}
	BndryStatus(dat);
	Density(dat);
	DensityLegend (dat);
	Plot(dat);
	plot_freq (-1, -1, EVENT_LEFT_DOUBLE_CLICK, dat, 0, 0);

	/* load print panel */
	printPan = LoadPanel (0, "WinQCF.uir", PRINT);

	/* setup the print panel */
	SetupPrintPanel (dat);

	

	if (outputtype == BMP)
	{
		GetPanelDisplayBitmap (printPan, VAL_FULL_PANEL, VAL_ENTIRE_OBJECT, &BmpId);
		if (SaveBitmapToFile (argv[OUTPUT], BmpId) != 0)
		{
			sprintf(tmpstr, "An error prevented the BMP image from being saved to <%s>", argv[OUTPUT]);
			MessagePopup ("Command Line Error", tmpstr);
			exit(1);
		}
	}
	else if (outputtype == PNG)
	{
		Png_SetParameters (0.5, 0, 72, Z_BEST_COMPRESSION, 0);
		if (Png_SavePanelControlToFile (printPan, 0, argv[OUTPUT]) != 0)
		{
			sprintf(tmpstr, "An error prevented the PNG image from being saved to <%s>", argv[OUTPUT]);
			MessagePopup ("Command Line Error", tmpstr);
			exit(1);
		}
	}
	else if (outputtype == PRN)
	{
		SetPrintAttribute (ATTR_PRINT_AREA_HEIGHT, VAL_USE_ENTIRE_PAPER);
		SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, VAL_INTEGRAL_SCALE);
		SetPrintAttribute (ATTR_PRINTER_NAME, argv[OUTPUT]);
		if (PrintPanel (printPan, argv[OUTPUT], 1, VAL_FULL_PANEL, 0) != 0)
		{
			sprintf(tmpstr, "A error occurred printing to <%s>", argv[OUTPUT]);
			MessagePopup ("Command Line Error", tmpstr);
			exit(1);
		}
	}
	else if (outputtype == PRT)
	{
		SetPrintAttribute (ATTR_PRINT_AREA_HEIGHT, VAL_USE_ENTIRE_PAPER);
		SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, VAL_INTEGRAL_SCALE);
		SetPrintAttribute (ATTR_PRINTER_NAME, argv[OUTPUT]);
		if (PrintPanel (printPan, "", 1, VAL_FULL_PANEL, 0) != 0)
		{
			sprintf(tmpstr, "A error occurred printing to <%s>", argv[OUTPUT]);
			MessagePopup ("Command Line Error", tmpstr);
			exit(1);
		}
	}

		
	/* discard panel */
	DiscardPanel (printPan);

	return 0;
		
}
	
	
