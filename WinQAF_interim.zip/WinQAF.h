/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2026. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  BUTTON                           1
#define  BUTTON_OPEN                      2       /* control type: canvas, callback function: (none) */
#define  BUTTON_PRINT                     3       /* control type: canvas, callback function: (none) */
#define  BUTTON_SAVE                      4       /* control type: canvas, callback function: (none) */

#define  EDIT                             2
#define  EDIT_CURSOR_TOGGLE               2       /* control type: radioButton, callback function: EditCursorToggle */
#define  EDIT_ZOOM                        3       /* control type: command, callback function: EditZoomIn */
#define  EDIT_EXCLUDE                     4       /* control type: command, callback function: exclude_pix */
#define  EDIT_RESTORE                     5       /* control type: command, callback function: EditRestoreGraph */
#define  EDIT_RESET                       6       /* control type: command, callback function: reset_exclude */
#define  EDIT_LIST                        7       /* control type: command, callback function: list_dat */
#define  EDIT_KT_MAX                      8       /* control type: numeric, callback function: EditKtMax */
#define  EDIT_KN_MAX                      9       /* control type: numeric, callback function: EditKnMax */
#define  EDIT_CURVE_SHAPE_LEFT            10      /* control type: ring, callback function: EditCurveShapeLeft */
#define  EDIT_CURVE_POS_LEFT              11      /* control type: ring, callback function: EditCurvePosLeft */
#define  EDIT_CURVE_SHAPE_RIGHT           12      /* control type: ring, callback function: EditCurveShapeRight */
#define  EDIT_CURVE_POS_RIGHT             13      /* control type: ring, callback function: EditCurvePosRight */
#define  EDIT_LESS_ERR                    14      /* control type: command, callback function: EditErr */
#define  EDIT_MORE_ERR                    15      /* control type: command, callback function: EditErr */
#define  EDIT_NAR_LEFT                    16      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_WIDE_LEFT                   17      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_NAR_RIGHT                   18      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_WIDE_RIGHT                  19      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_NAR_BOTH                    20      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_WIDE_BOTH                   21      /* control type: command, callback function: EditNarrowAndWide */
#define  EDIT_OK                          22      /* control type: command, callback function: EditOk */
#define  EDIT_CURSOR_1_X                  23      /* control type: numeric, callback function: (none) */
#define  EDIT_CURSOR_2_X                  24      /* control type: numeric, callback function: (none) */
#define  EDIT_GRAPH                       25      /* control type: graph, callback function: EditUpdateMarker */
#define  EDIT_CURSOR_1_Y                  26      /* control type: numeric, callback function: (none) */
#define  EDIT_CURSOR_2_Y                  27      /* control type: numeric, callback function: (none) */
#define  EDIT_TEXTMSG_3                   28      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_4                   29      /* control type: textMsg, callback function: (none) */
#define  EDIT_DECORATION_2                30      /* control type: deco, callback function: (none) */
#define  EDIT_DECORATION_3                31      /* control type: deco, callback function: (none) */
#define  EDIT_DECORATION_4                32      /* control type: deco, callback function: (none) */
#define  EDIT_TEXTMSG_5                   33      /* control type: textMsg, callback function: (none) */
#define  EDIT_DECORATION_5                34      /* control type: deco, callback function: (none) */
#define  EDIT_DECORATION_12               35      /* control type: deco, callback function: (none) */
#define  EDIT_DECORATION_13               36      /* control type: deco, callback function: (none) */
#define  EDIT_TEXTMSG_8                   37      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_9                   38      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_10                  39      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_11                  40      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_12                  41      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_OUT_PERC               42      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_24                  43      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_IN                     44      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_OUT                    45      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_ACT                    46      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_IGN                    47      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_TOT                    48      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_13                  49      /* control type: textMsg, callback function: (none) */
#define  EDIT_DECORATION_11               50      /* control type: deco, callback function: (none) */
#define  EDIT_TEXTMSG_14                  51      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_15                  52      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG                     53      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_7                   54      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_2                   55      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_25                  56      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_R_PERC                 57      /* control type: textMsg, callback function: (none) */
#define  EDIT_STAT_L_PERC                 58      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_26                  59      /* control type: textMsg, callback function: (none) */
#define  EDIT_ERR_LEVEL                   60      /* control type: textMsg, callback function: (none) */
#define  EDIT_TEXTMSG_6                   61      /* control type: textMsg, callback function: (none) */
#define  EDIT_PICTURE                     62      /* control type: picture, callback function: (none) */

#define  FREQ                             3
#define  FREQ_QUIT                        2       /* control type: command, callback function: quit_freq */
#define  FREQ_TEXTMSG                     3       /* control type: textMsg, callback function: (none) */
#define  FREQ_PLOT                        4       /* control type: graph, callback function: (none) */
#define  FREQ_TEXTMSG_2                   5       /* control type: textMsg, callback function: (none) */
#define  FREQ_KEY_LO                      6       /* control type: deco, callback function: (none) */
#define  FREQ_KEY_MED                     7       /* control type: deco, callback function: (none) */
#define  FREQ_KEY_HI                      8       /* control type: deco, callback function: (none) */
#define  FREQ_TEXTMSG_3                   9       /* control type: textMsg, callback function: (none) */
#define  FREQ_DECORATION_2                10      /* control type: deco, callback function: (none) */
#define  FREQ_NODAT                       11      /* control type: textMsg, callback function: (none) */

#define  LISTPAN                          4
#define  LISTPAN_DATALIST                 2       /* control type: textBox, callback function: (none) */
#define  LISTPAN_QUIT_BUT                 3       /* control type: command, callback function: quitlist */
#define  LISTPAN_TEXTMSG                  4       /* control type: textMsg, callback function: (none) */
#define  LISTPAN_TEXTMSG_2                5       /* control type: textMsg, callback function: (none) */
#define  LISTPAN_DAT_CNT                  6       /* control type: textMsg, callback function: (none) */

#define  MAIN                             5
#define  MAIN_LOW_GRAPH                   2       /* control type: graph, callback function: EditPanel */
#define  MAIN_MED_GRAPH                   3       /* control type: graph, callback function: EditPanel */
#define  MAIN_FPLOT                       4       /* control type: graph, callback function: plot_freq */
#define  MAIN_HIGH_GRAPH                  5       /* control type: graph, callback function: EditPanel */
#define  MAIN_DENS_OFF                    6       /* control type: radioButton, callback function: ChangeDensity */
#define  MAIN_DENS_MODE_1                 7       /* control type: radioButton, callback function: ChangeDensity */
#define  MAIN_DENS_MODE_3                 8       /* control type: radioButton, callback function: ChangeDensity */
#define  MAIN_DENS_MODE_2                 9       /* control type: radioButton, callback function: ChangeDensity */
#define  MAIN_PLANE0                      10      /* control type: radioButton, callback function: ChangePlane */
#define  MAIN_PLANE1                      11      /* control type: radioButton, callback function: ChangePlane */
#define  MAIN_PLANE2                      12      /* control type: radioButton, callback function: ChangePlane */
#define  MAIN_MONTH                       13      /* control type: ring, callback function: ChangeMonth */
#define  MAIN_YEAR                        14      /* control type: ring, callback function: ChangeYear */
#define  MAIN_3_FILTER                    15      /* control type: radioButton, callback function: FilterApply */
#define  MAIN_KS_THOLD                    16      /* control type: numeric, callback function: (none) */
#define  MAIN_3_FILTER_APPLY              17      /* control type: command, callback function: FilterApply */
#define  MAIN_QUIT                        18      /* control type: command, callback function: ExitProgram */
#define  MAIN_ANIMATE                     19      /* control type: command, callback function: animate */
#define  MAIN_DENS_TITLE                  20      /* control type: textMsg, callback function: (none) */
#define  MAIN_PLANE                       21      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_8                22      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_3                23      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_2                24      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_4                25      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_9                26      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_7                   27      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_18               28      /* control type: deco, callback function: (none) */
#define  MAIN_TIME                        29      /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_R_SHAPE                 30      /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_R_POS                   31      /* control type: textMsg, callback function: (none) */
#define  MAIN_DR0_IN                      32      /* control type: deco, callback function: (none) */
#define  MAIN_DR4_IN                      33      /* control type: deco, callback function: (none) */
#define  MAIN_RANGE_0                     34      /* control type: textMsg, callback function: (none) */
#define  MAIN_RANGE_1                     35      /* control type: textMsg, callback function: (none) */
#define  MAIN_RANGE_2                     36      /* control type: textMsg, callback function: (none) */
#define  MAIN_RANGE_3                     37      /* control type: textMsg, callback function: (none) */
#define  MAIN_RANGE_4                     38      /* control type: textMsg, callback function: (none) */
#define  MAIN_DR3_IN                      39      /* control type: deco, callback function: (none) */
#define  MAIN_DR2_IN                      40      /* control type: deco, callback function: (none) */
#define  MAIN_DR1_IN                      41      /* control type: deco, callback function: (none) */
#define  MAIN_DR4_OUT                     42      /* control type: deco, callback function: (none) */
#define  MAIN_DENS_FAC                    43      /* control type: numeric, callback function: ChangeDensity */
#define  MAIN_DR3_OUT                     44      /* control type: deco, callback function: (none) */
#define  MAIN_DR2_OUT                     45      /* control type: deco, callback function: (none) */
#define  MAIN_DR1_OUT                     46      /* control type: deco, callback function: (none) */
#define  MAIN_DR0_OUT                     47      /* control type: deco, callback function: (none) */
#define  MAIN_DENSITY                     48      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_14               49      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_15               50      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_21                  51      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_22                  52      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_23                  53      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_24                  54      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_25                  55      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_31                  56      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_32                  57      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_33                  58      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_IN                  59      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_OUT                 60      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_ACT                 61      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_IGN                 62      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_TOT                 63      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_OUT_PERC            64      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_R_PERC              65      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_HI_L_PERC              66      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION                  67      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_61                  68      /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_L_SHAPE                  69      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_62                  70      /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_R_SHAPE                  71      /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_R_POS                    72      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_16               73      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_17               74      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_37                  75      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_38                  76      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_39                  77      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_40                  78      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_41                  79      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_54                  80      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_48                  81      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_49                  82      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_OUT                83      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_ACT                84      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_TOT                85      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_OUT_PERC           86      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_R_PERC             87      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_L_PERC             88      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_IN                 89      /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_MED_IGN                90      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_19               91      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_59                  92      /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_L_SHAPE                 93      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_60                  94      /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_R_SHAPE                 95      /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_R_POS                   96      /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_12               97      /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_13               98      /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_2                   99      /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG                     100     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_3                   101     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_4                   102     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_5                   103     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_6                   104     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_8                   105     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_9                   106     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_OUT_PERC           107     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_R_PERC             108     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_L_PERC             109     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_IN                 110     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_ACT                111     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_IGN                112     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_TOT                113     /* control type: textMsg, callback function: (none) */
#define  MAIN_STAT_LOW_OUT                114     /* control type: textMsg, callback function: (none) */
#define  MAIN_DECORATION_20               115     /* control type: deco, callback function: (none) */
#define  MAIN_TEXTMSG_65                  116     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_66                  117     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_69                  118     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_70                  119     /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_L_POS                   120     /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_KN                      121     /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_KT                      122     /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_L_SHAPE                 123     /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_L_POS                   124     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_58                  125     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_57                  126     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_10                  127     /* control type: textMsg, callback function: (none) */
#define  MAIN_TEXTMSG_63                  128     /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_KT                       129     /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_KN                       130     /* control type: textMsg, callback function: (none) */
#define  MAIN_LOW_KN                      131     /* control type: textMsg, callback function: (none) */
#define  MAIN_MED_KT                      132     /* control type: textMsg, callback function: (none) */
#define  MAIN_HI_L_POS                    133     /* control type: textMsg, callback function: (none) */
#define  MAIN_FPLOTLABEL                  134     /* control type: textMsg, callback function: (none) */
#define  MAIN_ANIMATE_TIMER               135     /* control type: timer, callback function: K_animation */
#define  MAIN_FPLOTZERO                   136     /* control type: textMsg, callback function: (none) */
#define  MAIN_PICTURE_2                   137     /* control type: picture, callback function: (none) */

#define  NEWSITE                          6
#define  NEWSITE_SITE_ID                  2       /* control type: string, callback function: NewSiteID */
#define  NEWSITE_SITE_DESC                3       /* control type: textBox, callback function: (none) */
#define  NEWSITE_LAT                      4       /* control type: numeric, callback function: (none) */
#define  NEWSITE_LON                      5       /* control type: numeric, callback function: set_tz */
#define  NEWSITE_ELEV                     6       /* control type: numeric, callback function: (none) */
#define  NEWSITE_TZONE                    7       /* control type: numeric, callback function: (none) */
#define  NEWSITE_INTEGRATION              8       /* control type: numeric, callback function: OpenFileTime */
#define  NEWSITE_PLANE0                   9       /* control type: radioButton, callback function: ChangeNewsitePlane */
#define  NEWSITE_PLANE1                   10      /* control type: radioButton, callback function: ChangeNewsitePlane */
#define  NEWSITE_PLANE2                   11      /* control type: radioButton, callback function: ChangeNewsitePlane */
#define  NEWSITE_COMMENTS                 12      /* control type: textBox, callback function: (none) */
#define  NEWSITE_BROWSE_QC0               13      /* control type: command, callback function: NewSiteQC0Path */
#define  NEWSITE_QC0_PATH                 14      /* control type: string, callback function: (none) */
#define  NEWSITE_KS_THOLD                 15      /* control type: numeric, callback function: (none) */
#define  NEWSITE_BROWSE_DATA              16      /* control type: command, callback function: NewSiteDataPath */
#define  NEWSITE_DAT_PATH                 17      /* control type: string, callback function: (none) */
#define  NEWSITE_OK                       18      /* control type: command, callback function: NewSiteOk */
#define  NEWSITE_CANCEL                   19      /* control type: command, callback function: NewSiteCancel */
#define  NEWSITE_CURVES                   20      /* control type: textBox, callback function: (none) */
#define  NEWSITE_TEXTMSG                  21      /* control type: textMsg, callback function: (none) */
#define  NEWSITE_3_FILTER                 22      /* control type: radioButton, callback function: NewSiteFilterEnable */
#define  NEWSITE_DECORATION_2             23      /* control type: deco, callback function: (none) */
#define  NEWSITE_TEXTMSG_2                24      /* control type: textMsg, callback function: (none) */
#define  NEWSITE_TEXTMSG_3                25      /* control type: textMsg, callback function: (none) */

#define  OPEN                             7
#define  OPEN_BROWSE                      2       /* control type: command, callback function: OpenFileBrowse */
#define  OPEN_FILENAME                    3       /* control type: textBox, callback function: (none) */
#define  OPEN_BROWSE_QZ0                  4       /* control type: command, callback function: OpenFileBrowseFolder */
#define  OPEN_SITE                        5       /* control type: ring, callback function: GetSiteInfo */
#define  OPEN_TIME                        6       /* control type: numeric, callback function: OpenFileTime */
#define  OPEN_MONTH                       7       /* control type: ring, callback function: (none) */
#define  OPEN_OK                          8       /* control type: command, callback function: OpenFileOk */
#define  OPEN_NEWSITE                     9       /* control type: command, callback function: OpenFileNewSite */
#define  OPEN_CANCEL                      10      /* control type: command, callback function: Cancel */

#define  PRINT                            8
#define  PRINT_LOW_GRAPH                  2       /* control type: graph, callback function: EditPanel */
#define  PRINT_MED_GRAPH                  3       /* control type: graph, callback function: EditPanel */
#define  PRINT_FPLOT                      4       /* control type: graph, callback function: (none) */
#define  PRINT_KEY_LO                     5       /* control type: deco, callback function: (none) */
#define  PRINT_KEY_MED                    6       /* control type: deco, callback function: (none) */
#define  PRINT_KEY_HI                     7       /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_91                 8       /* control type: textMsg, callback function: (none) */
#define  PRINT_HIGH_GRAPH                 9       /* control type: graph, callback function: EditPanel */
#define  PRINT_TEXTMSG_6                  10      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_OUT_PERC          11      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG                    12      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_2                  13      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_3                  14      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_4                  15      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_5                  16      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_IN                17      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_OUT               18      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_ACT               19      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_TOT               20      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_8                  21      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_R_PERC            22      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_92                 23      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_7                  24      /* control type: textMsg, callback function: (none) */
#define  PRINT_TIME                       25      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_12                 26      /* control type: textMsg, callback function: (none) */
#define  PRINT_TITLE_LOCATION             27      /* control type: textMsg, callback function: (none) */
#define  PRINT_PLANE                      28      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_LOW_IGN               29      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_7               30      /* control type: deco, callback function: (none) */
#define  PRINT_DECORATION_4               31      /* control type: deco, callback function: (none) */
#define  PRINT_KS_THOLD                   32      /* control type: textMsg, callback function: (none) */
#define  PRINT_INFILE                     33      /* control type: textMsg, callback function: (none) */
#define  PRINT_3_COMP                     34      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_17                 35      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_14                 36      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_61                 37      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_62                 38      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_63                 39      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_64                 40      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_65                 41      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_66                 42      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_18              43      /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_68                 44      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_19              45      /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_69                 46      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_70                 47      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_71                 48      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_72                 49      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_73                 50      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_74                 51      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_75                 52      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_76                 53      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_20              54      /* control type: deco, callback function: (none) */
#define  PRINT_DECORATION_21              55      /* control type: deco, callback function: (none) */
#define  PRINT_DENSITY                    56      /* control type: textMsg, callback function: (none) */
#define  PRINT_DENS_MODE                  57      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_IN                58      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_OUT               59      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_ACT               60      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_IGN               61      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_TOT               62      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_OUT_PERC          63      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_67                 64      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_IN                 65      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_OUT                66      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_ACT                67      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_IGN                68      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_TOT                69      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_OUT_PERC           70      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_R_PERC             71      /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_HI_L_PERC             72      /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_L_SHAPE                73      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_78                 74      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_77                 75      /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_R_SHAPE                76      /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_R_POS                  77      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_6               78      /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_79                 79      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_80                 80      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_81                 81      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_22              82      /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_82                 83      /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_84                 84      /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_23              85      /* control type: deco, callback function: (none) */
#define  PRINT_MED_L_SHAPE                86      /* control type: textMsg, callback function: (none) */
#define  PRINT_MED_L_POS                  87      /* control type: textMsg, callback function: (none) */
#define  PRINT_MED_R_SHAPE                88      /* control type: textMsg, callback function: (none) */
#define  PRINT_MED_R_POS                  89      /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_L_SHAPE                 90      /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_R_SHAPE                 91      /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_L_POS                   92      /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_R_POS                   93      /* control type: textMsg, callback function: (none) */
#define  PRINT_DR4_IN                     94      /* control type: deco, callback function: (none) */
#define  PRINT_RANGE_0                    95      /* control type: textMsg, callback function: (none) */
#define  PRINT_RANGE_4                    96      /* control type: textMsg, callback function: (none) */
#define  PRINT_RANGE_1                    97      /* control type: textMsg, callback function: (none) */
#define  PRINT_RANGE_3                    98      /* control type: textMsg, callback function: (none) */
#define  PRINT_RANGE_2                    99      /* control type: textMsg, callback function: (none) */
#define  PRINT_DENS_BKGRND                100     /* control type: deco, callback function: (none) */
#define  PRINT_DR4_OUT                    101     /* control type: deco, callback function: (none) */
#define  PRINT_DR3_OUT                    102     /* control type: deco, callback function: (none) */
#define  PRINT_DR3_IN                     103     /* control type: deco, callback function: (none) */
#define  PRINT_DR2_IN                     104     /* control type: deco, callback function: (none) */
#define  PRINT_DR1_IN                     105     /* control type: deco, callback function: (none) */
#define  PRINT_DR0_IN                     106     /* control type: deco, callback function: (none) */
#define  PRINT_DR2_OUT                    107     /* control type: deco, callback function: (none) */
#define  PRINT_DR1_OUT                    108     /* control type: deco, callback function: (none) */
#define  PRINT_TEXTMSG_85                 109     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_10                 110     /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_L_POS                  111     /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_KT                     112     /* control type: textMsg, callback function: (none) */
#define  PRINT_LOW_KN                     113     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_86                 114     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_88                 115     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_89                 116     /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_KT                      117     /* control type: textMsg, callback function: (none) */
#define  PRINT_HI_KN                      118     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_87                 119     /* control type: textMsg, callback function: (none) */
#define  PRINT_MED_KT                     120     /* control type: textMsg, callback function: (none) */
#define  PRINT_PICTURE_2                  121     /* control type: picture, callback function: (none) */
#define  PRINT_MED_KN                     122     /* control type: textMsg, callback function: (none) */
#define  PRINT_DR0_OUT                    123     /* control type: deco, callback function: (none) */
#define  PRINT_NODAT                      124     /* control type: textMsg, callback function: (none) */
#define  PRINT_DECORATION_2               125     /* control type: deco, callback function: (none) */
#define  PRINT_STAT_LOW_L_PERC            126     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_9                  127     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_83                 128     /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_L_PERC            129     /* control type: textMsg, callback function: (none) */
#define  PRINT_STAT_MED_R_PERC            130     /* control type: textMsg, callback function: (none) */
#define  PRINT_TEXTMSG_90                 131     /* control type: textMsg, callback function: (none) */

#define  SPL_PAN                          9
#define  SPL_PAN_VER                      2       /* control type: textMsg, callback function: (none) */
#define  SPL_PAN_TIMER                    3       /* control type: timer, callback function: exit_splash */
#define  SPL_PAN_PICTURE                  4       /* control type: picture, callback function: exit_splash */

#define  WAIT_PAN                         10
#define  WAIT_PAN_TEXTMSG                 2       /* control type: textMsg, callback function: (none) */

#define  WAIT_PAN_2                       11
#define  WAIT_PAN_2_TEXTMSG               2       /* control type: textMsg, callback function: (none) */

#define  WAIT_PAN_3                       12
#define  WAIT_PAN_3_TEXTMSG               2       /* control type: textMsg, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

#define  LISTER                           1
#define  LISTER_FILE                      2
#define  LISTER_FILE_SAVE                 3       /* callback function: list_save */
#define  LISTER_FILE_CLOSE                4       /* callback function: menu_quitlist */

#define  MENU                             2
#define  MENU_FILE                        2
#define  MENU_FILE_OPEN                   3       /* callback function: MenuOpenFile */
#define  MENU_FILE_SEPARATOR_5            4
#define  MENU_FILE_EDIT                   5       /* callback function: edit_qa0 */
#define  MENU_FILE_SEPARATOR_3            6
#define  MENU_FILE_SAVE_QC0               7       /* callback function: MenuSaveQC0 */
#define  MENU_FILE_SAVE_IMAGE_BMP         8       /* callback function: MenuSaveImageBMP */
#define  MENU_FILE_SAVE_IMAGE_PNG         9       /* callback function: MenuSaveImagePNG */
#define  MENU_FILE_SEPARATOR_4            10
#define  MENU_FILE_PRINT                  11      /* callback function: MenuPrint */
#define  MENU_FILE_SEPARATOR              12
#define  MENU_FILE_QUIT                   13      /* callback function: MenuExitProgram */
#define  MENU_HELP                        14
#define  MENU_HELP_ABOUT_QCFIT            15      /* callback function: about_qcf */

#define  POPUP                            3
#define  POPUP_INTEG                      2       /* callback function: update_integ */
#define  POPUP_INTEG_I01                  3
#define  POPUP_INTEG_I03                  4
#define  POPUP_INTEG_I05                  5
#define  POPUP_INTEG_I10                  6
#define  POPUP_INTEG_I15                  7
#define  POPUP_INTEG_I20                  8
#define  POPUP_INTEG_I30                  9
#define  POPUP_INTEG_I60                  10


     /* Callback Prototypes: */

void CVICALLBACK about_qcf(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK animate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Cancel(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeDensity(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeMonth(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeNewsitePlane(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangePlane(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeYear(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK edit_qa0(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK EditCursorToggle(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditCurvePosLeft(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditCurvePosRight(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditCurveShapeLeft(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditCurveShapeRight(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditErr(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditKnMax(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditKtMax(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditNarrowAndWide(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditOk(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditPanel(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditRestoreGraph(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditUpdateMarker(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EditZoomIn(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK exclude_pix(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK exit_splash(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ExitProgram(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FilterApply(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GetSiteInfo(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK K_animation(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK list_dat(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK list_save(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK menu_quitlist(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuExitProgram(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuOpenFile(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuPrint(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuSaveImageBMP(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuSaveImagePNG(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MenuSaveQC0(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK NewSiteCancel(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NewSiteDataPath(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NewSiteFilterEnable(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NewSiteID(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NewSiteOk(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NewSiteQC0Path(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OpenFileBrowse(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OpenFileBrowseFolder(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OpenFileNewSite(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OpenFileOk(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OpenFileTime(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK plot_freq(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK quit_freq(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK quitlist(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK reset_exclude(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK set_tz(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK update_integ(int menubar, int menuItem, void *callbackData, int panel);


#ifdef __cplusplus
    }
#endif
